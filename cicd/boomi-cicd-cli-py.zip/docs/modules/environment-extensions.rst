.. module:: boomi_cicd.util.environment_extensions
   :noindex:
   :synopsis: Module for Environment Extensions AtomSphere API.

environment_extensions
======================

`Boomi AtomSphere API: Environment Extensions Object <https://help.boomi.com/bundle/developer_apis/page/int-Environment_extensions_object.html>`_

.. automodule:: boomi_cicd.util.environment_extensions
   :members:
   :undoc-members:
   :show-inheritance: