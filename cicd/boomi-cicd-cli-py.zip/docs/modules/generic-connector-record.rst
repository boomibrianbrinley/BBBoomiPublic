.. module:: boomi_cicd.util.generic_connector_record
   :noindex:
   :synopsis: Module for GenericConnectorRecord.

generic_connector_record
========================

`Boomi AtomSphere API: Generic Connector Record Object <https://help.boomi.com/docs/Atomsphere/Integration/AtomSphere%20API/int-Generic_connector_record_object_44c06f13-c285-4153-9daa-fe95a5880d96>`_

.. automodule:: boomi_cicd.util.generic_connector_record
   :members:
   :undoc-members:
