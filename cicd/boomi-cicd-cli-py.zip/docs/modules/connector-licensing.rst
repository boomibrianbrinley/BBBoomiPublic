.. module:: boomi_cicd.util.connector_licensing
   :noindex:
   :synopsis: Module for Connector Licensing Report.

connector_licensing
===================

`Boomi AtomSphere API: Connector Licensing Object <https://help.boomi.com/docs/Atomsphere/Integration/AtomSphere%20API/int-Connection_licensing_operation_a1412b83-b14d-4023-b274-b3212902f578>`_

.. automodule:: boomi_cicd.util.connector_licensing
   :members:
   :undoc-members:
