.. module:: boomi_cicd.util.component_metadata
   :noindex:
   :synopsis: Module for Component Metadata AtomSphere API.

component_metadata
===================

`Boomi AtomSphere API: Component Metadata Object <https://help.boomi.com/docs/Atomsphere/Integration/AtomSphere%20API/int-Component_metadata_object_c2067cb5-bb9d-4033-adc2-d4707e26e75c>`_

.. automodule:: boomi_cicd.util.component_metadata
   :members:
   :undoc-members:
   :show-inheritance: