.. module:: boomi_cicd.util.environment
   :noindex:
   :synopsis: Module for Environment AtomSphere API.



environment
===========

`Boomi AtomSphere API: Environment Object <https://help.boomi.com/bundle/developer_apis/page/r-atm-Environment_object.html>`_

.. automodule:: boomi_cicd.util.environment
   :members:
   :undoc-members:
   :show-inheritance: