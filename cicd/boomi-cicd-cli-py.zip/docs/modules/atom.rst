.. module:: boomi_cicd.util.atom
   :noindex:
   :synopsis: Module for Atom related functions.

atom
====

`Boomi AtomSphere API: Atom Object <https://help.boomi.com/bundle/developer_apis/page/r-atm-Atom_object.html>`_

.. automodule:: boomi_cicd.util.atom
   :members:
   :undoc-members:
