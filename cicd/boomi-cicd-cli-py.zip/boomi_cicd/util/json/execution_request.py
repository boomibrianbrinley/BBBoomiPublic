def create():
    data = {"@type": "ExecutionRequest", "atomId": "", "processId": ""}
    return data
