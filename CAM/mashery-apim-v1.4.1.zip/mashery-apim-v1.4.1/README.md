# Boomi Cloud API Management (CAM) Skill for Claude Code

A Claude Code skill that lets you register, configure, and manage APIs in **Boomi Cloud API Management** — directly from your AI-assisted development workflow.

This skill gives Claude deep knowledge of the Mashery V3 REST API, Python CLI tools for all gateway operations, and battle-tested reference documentation covering authentication, service creation, endpoint routing, package and plan management, and developer key provisioning.

---

## What This Skill Does

| Capability | Description |
|---|---|
| **Service management** | Create and list API Services (the logical API definition objects in Mashery) |
| **Endpoint configuration** | Configure routing rules — inbound path aliases, backend Boomi listener URLs, auth types, HTTP methods |
| **Package + Plan creation** | Create distributable API packages and access-tier plans with rate limiting |
| **Key provisioning** | Admin-provision API keys for immediate testing without developer self-registration |
| **Authentication** | Acquire and manage OAuth 2.0 bearer tokens for the Mashery V3 management API |
| **Boomi Integration gateway** | Full workflow: expose a Boomi WSS listener through the Mashery gateway in minutes |

---

## Prerequisites

- **Claude Code** CLI installed and authenticated
- **Boomi Cloud API Management** area with admin access (see [Authentication Guide](plugins/mashery-apim/skills/mashery-apim/references/guides/authentication.md))
- **Python 3.7+** — used by the CLI tools (standard on macOS/Linux)
- Boomi Integration Atom running a Web Services Server listener (for the Boomi gateway pattern)

---

## Installation

### Step 1 — Install Boomi Companion (recommended)

This skill is designed to work alongside **Boomi Companion** — the official Boomi AI agent for Claude Code that covers Integration, APIs, Event Streams, and the broader Boomi platform:

```
/plugin marketplace add OfficialBoomi/boomi-companion
```

### Step 2 — Install this CAM skill

```
/plugin marketplace add boomi-internal/CAM_saker
```

Then activate the skill:

```
/plugin install mashery-apim@boomi-internal-cam-saker
```

### Alternative — Install from a local clone

```bash
git clone https://github.com/boomi-internal/CAM_saker.git
claude plugin install ./CAM_saker
```

---

## Configuration

Create a `.env` file in your project root (never commit this file):

```bash
# Boomi Cloud API Management (Mashery)
MASHERY_API_KEY=your-mashery-app-api-key
MASHERY_API_SECRET=your-mashery-app-api-secret
MASHERY_USERNAME=you@example.com
MASHERY_PASSWORD=your-mashery-password
MASHERY_AREA_UUID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
MASHERY_API_URL=https://api.mashery.com
MASHERY_TRAFFIC_DOMAIN=yourcompany.api.mashery.com

# Boomi Integration (required for the Boomi Integration + Mashery gateway pattern)
BOOMI_USERNAME=user@example.com
BOOMI_ACCOUNT_ID=boomi_accountname-XXXXXX
BOOMI_API_TOKEN=your-api-token
SERVER_BASE_URL=http://your-atom-host:9090
```

See the [Authentication Guide](plugins/mashery-apim/skills/mashery-apim/references/guides/authentication.md) for how to obtain each value, including where to find your Area UUID and how to issue developer app keys.

---

## CLI Tools

All tools live in `plugins/mashery-apim/skills/mashery-apim/tools/`. They auto-load credentials from your `.env` file.

### Verify credentials
```bash
python3 tools/mashery-auth.py
```

### Create a Service (API definition)
```bash
python3 tools/mashery-service-create.py \
  --name "Orders API" \
  --description "Backed by Boomi Integration" \
  --version "v1"
```

### List existing Services
```bash
python3 tools/mashery-service-list.py
python3 tools/mashery-service-list.py --filter "Orders"   # search by name
```

### Add an Endpoint (routing rule to Boomi listener)
```bash
python3 tools/mashery-endpoint-create.py \
  --service-id <serviceId> \
  --name "Default" \
  --backend-url "http://atom-host:9090/ws/rest/orders" \
  --path-alias "/orders"
```

### Create Package + Plan (developer access tier)
```bash
python3 tools/mashery-package-plan-create.py \
  --service-id <serviceId> \
  --endpoint-id <endpointId> \
  --package-name "Orders API Package" \
  --plan-name "Basic" \
  --provision-key
```

All tools support `--help` for full usage details.

---

## Full Workflow: Expose a Boomi Listener via Mashery

This is the core end-to-end pattern:

```
Boomi Integration (WSS listener)  →  Mashery Gateway  →  Developer API Key
```

**Step 1 — Build the Boomi listener** (use the `boomi-integration` skill):
- Create a process with a Web Services Server start shape
- Deploy to an Atom with port 9090 accessible from the internet

**Step 2 — Register in Mashery**:
```bash
# Verify credentials
python3 tools/mashery-auth.py

# Create the Service
python3 tools/mashery-service-create.py --name "My API"
# → save serviceId

# Create the Endpoint
python3 tools/mashery-endpoint-create.py \
  --service-id <serviceId> \
  --name "Default" \
  --backend-url "http://atom-host:9090/ws/rest/myapi" \
  --path-alias "/myapi"
# → save endpointId

# Create Package + Plan + test key
python3 tools/mashery-package-plan-create.py \
  --service-id <serviceId> \
  --endpoint-id <endpointId> \
  --package-name "My API Package" \
  --plan-name "Basic" \
  --provision-key
```

**Step 3 — Test**:
```bash
curl "https://yourcompany.api.mashery.com/myapi?api_key=<provisioned_key>"
```

---

## Reference Documentation

| Document | Description |
|---|---|
| [CAM_THINKING.md](plugins/mashery-apim/skills/mashery-apim/references/CAM_THINKING.md) | Core mental models — read before any CAM work |
| [authentication.md](plugins/mashery-apim/skills/mashery-apim/references/guides/authentication.md) | OAuth flow, credential setup, Area UUID, token caching |
| [concepts.md](plugins/mashery-apim/skills/mashery-apim/references/guides/concepts.md) | Resource hierarchy, terminology, Mashery vs. Boomi Integration |
| [services.md](plugins/mashery-apim/skills/mashery-apim/references/guides/services.md) | Creating, listing, updating, and deleting Services |
| [endpoints.md](plugins/mashery-apim/skills/mashery-apim/references/guides/endpoints.md) | Endpoint routing, auth types, backend URL construction |
| [packages-and-plans.md](plugins/mashery-apim/skills/mashery-apim/references/guides/packages-and-plans.md) | Packages, Plans, and API key provisioning |
| [best-practices.md](plugins/mashery-apim/skills/mashery-apim/references/guides/best-practices.md) | Naming conventions, rate limits, security, production patterns |
| [request-examples.md](plugins/mashery-apim/skills/mashery-apim/references/api/request-examples.md) | Annotated curl examples for all common Mashery V3 API operations |

---

## Getting Started

New to this skill? Start with the [Getting Started guide](docs/getting-started.md).

---

## Repository Structure

```
CAM_saker/
├── .claude-plugin/
│   └── marketplace.json              Claude Code marketplace metadata
├── docs/
│   └── getting-started.md            Step-by-step 15-minute setup guide
├── plugins/
│   └── mashery-apim/
│       ├── .claude-plugin/
│       │   └── plugin.json           Plugin registration config
│       └── skills/
│           └── mashery-apim/
│               ├── SKILL.md          Navigation hub for Claude
│               ├── references/
│               │   ├── CAM_THINKING.md   Core mental models
│               │   ├── guides/           Topic-specific how-to guides
│               │   └── api/              Request examples
│               └── tools/            Python CLI tools (no external deps)
├── .gitignore
├── CONTRIBUTING.md
└── README.md
```

---

## How It Works with Claude Code

When this skill is installed, Claude gains deep knowledge of the Mashery V3 API and can drive gateway operations via natural language:

```
"Register the Hello World Boomi listener as a Mashery API"
"Create a package and plan for the Orders API with a 10 QPS limit"
"List all services in my Mashery area"
"Provision a test API key for the Products API plan"
"Set up a new API endpoint with OAuth authentication"
```

Claude reads `SKILL.md` as the entry point and routes to the appropriate reference documents and tools based on the task at hand.

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

## Author

**Shawn Aker** — Boomi Platform  
[shawn.aker@boomi.com](mailto:shawn.aker@boomi.com)
