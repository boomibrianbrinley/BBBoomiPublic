# mashery-apim v1.4.1 — manual install (pre-merge build)

This is a **portable, self-contained Claude Code marketplace** built from PR #1
(`feat/mashery-apim-v1.4.0`, plugin **v1.4.1**) of `boomi-internal/CAM_Saker`,
for use **before the PR is merged to `main`**. Once PR #1 merges, switch to the
official marketplace instead of this local copy.

## Prerequisites
- Claude Code CLI
- `python3`, `curl`, `jq`
- A Boomi Cloud API Management (Mashery) area + credentials

## Install
1. Copy this whole `mashery-apim-v1.4.1/` folder onto the target machine (or unzip
   `mashery-apim-v1.4.1.zip`). Note its absolute path, e.g. `~/mashery-apim-v1.4.1`.

2. If that machine already has a `mashery-apim` marketplace (e.g. the v1.0.0 one from
   `main`), remove it first to avoid a name collision:
   ```bash
   claude plugin marketplace remove mashery-apim
   ```

3. Add this folder as a local marketplace and install the plugin:
   ```bash
   claude plugin marketplace add /absolute/path/to/mashery-apim-v1.4.1
   claude plugin install mashery-apim@mashery-apim
   ```

4. Confirm it loaded — the `mashery-apim` skill should be listed, reporting **v1.4.1**.

## Configure credentials (`.env` in your Boomi working project)
```
MASHERY_API_KEY=...          # Control Center -> My Account -> Issue Developer Keys
MASHERY_API_SECRET=...
MASHERY_USERNAME=...          # Control Center login email (NOT a Boomi platform token)
MASHERY_PASSWORD=...
MASHERY_AREA_UUID=...         # from the Control Center URL
MASHERY_API_URL=https://api.mashery.com
MASHERY_TRAFFIC_DOMAIN=...    # exact whitelisted public domain for the area
```

## Verify
```bash
python3 plugins/mashery-apim/skills/mashery-apim/tools/mashery-auth.py
```
Expect a bearer token. If `invalid_client`, the API key/secret are wrong; if `401`,
the username/password are wrong.

## Known caveat (field-tested)
Backends fronted by a CDN/WAF (e.g. Cloudflare) may return an instant
`504 ERR_504_GATEWAY_TIMEOUT` on the outbound leg even with a correct endpoint —
the CDN edge rejects the gateway's data-center egress. Confirm by repointing to a
non-CDN origin. Such backends require additional support — open a ticket with
**support@boomi.com**.
