# Contributing

Contributions are welcome — bug fixes, documentation improvements, new CLI tools, and additional reference guides.

---

## What to Contribute

| Type | Where |
|---|---|
| Bug fix in a tool | `plugins/mashery-apim/skills/mashery-apim/tools/` |
| New API endpoint documentation | `plugins/mashery-apim/skills/mashery-apim/references/api/request-examples.md` |
| New how-to guide | `plugins/mashery-apim/skills/mashery-apim/references/guides/` |
| Discovered API behavior or gotcha | Add to relevant guide + update SKILL.md routing table |
| New CLI tool | `tools/` — follow the existing Python pattern |

---

## Development Setup

1. Fork the repository
2. Clone your fork: `git clone https://github.com/YOUR_USERNAME/CAM_saker.git`
3. Create a `.env` file (see [Authentication Guide](plugins/mashery-apim/skills/mashery-apim/references/guides/authentication.md)) — **never commit this**
4. Test your changes against a real Mashery area

---

## Tool Guidelines

All Python tools in `tools/` follow a consistent pattern:

- **Import from `mashery_paths.py`** for credential loading, token acquisition, and HTTP helpers — do not re-implement auth
- **Use `argparse`** for CLI argument parsing with `--help` support
- **Print human-readable output** by default with a clear summary at the end
- **Print next-step guidance** after each successful operation (what to run next)
- **No external dependencies** — only Python standard library + `mashery_paths.py`
- **Exit code 0** on success, **exit code 1** on any error (via `sys.exit(1)`)

See any existing tool as a template.

---

## Documentation Guidelines

- Write in second person ("you"), present tense
- Lead with practical usage before theory
- Include working curl examples for all API calls documented
- Call out gotchas and non-obvious behavior explicitly — these are the most valuable additions
- Keep tables for field listings and error codes; use prose for explanations
- Update `SKILL.md` routing table whenever you add a new guide

---

## Pull Request Process

1. Create a branch: `git checkout -b feature/your-change`
2. Make your changes
3. Test tools against a live Mashery area
4. Open a PR with a clear description of what changed and why
5. Reference any Mashery API behavior you discovered that informed the change

---

## Reporting Issues

Open a GitHub Issue with:
- What you were trying to do
- What API call failed (endpoint + HTTP response code)
- Any error message from the tool output
- Your Mashery area region (if relevant)
