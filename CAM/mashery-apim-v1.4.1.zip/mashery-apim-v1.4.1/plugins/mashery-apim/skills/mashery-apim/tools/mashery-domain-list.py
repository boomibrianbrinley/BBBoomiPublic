#!/usr/bin/env python3
"""
mashery-domain-list.py — List the area's whitelisted public domains.

The area keeps a registry of "public domains" (a.k.a. the domain whitelist):
the set of hostnames allowed to be used as the public/system domain on an
endpoint — e.g. your Traffic Manager domain (yourco.api.mashery.com) and any
backend hosts (azurewebsites.net, herokuapp.com, ...). An endpoint can only
reference a host that already appears here.

Usage:
    python3 mashery-domain-list.py [--filter <substring>] [--json]

Options:
    --filter SUB   Filter by domain (case-insensitive substring match)
    --json         Emit raw JSON instead of the formatted listing

Output: Formatted list of whitelisted domains with IDs and status.
"""

import sys
import argparse
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mashery_paths import load_env, get_token, mashery_get_all, print_json


def main():
    parser = argparse.ArgumentParser(description="List Mashery area public (whitelisted) domains")
    parser.add_argument("--filter", help="Filter by domain (substring match)")
    parser.add_argument("--json", action="store_true", help="Emit raw JSON")
    args = parser.parse_args()

    load_env()
    token = get_token()

    # V3 /domains returns a bare JSON array (like /services); mashery_get_all
    # normalizes the response and pages via the X-Total-Count header.
    domains = mashery_get_all("domains", token,
                              params={"fields": "id,domain,status,description"})

    if args.filter:
        needle = args.filter.lower()
        domains = [d for d in domains if needle in d.get("domain", "").lower()]

    if args.json:
        print(json.dumps(domains, indent=2))
        return

    print(f"Found {len(domains)} whitelisted domain(s):\n")
    for d in domains:
        print(f"  ID:      {d.get('id')}")
        print(f"  Domain:  {d.get('domain')}")
        print(f"  Status:  {d.get('status')}")
        if d.get("description"):
            print(f"  Desc:    {d.get('description')}")
        print()

    if not domains:
        print("No domains found. Register one with mashery-domain-create.py")


if __name__ == "__main__":
    main()
