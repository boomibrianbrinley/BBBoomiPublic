#!/usr/bin/env python3
"""
mashery-endpoint-get.py — Show an endpoint's full configuration (for diffing).

A single endpoint GET returns only id/name/created/updated unless you pass an
explicit fields list — this tool requests the full field set so you can inspect
or diff an endpoint's real config (the backbone of mashery-endpoint-clone.py).

Usage:
    python3 mashery-endpoint-get.py --service-id <id> --endpoint-id <id> [--json] [--raw-secret]

Options:
    --service-id   Parent service ID (required)
    --endpoint-id  Endpoint ID (required)
    --json         Emit raw JSON only (good for `diff <(get A) <(get B)`)
    --raw-secret   Do NOT mask the systemDomainAuthentication password
                   (default: masked to ***). Use with care.

Output: the endpoint's full config as JSON (backend-auth password masked unless
--raw-secret).
"""

import sys
import argparse
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mashery_paths import (load_env, get_token, mashery_get, print_json,
                           mask_system_domain_auth, ENDPOINT_FULL_FIELDS)


def main():
    parser = argparse.ArgumentParser(description="Show a Mashery endpoint's full config")
    parser.add_argument("--service-id", required=True, help="Parent service ID")
    parser.add_argument("--endpoint-id", required=True, help="Endpoint ID")
    parser.add_argument("--json", action="store_true", help="Emit raw JSON only")
    parser.add_argument("--raw-secret", action="store_true",
                        help="Do not mask the backend-auth password")
    args = parser.parse_args()

    load_env()
    token = get_token()

    path = f"services/{args.service_id}/endpoints/{args.endpoint_id}"
    ep = mashery_get(f"{path}?fields={ENDPOINT_FULL_FIELDS}", token)

    if not args.raw_secret and isinstance(ep.get("systemDomainAuthentication"), dict):
        ep = dict(ep)
        ep["systemDomainAuthentication"] = mask_system_domain_auth(ep["systemDomainAuthentication"])

    if args.json:
        print(json.dumps(ep, indent=2, sort_keys=True))
        return

    print(f"Endpoint {ep.get('name')!r} ({ep.get('id')})")
    print(f"  Path alias:   {ep.get('requestPathAlias')}")
    print(f"  Public:       {[d.get('address') for d in (ep.get('publicDomains') or [])]}")
    print(f"  System:       {[d.get('address') for d in (ep.get('systemDomains') or [])]}")
    print(f"  Backend path: {ep.get('outboundTransportProtocol')}://...{ep.get('outboundRequestTargetPath')}")
    print(f"  Inbound auth: {ep.get('requestAuthenticationType')} "
          f"(key {ep.get('apiKeyValueLocationKey')!r} in {ep.get('apiKeyValueLocations')})")
    sda = ep.get("systemDomainAuthentication")
    print(f"  Backend auth: {sda if sda else 'none'}")
    print(f"  Methods:      {ep.get('supportedHttpMethods')}")
    print(f"  Timeouts:     req={ep.get('connectionTimeoutForSystemDomainRequest')} "
          f"resp={ep.get('connectionTimeoutForSystemDomainResponse')}")
    print(f"  Processor:    {(ep.get('processor') or {}).get('adapter', 'none')}")
    print(f"  Inbound SSL:  {ep.get('inboundSslRequired')}   highSecurity: {ep.get('highSecurity')}")
    print(f"\nFull config:")
    print_json(ep)


if __name__ == "__main__":
    main()
