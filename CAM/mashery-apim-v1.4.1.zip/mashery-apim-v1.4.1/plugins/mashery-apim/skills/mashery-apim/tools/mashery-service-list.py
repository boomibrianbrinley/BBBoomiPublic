#!/usr/bin/env python3
"""
mashery-service-list.py — List all Mashery Services in the area.

Usage:
    python3 mashery-service-list.py [--filter <name>] [--fields <f1,f2>]

Options:
    --filter NAME    Filter by service name (case-insensitive substring match)
    --fields FIELDS  Comma-separated fields to return (default: id,name,version,description)

Output: Formatted list of services with IDs.
"""

import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mashery_paths import load_env, get_token, mashery_get_all, print_json


def main():
    parser = argparse.ArgumentParser(description="List Mashery Services")
    parser.add_argument("--filter", help="Filter by name (substring match)")
    parser.add_argument("--fields", default="id,name,version,description",
                        help="Fields to return (default: id,name,version,description)")
    args = parser.parse_args()

    load_env()
    token = get_token()

    # V3 /services returns a bare JSON array; mashery_get_all normalizes the
    # response and handles limit/offset pagination via the X-Total-Count header.
    all_items = mashery_get_all("services", token, params={"fields": args.fields})

    # Apply name filter
    if args.filter:
        needle = args.filter.lower()
        all_items = [s for s in all_items if needle in s.get("name", "").lower()]

    print(f"Found {len(all_items)} service(s):\n")
    for svc in all_items:
        print(f"  ID:      {svc.get('id')}")
        print(f"  Name:    {svc.get('name')}")
        print(f"  Version: {svc.get('version', '')}")
        if svc.get("description"):
            print(f"  Desc:    {svc.get('description')}")
        print()

    if not all_items:
        print("No services found. Create one with mashery-service-create.py")


if __name__ == "__main__":
    main()
