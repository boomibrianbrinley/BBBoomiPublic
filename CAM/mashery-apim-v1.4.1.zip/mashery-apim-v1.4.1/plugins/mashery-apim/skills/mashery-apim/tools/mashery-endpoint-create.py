#!/usr/bin/env python3
"""
mashery-endpoint-create.py — Add an Endpoint to a Mashery Service.

Usage:
    python3 mashery-endpoint-create.py \
        --service-id <serviceId> \
        --name "Default" \
        --backend-url "http://atom-host:9090/ws/rest/myapi" \
        --path-alias "/myapi" \
        [--auth apiKey|apiKeyAndSecret_SHA256] \
        [--key-param api_key] \
        [--methods get,post,put,delete] \
        [--ssl] \
        [--backend-auth-type httpBasic --backend-user U --backend-password P]

Options:
    --service-id   ID of the parent service (required)
    --name         Endpoint name (required)
    --backend-url  Full URL of your Boomi listener (required)
                   e.g. http://W10-B13QL24:9090/ws/rest/orders
    --path-alias   Public path alias clients call (required, starts with /)
                   e.g. /orders
    --auth         Authentication type: apiKey (default) | apiKeyAndSecret_SHA256 | none.
                   Mashery V3 has NO unauthenticated/open endpoint type — any
                   unrecognized value (including "none") is parsed as `custom` and
                   fails with "customRequestAuthenticationAdapter is required". The
                   tool rejects --auth none up front with that explanation; for a
                   keyless/public endpoint use the Control Center UI. Note: omitting
                   the field is not "open" either — the area defaults it to apiKey.
    --key-param    Query parameter name for API key (default: api_key)
    --methods      Comma-separated HTTP methods (default: get,post,put,delete)
    --ssl          Require HTTPS on inbound (flag, default: off)
    --backend-auth-type  Outbound auth Mashery uses when calling your backend
                   (systemDomainAuthentication). Currently: httpBasic. Omit for none.
    --backend-user       Username for httpBasic backend auth (required with httpBasic)
    --backend-password   Password for httpBasic backend auth. If omitted, read from
                   env MASHERY_BACKEND_PASSWORD (avoids exposing it in the process list).
    --sdk-processors / --processor-adapter / --connect-timeout / ...  Call Transformation
                   (endpoint processor) + backend timeouts. ONE SDK class → set as adapter
                   directly; MULTIPLE → Mashery_Proxy_Processor_Chain. --connect-timeout is
                   2-7 sec only. See mashery-endpoint-update.py / endpoints.md for the full set.

The MASHERY_TRAFFIC_DOMAIN from .env is used as the public domain.

Output: JSON of the created endpoint. Save the "id" as endpointId.
"""

import sys
import argparse
import os
from pathlib import Path
from urllib.parse import urlparse

sys.path.insert(0, str(Path(__file__).parent))
from mashery_paths import (load_env, get_mashery_credentials, get_token, mashery_post,
                           mashery_get, print_json, build_system_domain_auth,
                           mask_system_domain_auth, ENDPOINT_FIELDS,
                           add_processor_args, apply_processor_args)


def parse_backend_url(backend_url):
    """Parse a backend URL into systemDomain, protocol, and path components."""
    parsed = urlparse(backend_url)
    host = parsed.hostname
    port = parsed.port

    if port:
        system_domain = f"{host}:{port}"
    else:
        system_domain = host

    protocol = parsed.scheme or "http"
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query

    return system_domain, protocol, path


def main():
    parser = argparse.ArgumentParser(description="Create a Mashery Endpoint on a Service")
    parser.add_argument("--service-id", required=True, help="Parent service ID")
    parser.add_argument("--name", required=True, help="Endpoint name")
    parser.add_argument("--backend-url", required=True,
                        help="Full Boomi listener URL (e.g. http://host:9090/ws/rest/myapi)")
    parser.add_argument("--path-alias", required=True,
                        help="Public path alias (e.g. /orders)")
    parser.add_argument("--auth", default="apiKey",
                        choices=["apiKey", "apiKeyAndSecret_SHA256", "none"],
                        help="Auth type: apiKey (default) | apiKeyAndSecret_SHA256 | none. "
                             "NOTE: Mashery V3 has no unauthenticated/open endpoint type — "
                             "'none' is rejected (see below).")
    parser.add_argument("--key-param", default="api_key",
                        help="Query parameter name for API key (default: api_key)")
    parser.add_argument("--methods", default="get,post,put,delete",
                        help="Supported HTTP methods (default: get,post,put,delete)")
    parser.add_argument("--ssl", action="store_true",
                        help="Require HTTPS on inbound")
    parser.add_argument("--backend-auth-type", "--system-domain-auth", dest="backend_auth_type",
                        choices=["httpBasic", "basic"],
                        help="Outbound auth to the backend (systemDomainAuthentication). "
                             "httpBasic (alias: basic). Omit for none.")
    parser.add_argument("--backend-user", "--system-user", dest="backend_user",
                        help="Username for httpBasic backend auth")
    parser.add_argument("--backend-password", "--system-pass", dest="backend_password",
                        help="Password for httpBasic backend auth "
                             "(else env MASHERY_BACKEND_PASSWORD — avoids the CLI)")
    add_processor_args(parser)
    args = parser.parse_args()
    if args.backend_auth_type == "basic":
        args.backend_auth_type = "httpBasic"

    load_env()
    creds = get_mashery_credentials()

    # Mashery V3 has no unauthenticated/open endpoint type. requestAuthenticationType
    # accepts only apiKey, apiKeyAndSecret_SHA256, oauth (if enabled on the service),
    # or custom (which needs a customRequestAuthenticationAdapter). Any other value —
    # including "none" — is parsed as `custom`, so the create fails with:
    #   400 "Property 'customRequestAuthenticationAdapter' is required if
    #        requestAuthenticationType is custom."
    # Fail fast with that explanation instead of sending a request that 400s.
    if args.auth == "none":
        print("ERROR: Mashery V3 has no unauthenticated ('none'/open) endpoint type.",
              file=sys.stderr)
        print("requestAuthenticationType must be one of: apiKey, apiKeyAndSecret_SHA256, "
              "oauth (if enabled), custom.", file=sys.stderr)
        print("Sending 'none' is treated as 'custom' and fails with "
              "\"customRequestAuthenticationAdapter is required\".", file=sys.stderr)
        print("\nUse --auth apiKey for a keyed endpoint. For a truly keyless/public "
              "endpoint, configure it in the Mashery Control Center UI (or a custom "
              "no-op auth adapter) — it cannot be created keyless via the V3 API.",
              file=sys.stderr)
        sys.exit(1)

    token = get_token()

    system_domain, protocol, target_path = parse_backend_url(args.backend_url)
    traffic_domain = creds.get("traffic_domain", "")
    methods = [m.strip().lower() for m in args.methods.split(",")]

    # Ensure path alias starts with /
    path_alias = args.path_alias if args.path_alias.startswith("/") else f"/{args.path_alias}"

    body = {
        "name": args.name,
        "requestPathAlias": path_alias,
        "systemDomains": [{"address": system_domain}],
        "outboundRequestTargetPath": target_path,
        "outboundTransportProtocol": protocol,
        "inboundSslRequired": args.ssl,
        "supportedHttpMethods": methods,
        "useSystemDomainAsTarget": False,
        "requestAuthenticationType": args.auth,
    }

    if traffic_domain:
        body["publicDomains"] = [{"address": traffic_domain}]
        body["trafficManagerDomain"] = traffic_domain

    # Both key-based auth types read the key from the same location. (Note:
    # omitting requestAuthenticationType does NOT mean "open" — the area defaults
    # it to apiKey, so it must be set explicitly.)
    if args.auth in ("apiKey", "apiKeyAndSecret_SHA256"):
        body["apiKeyValueLocations"] = ["request-parameters"]
        body["apiKeyValueLocationKey"] = args.key_param

    # Outbound/backend auth (systemDomainAuthentication) — e.g. HTTP Basic to a
    # secured Boomi listener.
    if args.backend_auth_type:
        password = args.backend_password or os.environ.get("MASHERY_BACKEND_PASSWORD")
        try:
            body["systemDomainAuthentication"] = build_system_domain_auth(
                args.backend_auth_type, args.backend_user, password)
        except ValueError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)

    # Call Transformation (processor) + connect/response timeouts (shared logic).
    try:
        proc_changes = apply_processor_args(args, body)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    path = f"services/{args.service_id}/endpoints"
    print(f"Creating endpoint {args.name!r} on service {args.service_id}...")
    print(f"  Backend:      {args.backend_url}")
    print(f"  Public path:  {path_alias}")
    print(f"  Auth:         {args.auth}")
    if args.backend_auth_type:
        print(f"  Backend auth: {args.backend_auth_type} (user {args.backend_user!r})")
    for c in proc_changes:
        print(f"  {c}")
    print()

    result = mashery_post(path, token, body)
    endpoint_id = result.get("id")

    # The POST response is a minimal projection (id/name/created/updated). Read the
    # endpoint back with explicit fields so the output is informative.
    result = mashery_get(f"{path}/{endpoint_id}?fields={ENDPOINT_FIELDS}", token)
    print(f"Endpoint created successfully!")
    print(f"  Endpoint ID:  {endpoint_id}")
    print(f"  Path alias:   {result.get('requestPathAlias')}")
    print(f"  Backend:      {protocol}://{system_domain}{target_path}")
    # Mask the backend-auth password before dumping the response.
    if isinstance(result.get("systemDomainAuthentication"), dict):
        result = dict(result)
        result["systemDomainAuthentication"] = mask_system_domain_auth(
            result["systemDomainAuthentication"])
    print(f"\nFull endpoint:")
    print_json(result)

    if traffic_domain:
        print(f"\nPublic URL will be:")
        print(f"  https://{traffic_domain}{path_alias}?{args.key_param}=<api_key>")

    print(f"\nNext step — create a Package + Plan:")
    print(f"  python3 mashery-package-plan-create.py \\")
    print(f"    --service-id {args.service_id} \\")
    print(f"    --endpoint-id {endpoint_id} \\")
    print(f"    --package-name \"My API Package\" \\")
    print(f"    --plan-name \"Basic\"")


if __name__ == "__main__":
    main()
