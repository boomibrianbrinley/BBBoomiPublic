#!/usr/bin/env python3
"""
mashery-service-create.py — Create a new Mashery Service (API definition).

Usage:
    python3 mashery-service-create.py --name "My API" [--description "..."] [--version "v1"]

Options:
    --name NAME          Service name (required, must be unique in area)
    --description DESC   Service description
    --version VERSION    Version label (default: "v1")

Output: JSON of the created service. The "id" field is the serviceId needed
        for mashery-endpoint-create.py and mashery-package-plan-create.py.
"""

import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mashery_paths import load_env, get_token, mashery_post, print_json


def main():
    parser = argparse.ArgumentParser(description="Create a Mashery Service")
    parser.add_argument("--name", required=True, help="Service name (must be unique)")
    parser.add_argument("--description", default="", help="Service description")
    parser.add_argument("--version", default="v1", help="Version label (default: v1)")
    args = parser.parse_args()

    load_env()
    token = get_token()

    body = {
        "name": args.name,
        "description": args.description,
        "version": args.version,
    }

    print(f"Creating Mashery Service: {args.name!r}...")
    result = mashery_post("services", token, body)

    service_id = result.get("id")
    print(f"\nService created successfully!")
    print(f"  Service ID:   {service_id}")
    print(f"  Name:         {result.get('name')}")
    print(f"  Version:      {result.get('version')}")
    print(f"\nFull response:")
    print_json(result)
    print(f"\nNext step — create an endpoint:")
    print(f"  python3 mashery-endpoint-create.py --service-id {service_id} \\")
    print(f"    --name \"Default\" --backend-url <BOOMI_LISTENER_URL> --path-alias /myapi")


if __name__ == "__main__":
    main()
