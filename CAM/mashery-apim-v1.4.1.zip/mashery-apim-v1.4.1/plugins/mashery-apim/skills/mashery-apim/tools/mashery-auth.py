#!/usr/bin/env python3
"""
mashery-auth.py — Verify Mashery credentials and print a bearer token.

Usage:
    python3 mashery-auth.py

Reads credentials from the project .env file. If successful, prints:
  - The bearer token (can be used in manual curl calls)
  - The area UUID the token is scoped to

Exit codes:
  0 — success
  1 — authentication failed (check .env)
"""

import sys
import os
from pathlib import Path

# Allow importing mashery_paths from this directory
sys.path.insert(0, str(Path(__file__).parent))
from mashery_paths import load_env, get_mashery_credentials, get_token


def main():
    load_env()
    creds = get_mashery_credentials()

    print(f"Authenticating to {creds['api_url']}...")
    print(f"Area UUID: {creds['area_uuid']}")
    print(f"Username:  {creds['username']}")
    print()

    token = get_token()

    print("Authentication successful!")
    print()
    print("Bearer token (valid ~1 hour):")
    print(token)
    print()
    print("Example usage:")
    print(f'  curl -H "Authorization: Bearer {token[:20]}..." \\')
    print(f'       "{creds["api_url"]}/v3/rest/services?fields=id,name"')


if __name__ == "__main__":
    main()
