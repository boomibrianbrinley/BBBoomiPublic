#!/usr/bin/env python3
"""
mashery-domain-create.py — Register (whitelist) a public domain in the area.

Adds a hostname to the area's public-domain whitelist so it can be used as the
public or system domain on an endpoint (e.g. a Traffic Manager domain like
yourco.api.mashery.com, or a backend host). Confirmed working against the V3
API — this is NOT a Control-Center-UI-only operation.

Usage:
    python3 mashery-domain-create.py --domain <hostname> [--description "..."]

Options:
    --domain HOST       Hostname to whitelist (required), e.g. api.example.com
    --description DESC   Optional note (stored on the whitelist entry)

Output: JSON of the created domain entry, including its "id" and the gateway's
        "...has been whitelisted." confirmation message.

IMPORTANT — register deliberately:
    The V3 API does NOT permit deleting a domain (DELETE /domains/{id} returns
    403 Forbidden for the standard service account) and the `domain`/`status`
    fields are immutable on update (only `description` can be PUT). A
    whitelisted domain can therefore only be removed via the Control Center UI.
    Double-check the hostname before running this.
"""

import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mashery_paths import load_env, get_token, mashery_post, print_json


def main():
    parser = argparse.ArgumentParser(description="Whitelist a public domain in the Mashery area")
    parser.add_argument("--domain", required=True,
                        help="Hostname to whitelist (e.g. api.example.com)")
    parser.add_argument("--description", default="", help="Optional note on the entry")
    args = parser.parse_args()

    load_env()
    token = get_token()

    body = {"domain": args.domain, "status": "active"}
    if args.description:
        body["description"] = args.description

    print(f"Whitelisting public domain: {args.domain!r}...")
    result = mashery_post("domains", token, body)

    print(f"\nDomain whitelisted successfully!")
    print(f"  Domain ID:  {result.get('id')}")
    print(f"  Domain:     {result.get('domain')}")
    print(f"  Status:     {result.get('status')}")
    if result.get("message"):
        print(f"  Message:    {result.get('message')}")
    print(f"\nFull response:")
    print_json(result)

    print(f"\nNote: this domain can now be used as a publicDomains/systemDomains")
    print(f"      address on an endpoint. It cannot be removed via the V3 API")
    print(f"      (DELETE returns 403) — only via the Control Center UI.")


if __name__ == "__main__":
    main()
