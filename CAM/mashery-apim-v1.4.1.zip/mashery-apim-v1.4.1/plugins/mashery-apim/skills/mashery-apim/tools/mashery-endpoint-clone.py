#!/usr/bin/env python3
"""
mashery-endpoint-clone.py — Clone an endpoint's full config to a target service.

Reads the SOURCE endpoint's complete configuration, deep-copies it, applies only
the overrides you pass, and creates the clone on the TARGET service — so every
non-overridden field (apiKeyValueLocations, supportedHttpMethods, the
CircuitBreaker `processor`, `systemDomainAuthentication`, connection timeouts,
headers, `cache`, `highSecurity`, …) matches the source exactly. The goal is a
"seamless" clone: a config diff shows ONLY the fields you intentionally changed.

Usage:
    python3 mashery-endpoint-clone.py \
        --source-service-id <id> --source-endpoint-id <id> \
        --target-service-id <id> \
        [--name "New name"] [--path-alias /new/path] \
        [--public-domain new.api.mashery.com] [--inbound-ssl true|false] \
        [--no-copy-methods] [--raw-secret]

Options:
    --source-service-id / --source-endpoint-id   Endpoint to copy FROM (required)
    --target-service-id   Service to create the clone ON (required; may equal source)
    --name           Override the clone's name (default: same as source)
    --path-alias     Override requestPathAlias (leading / added if missing)
    --public-domain  Override the inbound public domain (also sets trafficManagerDomain)
    --inbound-ssl    Override inboundSslRequired (true|false)
    --no-copy-methods  Do not copy the source endpoint's API methods (default: copy)
    --raw-secret     Do not mask the backend-auth password in output (default: masked)

Secrets: the source `systemDomainAuthentication` (e.g. HTTP Basic password) is
copied IN-PROCESS (source GET → target POST). It is never taken on the command
line and is masked (***) in this tool's output.

Constraints worth knowing (verified live):
- An endpoint's (publicDomain, requestPathAlias) must be unique — override
  --path-alias and/or --public-domain so the clone doesn't collide with the source.
- connectionTimeout* values must be >= 2 (the clone copies the source value, which
  is already valid).
- A whitelisted public domain can't be deleted via the API (DELETE → 403) — pick
  --public-domain carefully (see mashery-domain-list.py).
- Newly provisioned keys can take ~15 min to propagate to the gateway.

Output: the created clone's full config (JSON; backend secret masked).
"""

import sys
import argparse
import copy
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mashery_paths import (load_env, get_token, mashery_get, mashery_get_all, mashery_post,
                           print_json, strip_server_keys, mask_system_domain_auth,
                           ENDPOINT_FULL_FIELDS)

METHOD_FIELDS = "id,name,sampleJsonResponse,sampleXmlResponse"


def main():
    parser = argparse.ArgumentParser(description="Clone a Mashery endpoint to a target service")
    parser.add_argument("--source-service-id", required=True)
    parser.add_argument("--source-endpoint-id", required=True)
    parser.add_argument("--target-service-id", required=True,
                        help="Service to create the clone on (may equal source)")
    parser.add_argument("--name", help="Override clone name (default: source name)")
    parser.add_argument("--path-alias", help="Override requestPathAlias")
    parser.add_argument("--public-domain", help="Override inbound public domain")
    parser.add_argument("--inbound-ssl", choices=["true", "false"],
                        help="Override inboundSslRequired")
    parser.add_argument("--no-copy-methods", action="store_true",
                        help="Do not copy the source endpoint's API methods")
    parser.add_argument("--raw-secret", action="store_true",
                        help="Do not mask the backend-auth password in output")
    args = parser.parse_args()

    load_env()
    token = get_token()

    src_path = f"services/{args.source_service_id}/endpoints/{args.source_endpoint_id}"
    source = mashery_get(f"{src_path}?fields={ENDPOINT_FULL_FIELDS}", token)
    if not source.get("id"):
        print(f"ERROR: source endpoint {args.source_endpoint_id} not found on service "
              f"{args.source_service_id}.", file=sys.stderr)
        sys.exit(1)

    # Build the clone body: deep copy, drop server-managed keys, drop methods
    # (methods are sub-resources, copied separately below).
    body = strip_server_keys(copy.deepcopy(source))
    body.pop("methods", None)

    # Apply overrides only.
    applied = []
    if args.name:
        body["name"] = args.name
        applied.append("name")
    if args.path_alias:
        body["requestPathAlias"] = (args.path_alias if args.path_alias.startswith("/")
                                    else f"/{args.path_alias}")
        applied.append("requestPathAlias")
    if args.public_domain:
        body["publicDomains"] = [{"address": args.public_domain}]
        body["trafficManagerDomain"] = args.public_domain
        applied.append("publicDomains")
    if args.inbound_ssl is not None:
        body["inboundSslRequired"] = (args.inbound_ssl == "true")
        applied.append("inboundSslRequired")

    same_service = args.target_service_id == args.source_service_id
    if not args.path_alias and not args.public_domain:
        where = "the same service" if same_service else "the target service"
        print("WARNING: no --path-alias or --public-domain override — the clone will "
              f"reuse the source's public domain + path. If {where} already exposes that "
              "(publicDomain, requestPathAlias) pair, the create will be rejected.",
              file=sys.stderr)

    print(f"Cloning endpoint {source.get('name')!r} → service {args.target_service_id}")
    print(f"  Overrides applied: {', '.join(applied) if applied else '(none)'}")
    print(f"  Backend auth:      {'copied in-process (masked)' if source.get('systemDomainAuthentication') else 'none'}")
    print()

    target_eps = f"services/{args.target_service_id}/endpoints"
    clone = mashery_post(target_eps, token, body)
    clone_id = clone["id"]
    print(f"Clone created — endpoint ID {clone_id}")

    # Copy methods (sub-resources) unless suppressed.
    copied_methods = 0
    if not args.no_copy_methods:
        src_methods = mashery_get_all(
            f"{src_path}/methods", token, params={"fields": METHOD_FIELDS})
        for m in src_methods:
            mashery_post(f"{target_eps}/{clone_id}/methods", token, strip_server_keys(m))
            copied_methods += 1
        if src_methods:
            print(f"Copied {copied_methods} method(s): "
                  f"{', '.join(m.get('name', '?') for m in src_methods)}")

    # Read the clone back and show it (secret masked unless --raw-secret).
    result = mashery_get(f"{target_eps}/{clone_id}?fields={ENDPOINT_FULL_FIELDS}", token)
    if not args.raw_secret and isinstance(result.get("systemDomainAuthentication"), dict):
        result = dict(result)
        result["systemDomainAuthentication"] = mask_system_domain_auth(
            result["systemDomainAuthentication"])

    print(f"\nClone summary:")
    print(f"  Name:         {result.get('name')}")
    print(f"  Path alias:   {result.get('requestPathAlias')}")
    print(f"  Public:       {[d.get('address') for d in (result.get('publicDomains') or [])]}")
    print(f"  Backend auth: {result.get('systemDomainAuthentication') or 'none'}")
    print(f"  Processor:    {(result.get('processor') or {}).get('adapter', 'none')}")
    print(f"  Methods:      {copied_methods} copied")
    print(f"\nVerify faithfulness with a diff of the full configs:")
    print(f"  diff <(python3 mashery-endpoint-get.py --service-id {args.source_service_id} "
          f"--endpoint-id {args.source_endpoint_id} --json) \\")
    print(f"       <(python3 mashery-endpoint-get.py --service-id {args.target_service_id} "
          f"--endpoint-id {clone_id} --json)")
    print(f"\nFull clone config:")
    print_json(result)


if __name__ == "__main__":
    main()
