#!/usr/bin/env python3
"""
mashery-endpoint-update.py — Update an existing Mashery Endpoint (partial PUT).

Mashery V3 PUT on an endpoint MERGES — only the fields you send are changed; the
rest are preserved (verified live). So this tool sends just the fields you pass.

Usage:
    python3 mashery-endpoint-update.py \
        --service-id <serviceId> --endpoint-id <endpointId> \
        [--name "New name"] \
        [--backend-url "http://atom-host:9090/ws/rest/myapi"] \
        [--path-alias "/myapi"] \
        [--methods get,post] \
        [--auth apiKey|apiKeyAndSecret_SHA256] [--key-param api_key] \
        [--ssl | --no-ssl] \
        [--backend-auth-type httpBasic --backend-user U --backend-password P] \
        [--clear-backend-auth] \
        [--sdk-processors "<fqcn>[,<fqcn>...]"] [--processor-adapter NAME --pre-inputs JSON --post-inputs JSON] \
        [--clear-processor] [--connect-timeout 2..7] [--response-timeout N]

Options:
    --service-id   Parent service ID (required)
    --endpoint-id  Endpoint ID to update (required)
    --name         New endpoint name
    --backend-url  New backend URL (sets systemDomains + outboundRequestTargetPath
                   + outboundTransportProtocol)
    --path-alias   New public path alias (starts with /)
    --methods      Comma-separated HTTP methods
    --auth         apiKey | apiKeyAndSecret_SHA256  ('none' is rejected — V3 has no
                   open endpoint type, same as endpoint-create)
    --key-param    API key parameter/header name (used with --auth)
    --ssl/--no-ssl Set inbound HTTPS required on/off
    --backend-auth-type  Set outbound backend auth (systemDomainAuthentication): httpBasic
    --backend-user / --backend-password  Credentials for httpBasic (password also from
                   env MASHERY_BACKEND_PASSWORD)
    --clear-backend-auth  Remove backend auth (sets systemDomainAuthentication to null)

  Call Transformation (endpoint processor) — see "Cloning/Call Transformation" in
  references/guides/endpoints.md:
    --sdk-processors "A[,B]"  Custom SDK class FQCN(s). ONE → set as adapter directly;
                   MULTIPLE → Mashery_Proxy_Processor_Chain with a comma `processors` list.
    --sdk-pre-processors / --sdk-post-processors   Per-stage class lists (when pre≠post).
    --processor-adapter NAME --pre-inputs JSON --post-inputs JSON   Named connector / full control.
    --pre-process / --post-process true|false   Toggle the pre/post stages.
    --clear-processor   Remove the Call Transformation.
    --connect-timeout N   Backend CONNECT timeout (connectionTimeoutForSystemDomainRequest); 2-7 only.
    --response-timeout N  Backend RESPONSE timeout (connectionTimeoutForSystemDomainResponse); >= 2.

At least one change flag is required. Backend-auth password is masked in output.

Output: the updated endpoint (read back with explicit fields; secret masked).
"""

import sys
import argparse
import os
from pathlib import Path
from urllib.parse import urlparse

sys.path.insert(0, str(Path(__file__).parent))
from mashery_paths import (load_env, get_token, mashery_get, mashery_put, print_json,
                           build_system_domain_auth, mask_system_domain_auth,
                           ENDPOINT_FIELDS, add_processor_args, apply_processor_args)


def parse_backend_url(backend_url):
    """Parse a backend URL into systemDomain, protocol, and path components."""
    parsed = urlparse(backend_url)
    host = parsed.hostname
    port = parsed.port
    system_domain = f"{host}:{port}" if port else host
    protocol = parsed.scheme or "http"
    path = parsed.path or "/"
    if parsed.query:
        path += "?" + parsed.query
    return system_domain, protocol, path


def main():
    parser = argparse.ArgumentParser(description="Update a Mashery Endpoint (partial PUT)")
    parser.add_argument("--service-id", required=True, help="Parent service ID")
    parser.add_argument("--endpoint-id", required=True, help="Endpoint ID to update")
    parser.add_argument("--name", help="New endpoint name")
    parser.add_argument("--backend-url", help="New backend URL")
    parser.add_argument("--path-alias", help="New public path alias (starts with /)")
    parser.add_argument("--methods", help="Comma-separated HTTP methods")
    parser.add_argument("--auth", choices=["apiKey", "apiKeyAndSecret_SHA256", "none"],
                        help="Inbound auth type (none is rejected — see help)")
    parser.add_argument("--key-param", default="api_key",
                        help="API key parameter/header name (with --auth)")
    ssl_group = parser.add_mutually_exclusive_group()
    ssl_group.add_argument("--ssl", dest="ssl", action="store_true", default=None,
                           help="Require inbound HTTPS")
    ssl_group.add_argument("--no-ssl", dest="ssl", action="store_false",
                           help="Do not require inbound HTTPS")
    parser.add_argument("--backend-auth-type", "--system-domain-auth", dest="backend_auth_type",
                        choices=["httpBasic", "basic"],
                        help="Set backend auth (systemDomainAuthentication): httpBasic (alias: basic)")
    parser.add_argument("--backend-user", "--system-user", dest="backend_user",
                        help="Username for httpBasic backend auth")
    parser.add_argument("--backend-password", "--system-pass", dest="backend_password",
                        help="Password for httpBasic backend auth (else env MASHERY_BACKEND_PASSWORD)")
    parser.add_argument("--clear-backend-auth", action="store_true",
                        help="Remove backend auth (sets systemDomainAuthentication to null)")
    add_processor_args(parser)
    args = parser.parse_args()
    if args.backend_auth_type == "basic":
        args.backend_auth_type = "httpBasic"

    if args.auth == "none":
        print("ERROR: Mashery V3 has no unauthenticated ('none'/open) endpoint type.",
              file=sys.stderr)
        print("Use apiKey or apiKeyAndSecret_SHA256; for a keyless endpoint use the "
              "Control Center UI.", file=sys.stderr)
        sys.exit(1)

    if args.backend_auth_type and args.clear_backend_auth:
        print("ERROR: pass either --backend-auth-type or --clear-backend-auth, not both.",
              file=sys.stderr)
        sys.exit(1)

    # Build the partial body from only the flags provided.
    body = {}
    if args.name is not None:
        body["name"] = args.name
    if args.path_alias is not None:
        body["requestPathAlias"] = (args.path_alias if args.path_alias.startswith("/")
                                    else f"/{args.path_alias}")
    if args.backend_url is not None:
        system_domain, protocol, target_path = parse_backend_url(args.backend_url)
        body["systemDomains"] = [{"address": system_domain}]
        body["outboundRequestTargetPath"] = target_path
        body["outboundTransportProtocol"] = protocol
    if args.methods is not None:
        body["supportedHttpMethods"] = [m.strip().lower() for m in args.methods.split(",")]
    if args.ssl is not None:
        body["inboundSslRequired"] = args.ssl
    if args.auth is not None:
        body["requestAuthenticationType"] = args.auth
        body["apiKeyValueLocations"] = ["request-parameters"]
        body["apiKeyValueLocationKey"] = args.key_param
    if args.backend_auth_type:
        password = args.backend_password or os.environ.get("MASHERY_BACKEND_PASSWORD")
        try:
            body["systemDomainAuthentication"] = build_system_domain_auth(
                args.backend_auth_type, args.backend_user, password)
        except ValueError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)
    if args.clear_backend_auth:
        body["systemDomainAuthentication"] = None

    # Call Transformation (processor) + connect/response timeouts (shared logic).
    try:
        apply_processor_args(args, body)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    if not body:
        print("ERROR: nothing to update — pass at least one change flag "
              "(--name, --backend-url, --path-alias, --methods, --auth, --ssl/--no-ssl, "
              "--backend-auth-type, --clear-backend-auth, --sdk-processors, "
              "--processor-adapter, --clear-processor, --connect-timeout, --response-timeout).",
              file=sys.stderr)
        sys.exit(1)

    load_env()
    token = get_token()

    path = f"services/{args.service_id}/endpoints/{args.endpoint_id}"
    changed = sorted(body.keys())
    print(f"Updating endpoint {args.endpoint_id} on service {args.service_id}...")
    print(f"  Fields changed: {', '.join(changed)}")
    if args.backend_auth_type:
        print(f"  Backend auth:   {args.backend_auth_type} (user {args.backend_user!r})")
    if args.clear_backend_auth:
        print(f"  Backend auth:   cleared")
    print()

    mashery_put(path, token, body)

    # PUT response is a minimal projection; read back with explicit fields.
    updated = mashery_get(f"{path}?fields={ENDPOINT_FIELDS}", token)
    if isinstance(updated.get("systemDomainAuthentication"), dict):
        updated = dict(updated)
        updated["systemDomainAuthentication"] = mask_system_domain_auth(
            updated["systemDomainAuthentication"])

    print("Endpoint updated successfully!")
    print(f"  Endpoint ID:  {updated.get('id')}")
    print(f"  Name:         {updated.get('name')}")
    print(f"  Path alias:   {updated.get('requestPathAlias')}")
    print(f"  Auth:         {updated.get('requestAuthenticationType')}")
    sda = updated.get("systemDomainAuthentication")
    print(f"  Backend auth: {sda if sda else 'none'}")
    print(f"\nFull endpoint:")
    print_json(updated)


if __name__ == "__main__":
    main()
