#!/usr/bin/env python3
"""
mashery-package-plan-create.py — Create a Package and Plan in Mashery, linked to a Service+Endpoint.

Usage:
    python3 mashery-package-plan-create.py \
        --service-id <serviceId> \
        --endpoint-id <endpointId> \
        --package-name "My API Package" \
        --plan-name "Basic" \
        [--qps 10] \
        [--rate-limit 1000] \
        [--rate-period day] \
        [--max-keys 2] \
        [--notify-period day] \
        [--app-name "My App"] \
        [--provision-key]

Options:
    --service-id     Service ID to associate with the plan (required)
    --endpoint-id    Endpoint ID to associate with the plan (required)
    --package-name   Name for the new Package (required)
    --plan-name      Name for the new Plan (required)
    --qps            Queries per second limit (default: 10, 0=unlimited)
    --rate-limit     Total calls per rate period (default: 1000, 0=unlimited)
    --rate-period    Rate limit period: minute|hour|day|month (default: day)
    --max-keys       Max keys a developer can create (default: 2)
    --notify-period  Package quota-notification period (default: day).
                     Must be minute|hour|day|week|month — "never" is REJECTED by
                     the V3 API (HTTP 400 "Property 'notifyDeveloperPeriod' is
                     required."). The near/over-quota notify flags stay off, so
                     this period only matters if those are later enabled.
    --app-name       Application to own the provisioned key (default:
                     "<package-name> App"; reused if it already exists).
    --provision-key  Also provision an API key for your own account (flag)

Output: Package ID, Plan ID, and optionally a test API key + secret.

Key provisioning note: V3 package keys are Application-scoped. With
--provision-key, the tool ensures the member owns an Application, then creates
the key under POST /applications/{appId}/packageKeys. (Creating a key directly
under .../members/{id}/keys returns 404 — that route is not supported.)
"""

import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mashery_paths import (load_env, get_mashery_credentials, get_token,
                            mashery_get_all, mashery_post, print_json)


def get_member_id(token, username):
    """Fetch the member ID for the current user's email address."""
    # V3 /members returns a bare JSON array; mashery_get_all normalizes it.
    items = mashery_get_all("members", token,
                            params={"filter": f"username:{username}", "fields": "id,username"})
    if not items:
        # Try without filter as fallback
        items = mashery_get_all("members", token, params={"fields": "id,username"})
    matches = [m for m in items if m.get("username", "").lower() == username.lower()]
    if matches:
        return matches[0]["id"]
    return items[0]["id"] if items else None


def get_or_create_application(token, member_id, username, app_name):
    """Return an Application id for the member, reusing one by name if present.

    Package keys in V3 are Application-scoped — you cannot create a key directly
    under a member/plan (POST .../members/{id}/keys returns 404). The working
    flow is: ensure the member owns an Application, then create the key under
    that Application (see provision_key)."""
    apps = mashery_get_all(f"members/{member_id}/applications", token,
                           params={"fields": "id,name,status"})
    for a in apps:
        if a.get("name", "").lower() == app_name.lower():
            return a["id"], False, a.get("status")
    created = mashery_post(f"members/{member_id}/applications", token,
                           {"name": app_name, "username": username})
    return created["id"], True, created.get("status")


def provision_key(token, member_id, app_id, package_id, plan_id):
    """Create an active package key under the Application, tied to package+plan.

    V3 route: POST /applications/{appId}/packageKeys with package/plan refs.
    Empty apikey/secret tell Mashery to auto-generate them. Returns the result
    dict (with apikey + secret)."""
    key_body = {
        "apikey": "", "secret": "", "status": "active", "limits": [],
        "package": {"id": package_id},
        "plan": {"id": plan_id},
    }
    return mashery_post(f"applications/{app_id}/packageKeys", token, key_body)


def main():
    parser = argparse.ArgumentParser(
        description="Create a Mashery Package + Plan linked to a Service/Endpoint"
    )
    parser.add_argument("--service-id", required=True, help="Service ID")
    parser.add_argument("--endpoint-id", required=True, help="Endpoint ID")
    parser.add_argument("--package-name", required=True, help="Package name")
    parser.add_argument("--plan-name", required=True, help="Plan name")
    parser.add_argument("--qps", type=int, default=10, help="QPS limit (default: 10)")
    parser.add_argument("--rate-limit", type=int, default=1000, help="Rate limit (default: 1000)")
    parser.add_argument("--rate-period", default="day",
                        choices=["minute", "hour", "day", "month"],
                        help="Rate limit period (default: day)")
    parser.add_argument("--max-keys", type=int, default=2, help="Max keys per developer (default: 2)")
    parser.add_argument("--notify-period", default="day",
                        choices=["minute", "hour", "day", "week", "month"],
                        help="Package quota-notification period (default: day). "
                             "'never' is NOT accepted by the V3 API.")
    parser.add_argument("--app-name", default="",
                        help="Application name to own the provisioned key "
                             "(default: '<package-name> App'). Reused if it already exists.")
    parser.add_argument("--provision-key", action="store_true",
                        help="Also provision an API key for your own account")
    args = parser.parse_args()

    load_env()
    creds = get_mashery_credentials()
    token = get_token()

    # --- Create Package ---
    print(f"Creating Package: {args.package_name!r}...")
    # notifyDeveloperPeriod must be a real period (minute|hour|day|week|month).
    # "never" is rejected by the V3 API with a misleading
    #   400 "Property 'notifyDeveloperPeriod' is required."
    # (Mashery reports an invalid enum value as if the field were missing.)
    # The near/over-quota notify flags are off, so the period is inert unless
    # those are later enabled; "day" is the area's own default.
    package_body = {
        "name": args.package_name,
        "description": f"Package for {args.package_name}",
        "notifyDeveloperPeriod": args.notify_period,
        "notifyDeveloperNearQuota": False,
        "notifyDeveloperOverQuota": False,
        "notifyDeveloperOfKeyChanges": False,
        "generateSecrets": True,
        "sharedSecretLength": 10,
    }
    package = mashery_post("packages", token, package_body)
    package_id = package["id"]
    print(f"  Package ID: {package_id}")

    # --- Create Plan ---
    print(f"\nCreating Plan: {args.plan_name!r}...")
    plan_body = {
        "name": args.plan_name,
        "description": f"{args.plan_name} access plan",
        "selfServiceKeyProvisioningEnabled": False,
        "adminKeyProvisioningEnabled": True,
        "numKeysBeforeReview": 1,
        "maxNumKeysAllowed": args.max_keys,
        "qpsLimitCeiling": args.qps,
        "rateLimitCeiling": args.rate_limit,
        "rateLimitPeriod": args.rate_period,
        "responseFilterFields": "",
        "notes": "",
        "services": [
            {
                "id": args.service_id,
                "endpoints": [
                    {"id": args.endpoint_id}
                ]
            }
        ]
    }
    plan = mashery_post(f"packages/{package_id}/plans", token, plan_body)
    plan_id = plan["id"]
    print(f"  Plan ID: {plan_id}")
    print(f"  QPS Limit: {args.qps}")
    print(f"  Rate Limit: {args.rate_limit}/{args.rate_period}")

    # --- Optionally provision a key ---
    # Keys are Application-scoped in V3: ensure the member owns an Application,
    # then create the key under it (POST /applications/{appId}/packageKeys).
    # The older POST .../members/{id}/keys path returns 404 — keys can't be
    # created directly under a member/plan.
    api_key = None
    api_secret = None
    if args.provision_key:
        print(f"\nLooking up member account for {creds['username']}...")
        member_id = get_member_id(token, creds["username"])
        if not member_id:
            print(f"  WARNING: Could not find member ID for {creds['username']}. "
                  "Skipping key provisioning.")
            print("  You can provision a key manually in Mashery Control Center.")
        else:
            print(f"  Member ID: {member_id}")
            app_name = args.app_name or f"{args.package_name} App"
            app_id, created, app_status = get_or_create_application(
                token, member_id, creds["username"], app_name)
            print(f"  Application: {app_name!r} ({'created' if created else 'reused'}) "
                  f"— {app_id}  [status: {app_status}]")
            print(f"\nProvisioning API key...")
            key_result = provision_key(token, member_id, app_id, package_id, plan_id)
            api_key = key_result.get("apikey")
            api_secret = key_result.get("secret")
            key_status = key_result.get("status")
            print(f"  API Key:    {api_key}")
            if api_secret:
                print(f"  API Secret: {api_secret}")
            print(f"  Key status: {key_status}")

            # The V3 API creates applications in 'draft' and cannot activate them
            # (PUT status->active returns 400 "Please choose a different value").
            # In this area ALL applications read as 'draft' — including ones with
            # working keys — so draft is expected and the key's own status governs
            # access. Surface this so a draft app isn't mistaken for the blocker.
            if (app_status or "").lower() == "draft":
                print("\n  NOTE: the Application is in 'draft' status. The V3 API cannot")
                print("  activate an application, and in this area every application reads")
                print("  as 'draft' (including ones with working keys), so this is expected.")
                print("  The key's own status above ('active') is what governs gateway access.")
                print("  If the gateway still rejects the key, activate the Application in")
                print("  the Mashery Control Center UI.")

    # --- Summary ---
    print(f"\n{'='*60}")
    print(f"Setup Complete!")
    print(f"{'='*60}")
    print(f"  Package ID:   {package_id}")
    print(f"  Package Name: {args.package_name}")
    print(f"  Plan ID:      {plan_id}")
    print(f"  Plan Name:    {args.plan_name}")
    print(f"  Service ID:   {args.service_id}")
    print(f"  Endpoint ID:  {args.endpoint_id}")
    if api_key:
        traffic_domain = creds.get("traffic_domain", "<MASHERY_TRAFFIC_DOMAIN>")
        print(f"\n  Test API Key:    {api_key}")
        if api_secret:
            print(f"  Test API Secret: {api_secret}")
        print(f"\n  Test your API:")
        print(f'    curl "https://{traffic_domain}/<path_alias>?api_key={api_key}"')
    else:
        print(f"\n  Next: Go to Mashery Control Center to provision API keys,")
        print(f"  or re-run with --provision-key flag.")


if __name__ == "__main__":
    main()
