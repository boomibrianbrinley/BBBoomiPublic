# Authentication

## Overview

Mashery V3 uses **OAuth 2.0 Resource Owner Password Credentials** flow (`grant_type=password`). You exchange your Mashery developer credentials plus your application's API key and secret for a short-lived bearer token. That token is then passed on all V3 REST API calls.

Tokens expire in **1 hour** (3600 seconds). The tools in this skill handle token acquisition automatically on each invocation.

---

## Getting Mashery V3 API Credentials (first time / "where do I get these?")

**The key thing to understand:** the token request needs **two separate
credential pairs from two different places** — and a Boomi platform/SSO login
gives you neither by default:

1. **An API Key + Secret** (the client credentials, `Authorization: Basic`) —
   issued from the **developer portal** (`developer.mashery.com → My Account`).
2. **An Area account login** (the `password` grant: username + password) — a user
   that exists in your CAM **Area**.

Plus your **Area UUID** as the scope. Get all three and the tools will authenticate.

### A) API Key + Secret → from the developer portal (`MASHERY_API_KEY` / `MASHERY_API_SECRET`)

1. Go to **`https://developer.mashery.com`** and **sign in** (top-right).
2. Open **My Account** → the **Keys** tab (the "Key Activity" page; URL looks like
   `developer.mashery.com/key/key-activity/...`). Tabs there are **Keys |
   Applications | Manage Account**.
3. Find the key named **"Mashery API: V2 + V3"** (it belongs to one of your
   registered **Applications**, e.g. `yohanes-cam`). Copy:
   - **Key**  → `MASHERY_API_KEY`
   - **Secret** → `MASHERY_API_SECRET`
4. Don't have one yet? Use the **Applications** tab to register an application,
   then request a **Mashery API (V2 + V3)** key for it.

> The Key Activity page also shows that key's **rate limits** — by default
> **2 calls/sec, 5,000/day** (which is why the tools self-throttle). If Boomi
> Support raises them, reflect it with `MASHERY_API_QPS` / `MASHERY_API_DAILY`.

### B) Area account → for the password grant (`MASHERY_USERNAME` / `MASHERY_PASSWORD`)

This is a user that exists in your CAM **Area** (distinct from the portal key
above). For automation, use a dedicated **service account** an **Area
Administrator** creates in the Control Center:

1. Log into the **Control Center** (Dashboard) for your area.
2. Go to **Manage → Users**.
3. **Create a new user** — use a name that signals it's non-human, e.g.
   `svcusr` / `service_account` / `svcuserboomiapj`.
4. Give it the **Area Administrator** role **and** enable the **Service User** flag.

Use that account's login as `MASHERY_USERNAME` / `MASHERY_PASSWORD`.

> **Expected, not a bug:** a Service User **cannot log into the Control Center**.
> Signing in with the service-account credentials shows: *"There is a problem with
> your permissions. Please have an administrator re-grant your admin permission."*
> That's normal for a `Service User` — it's an API-only account. Use a *separate*
> human Area-Admin account for any Control Center UI work.

### Mapping to your `.env`

- `MASHERY_API_KEY` / `MASHERY_API_SECRET` → the **"Mashery API: V2 + V3"** key's
  **Key** / **Secret** from `developer.mashery.com → My Account → Keys` (source A).
  These are the client credentials in the `Authorization: Basic` header.
- `MASHERY_USERNAME` / `MASHERY_PASSWORD` → the **Area account / service account**
  login (source B), used as the `password` grant.
- `MASHERY_AREA_UUID` → your area's UUID (see "Finding Your Area UUID").

### Reference links

- **Boomi Community — How to use V2/V3 API in Boomi Cloud API Management:**
  <https://community.boomi.com/s/article/How-to-use-V2-V3-API-in-Boomi-Cloud-API-Management>
- **Register a Mashery member account (developer portal):**
  <https://support.mashery.com/member/register>

If you can't create the Area account yourself, ask whoever administers your CAM
area to provision a service account (steps in B) for you.

---

## Required Credentials

| Env Var | Description | Where to Find It |
|---------|-------------|-----------------|
| `MASHERY_API_KEY` | API Key — client id (`Authorization: Basic`) | **developer.mashery.com → My Account → Keys** → "Mashery API: V2 + V3" key → **Key** field |
| `MASHERY_API_SECRET` | API Key **secret** — client secret | Same Key Activity page → **Secret** field |
| `MASHERY_USERNAME` | Area account login (the `password` grant) | The Area user / service account (Manage → Users) |
| `MASHERY_PASSWORD` | Area account password | Set when the Area user / service account was created |
| `MASHERY_AREA_UUID` | Your area/tenant UUID | Control Center URL (see below) |
| `MASHERY_API_URL` | Mashery API base URL | `https://api.mashery.com` (use this default) |
| `MASHERY_TRAFFIC_DOMAIN` | Public gateway hostname | Manage → Areas in Control Center |

> `MASHERY_API_QPS` / `MASHERY_API_DAILY` are optional overrides — only set them if
> Boomi Support has raised your key's rate limit above the 2/sec, 5,000/day default.

### Copy-paste `.env` block

Add these to your project `.env` (the same file the Boomi vars live in) and fill
in the values from the steps above:

```dotenv
# --- Boomi Cloud API Management (Mashery V3) ---
MASHERY_API_KEY=          # developer.mashery.com → My Account → Keys → "Mashery API: V2 + V3" → Key
MASHERY_API_SECRET=       # ...same page → Secret
MASHERY_USERNAME=         # Area account / service-account login (e.g. svcuserboomiapj)
MASHERY_PASSWORD=         # that account's password
MASHERY_AREA_UUID=        # area UUID from the Control Center URL
MASHERY_API_URL=https://api.mashery.com
MASHERY_TRAFFIC_DOMAIN=   # e.g. yourcompany.api.mashery.com
# Optional — only if Boomi Support raised your key's quota:
# MASHERY_API_QPS=10
# MASHERY_API_DAILY=50000
```

After filling it in, verify with `python3 ${CLAUDE_SKILL_DIR}/tools/mashery-auth.py`.

---

## Finding Your Area UUID

The Area UUID appears in the Mashery Control Center URL when you are logged in:

```
https://developer.mashery.com/controlcenter/areas/XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX/dashboard
                                                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                                   Copy this entire segment — it is MASHERY_AREA_UUID
```

You can also find it via API (requires a global admin token without a scope — uncommon):
```
GET https://api.mashery.com/v3/rest/areas
Authorization: Bearer <global_token>
```

---

## Issuing the API Key (`MASHERY_API_KEY` + `MASHERY_API_SECRET`)

The API key/secret come from the **developer portal**, under your own account —
**not** from the Area service account (which only supplies the username/password).

1. Sign into **`https://developer.mashery.com`** (top-right).
2. Open **My Account** → the **Keys** tab ("Key Activity" page; tabs are
   **Keys | Applications | Manage Account**).
3. Locate the key labelled **"Mashery API: V2 + V3"** (under one of your
   registered **Applications**). Copy **Key** → `MASHERY_API_KEY` and
   **Secret** → `MASHERY_API_SECRET`.
4. No such key yet? Use the **Applications** tab to register an application, then
   request a **Mashery API (V2 + V3)** key for it.

For the exact, current flow for your area, see the Boomi Community article:
<https://community.boomi.com/s/article/How-to-use-V2-V3-API-in-Boomi-Cloud-API-Management>

The API key/secret identify the **client** (the `Authorization: Basic` header); the
username/password identify the **account** (the `password` grant). They are two
different credential pairs — you need both.

---

## Token Request

```
POST https://api.mashery.com/v3/token
Content-Type: application/x-www-form-urlencoded
Authorization: Basic base64(<MASHERY_API_KEY>:<MASHERY_API_SECRET>)

grant_type=password&username=<MASHERY_USERNAME>&password=<MASHERY_PASSWORD>&scope=<MASHERY_AREA_UUID>
```

The `Authorization: Basic` header is Base64 encoding of `<apikey>:<apisecret>` (colon-separated).

---

## Token Response

```json
{
  "access_token": "rahvz8x3svu23gw7t3c7bgz4",
  "token_type": "bearer",
  "expires_in": 3600,
  "refresh_token": "qm5n8k2p7r4t9w6x3z8c5v2b",
  "scope": "<area_uuid>",
  "token_context": "mashery_api"
}
```

> **Note:** Mashery V3 access/refresh tokens are short **opaque strings** (~24 chars), **not** JWTs — do not expect a decodable `eyJ...` value. `token_type` is returned lowercase (`bearer`).

Use `access_token` as the bearer token on subsequent API calls:
```
Authorization: Bearer <access_token>
```

---

## Using the Auth Tool

```bash
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-auth.py
```

Output: prints the bearer token and an example curl command. If authentication fails, it prints the HTTP status and error body.

All other tools call `get_token()` from `mashery_paths.py` internally — you do not need to manually pass tokens between tool invocations.

---

## Common Auth Errors

### 400 Bad Request — `invalid_client`
```json
{"error": "invalid_client", "error_description": "..."}
```
**Cause**: Wrong `MASHERY_API_KEY` or `MASHERY_API_SECRET`.  
**Fix**: Re-issue application keys from Mashery Control Center → My Account → Issue Developer Keys.

### 401 Unauthorized on token endpoint
**Cause**: Wrong `MASHERY_USERNAME` or `MASHERY_PASSWORD`, or account locked.  
**Fix**: Try logging into Mashery Control Center manually first to confirm credentials.

### 400 — `invalid_grant`
**Cause**: Wrong `MASHERY_AREA_UUID` passed as the scope.  
**Fix**: Copy the UUID directly from the Control Center URL while logged in.

### Token works but REST calls return 403
**Cause**: The account behind the token lacks admin rights in the area — e.g. the
service account is missing the **Area Administrator** role or the **Service User**
flag was not enabled.
**Fix**: Have an Area Administrator confirm the service account has the **Area
Administrator** role *and* the **Service User** flag set (Manage → Users), then
re-issue the V3 API key if needed.

### Service account can't log into the Control Center
**Cause**: This is expected — a **Service User** is API-only and cannot sign into
the Control Center UI. The message *"There is a problem with your permissions…"* is
normal.
**Fix**: Nothing to fix for API use. For UI work, use a separate human Area-Admin
account.

---

## Token Caching (Optional Pattern)

The current tools re-authenticate on each invocation for simplicity and reliability. For automation scripts making many sequential calls, you can cache the token:

```python
# Cache location pattern
/tmp/mashery_token_<area_uuid_prefix>.json

# Store: {"access_token": "...", "expires_at": <unix_timestamp>}
# Read: check expires_at > time.time() before using cached token
```

This avoids hitting the token endpoint repeatedly but adds complexity. Only implement if you are making more than ~10 sequential tool calls in an automated script.
