# CAM Thinking — Core Mental Models

Read this before doing any Boomi Cloud API Management (CAM) work. These mental models prevent the most common mistakes.

---

## What Boomi Cloud API Management Is

Boomi Cloud API Management (CAM) is the **Mashery platform**, acquired by Boomi from TIBCO. It is a full-lifecycle API gateway that:

- Acts as a **reverse proxy** — clients call Mashery, Mashery calls your backend
- Enforces **authentication** (API keys, OAuth 2.0)
- Applies **rate limiting and throttling** before traffic reaches your backend
- Routes requests to **backend systems** (e.g., Boomi Integration listeners)
- Provides a **developer portal** for key self-service and documentation

**Critical**: Mashery is a **separate product** from Boomi Integration. They integrate by pointing a Mashery Endpoint at the URL of a Boomi web service listener. The two products do not share any infrastructure — Mashery is a cloud gateway, your Atom is a runtime.

---

## The Gateway Mental Model

```
Developer App
    │  GET https://yourcompany.api.mashery.com/orders?api_key=abc123
    ▼
Mashery Traffic Manager  ← the public-facing gateway
    │  validates api_key → checks rate limits → logs the call
    │  GET http://your-atom-host:9090/ws/rest/orders
    ▼
Boomi Atom (Web Services Server listener)
    │  executes the integration process
    ▼
Response flows back through Mashery to the developer
```

The developer never sees your Atom's hostname or internal URL. Mashery is the only public face.

---

## The Resource Hierarchy (Memorize This)

```
Area  (your org/tenant in Mashery — has a UUID)
│
├── Service  (one logical API — e.g., "Orders API")
│   └── Endpoint  (one routing rule: public path → backend URL)
│       └── Method  (optional per-HTTP-method overrides)
│
├── Package  (a distributable bundle visible in the developer portal)
│   └── Plan  (an access tier: rate limits + which Service/Endpoints are accessible)
│       └── Key  (a developer's API key, tied to a Plan)
│
└── Application  (a developer's registered app — holds Keys)
```

**The two sides are independent** — you can have a Service and Endpoint without any Package or Plan (it just won't be accessible). You connect them by adding the Service+Endpoint to a Plan's `services` array.

---

## Terminology That Trips People Up

| Term | What It Actually Means |
|------|----------------------|
| **Area** | Your Mashery tenant/org. Identified by a UUID. Everything belongs to an Area. |
| **Service** | The API definition object — NOT an endpoint or a URL. Think of it as the parent container. |
| **Endpoint** | A single routing rule: maps one public path to one backend URL. A Service can have multiple Endpoints. |
| **Traffic Manager Domain** | The Mashery-hosted hostname developers call (e.g., `yourcompany.api.mashery.com`). You do not control this DNS — Mashery does. |
| **System Domain** | YOUR backend hostname — the Atom's host + port. This is where Mashery forwards traffic to. |
| **Request Path Alias** | The path clients append to the Traffic Manager Domain (e.g., `/orders`). This is what you set on the Endpoint. |
| **Package** | A developer-portal bundle. Does not do anything by itself — access comes from the Plan inside it. |
| **Plan** | The actual access tier. Defines rate limits AND which Service+Endpoints are accessible. |
| **Key** | The credential a developer passes. Tied to a specific Plan. |

---

## The ID Rule: Always Use UUIDs

Mashery API responses include both `id` (UUID string) and `name` fields. **Always use `id`** when referencing resources in subsequent API calls:

- `name` is display-only and is NOT accepted as a path parameter
- `name` is NOT guaranteed unique across an area (two services can have similar names)
- `id` is the UUID — save it immediately when a resource is created

Example: after creating a Service, save its `id` as `serviceId`. You need this exact UUID to create Endpoints and link Plans.

---

## The Two-Side Mental Model

When setting up a Mashery API, there are always two things to configure:

**Side 1 — The routing (Service + Endpoint)**:
- What the gateway exposes publicly
- Where it forwards traffic to
- How it authenticates clients

**Side 2 — The access control (Package + Plan + Key)**:
- Who can call the API
- At what rate
- With what credential

Neither side knows about the other until you link them: you connect a Plan to a Service+Endpoint via the `services` array in the Plan creation body.

---

## Token Scope = Area UUID

The Mashery V3 OAuth token is **scoped to a specific Area UUID**. This is a common source of confusion:

- When you authenticate, you pass `scope=<MASHERY_AREA_UUID>` in the token request
- The token only works for API calls within that Area
- If you have multiple Mashery Areas (orgs), you need separate tokens (and separate `.env` configs) for each

---

## Boomi Integration + Mashery: What Each Product Configures

**In Boomi Integration (using the `boomi-integration` skill)**:
- A process with a **Web Services Server (WSS)** start shape
- Deployed to an Atom on a specific port (default 9090)
- The listener path is typically `/ws/rest/<service-name>`

**In Mashery (this skill)**:
- A **Service** (the API definition)
- An **Endpoint** where:
  - `systemDomains` = Atom hostname:port
  - `outboundRequestTargetPath` = `/ws/rest/<service-name>`
  - `requestPathAlias` = the public path clients call

Build the Boomi listener first. You cannot configure the Mashery Endpoint without knowing the listener URL.

---

## Common Mental Model Mistakes

**Mistake 1: Thinking Service = Endpoint**
A Service is the container. An Endpoint is the routing rule inside it. You always need both.

**Mistake 2: Forgetting to link the Plan to the Service+Endpoint**
A Package and Plan do nothing until you add the Service+Endpoint to the Plan's `services` array. This is done during Plan creation.

**Mistake 3: Using Service name instead of Service ID**
Always save and use the UUID `id` field. The `name` field is not accepted in API paths.

**Mistake 4: Testing before the key is associated with the right Plan**
An API key is only valid for the Plan it was created under. That Plan must include the Service+Endpoint you are calling.

**Mistake 5: Atom not accessible from the Mashery cloud**
Mashery's cloud infrastructure must be able to reach your Atom's host and port. If the Atom is behind a firewall or on a private network without a public IP, the gateway will return 503.
