# Mashery Endpoints

## What is an Endpoint?

An **Endpoint** defines the routing rule between a public Mashery URL and your backend service. For Boomi Integration, one Endpoint = one Boomi web service listener path.

An Endpoint specifies:
- **Inbound**: the public path alias clients call (e.g., `/orders`)
- **Backend**: the Atom hostname + port and the Boomi listener path
- **Auth**: how client credentials are validated (API key, API key + secret, OAuth)
- **Protocol**: HTTP vs HTTPS for backend calls

---

## Create an Endpoint

### Using the CLI tool

```bash
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-create.py \
  --service-id <serviceId> \
  --name "Default" \
  --backend-url "http://atom-host:9090/ws/rest/orders" \
  --path-alias "/orders"
```

Optional flags:
- `--auth apiKeyAndSecret_SHA256` — require an API key **plus** an HMAC-SHA256
  signed secret (stronger than a bare key)
- `--key-param X-Api-Key` — use a header instead of query parameter
- `--methods get,post` — restrict to specific HTTP methods
- `--ssl` — require HTTPS on inbound

### Using the API directly

```
POST https://api.mashery.com/v3/rest/services/{serviceId}/endpoints
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Default",
  "requestAuthenticationType": "apiKey",
  "apiKeyValueLocations": ["request-parameters"],
  "apiKeyValueLocationKey": "api_key",
  "supportedHttpMethods": ["get", "post", "put", "delete"],
  "requestPathAlias": "/orders",
  "publicDomains": [{"address": "mycompany.api.mashery.com"}],
  "systemDomains": [{"address": "atom-hostname:9090"}],
  "outboundRequestTargetPath": "/ws/rest/orders",
  "outboundTransportProtocol": "http",
  "inboundSslRequired": false,
  "useSystemDomainAsTarget": false
}
```

---

## Required Fields

| Field | Type | Notes |
|-------|------|-------|
| `name` | string | Unique within the service |
| `requestAuthenticationType` | string | `"apiKey"`, `"apiKeyAndSecret_SHA256"`, `"oauth"` (if enabled), or `"custom"` (needs adapter). **No `"none"`** — see "No unauthenticated endpoints" below. |
| `systemDomains` | array | Backend host(s): `[{"address": "host:port"}]` |
| `publicDomains` | array | Inbound host: `[{"address": "<MASHERY_TRAFFIC_DOMAIN>"}]` |
| `requestPathAlias` | string | Public path (e.g., `"/orders"`) — must start with `/` |
| `outboundRequestTargetPath` | string | Backend path (e.g., `"/ws/rest/orders"`) |

---

## Public Domain Whitelist

The hosts you put in `publicDomains` and `systemDomains` are not free-form —
each must already be registered in the **area's public-domain whitelist**.
This is the area-level registry of allowed hostnames (your Traffic Manager
domain plus any backend hosts). If you try to use a host that isn't whitelisted,
the endpoint create/update is rejected. So when onboarding a brand-new public
domain (e.g. a freshly-issued Let's Encrypt cert domain), register it first.

```bash
# See what's already whitelisted
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-domain-list.py

# Register a new public domain (then use it as a publicDomains address)
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-domain-create.py \
  --domain api.example.com --description "LE public domain"
```

The whitelist resource is `GET/POST /v3/rest/domains` (a bare JSON array of
`{id, domain, status, message, description}`). Notes on the lifecycle:

- **Create is supported via the V3 API** (`POST /domains` → 200, the response
  `message` confirms "…has been whitelisted").
- **Delete is NOT** — `DELETE /domains/{id}` returns **403 Forbidden** for the
  standard service account; removal is **Control Center UI-only**.
- **Update is description-only** — `domain` and `status` are immutable; sending
  them in a `PUT` returns `400 "Property '...' should not be part of request
  payload."`

Because a registration can't be undone via the API, double-check the hostname
before creating.

---

## Full Field Reference

```json
{
  "name": "Default",

  // --- Inbound (client → Mashery) ---
  "requestPathAlias": "/orders",
  "publicDomains": [{"address": "mycompany.api.mashery.com"}],
  "inboundSslRequired": false,
  "supportedHttpMethods": ["get","post","put","delete","patch","head","options"],

  // --- Authentication ---
  "requestAuthenticationType": "apiKey",
  "apiKeyValueLocations": ["request-parameters"],   // or "request-headers"
  "apiKeyValueLocationKey": "api_key",              // query param or header name

  // --- Outbound (Mashery → backend) ---
  "systemDomains": [{"address": "atom-hostname:9090"}],
  "outboundRequestTargetPath": "/ws/rest/orders",
  "outboundRequestTargetQueryParameters": "",
  "outboundTransportProtocol": "http",              // "http" or "https"
  "useSystemDomainAsTarget": false,

  // --- Traffic Control ---
  "trafficManagerDomain": "mycompany.api.mashery.com",
  "rateLimitHeadersEnabled": false,
  "forwardedHeaders": [],
  "returnedHeaders": [],

  // --- CORS ---
  "cors": {
    "allDomainsEnabled": false,
    "subDomainMatchingAllowed": false,
    "cookiesAllowed": false,
    "headersAllowed": "",
    "headersExposed": "",
    "maxAge": 0
  }
}
```

---

## Authentication Type Options

| Value | Description |
|-------|-------------|
| `apiKey` | Client passes an API key (query param or header) |
| `apiKeyAndSecret_SHA256` | Client passes API key + HMAC-SHA256 signed secret |
| `oauth` | OAuth 2.0 bearer token — only valid if OAuth is enabled for the service (else `400`) |
| `custom` | A named custom auth adapter — requires `customRequestAuthenticationAdapter` |

For Boomi integration demos and internal APIs, `"apiKey"` with `"request-parameters"` (`?api_key=...`) is the simplest to implement and test.

### No unauthenticated ("none"/open) endpoints

Mashery V3 has **no unauthenticated endpoint type** — `requestAuthenticationType`
must be one of the four values above. There is a trap: the field's parser maps
**any unrecognized string** (`"none"`, `"open"`, `"public"`, …) to `custom`, so
the create fails with a misleading

```
400 "Property 'customRequestAuthenticationAdapter' is required if
     requestAuthenticationType is custom."
```

And **omitting** the field is not "open" either — the area defaults it to
`apiKey`. So a truly keyless/public endpoint cannot be created through the V3
API; configure it in the Control Center UI (or via a custom no-op auth adapter).
`mashery-endpoint-create.py --auth none` therefore fails fast with this
explanation instead of sending a request that 400s.

---

## API Key Location Options

```json
"apiKeyValueLocations": ["request-parameters"]   // ?api_key=<value>
"apiKeyValueLocations": ["request-headers"]       // X-Api-Key: <value> (or custom header)
"apiKeyValueLocations": ["request-body"]          // key in POST body (rarely used)
```

---

## Boomi-Specific Backend URL Construction

The full backend URL Mashery calls is constructed as:
```
<outboundTransportProtocol>://<systemDomains[0].address><outboundRequestTargetPath>
```

For a Boomi Web Services Server listener, your `SERVER_BASE_URL` in `.env` (`http://W10-B13QL24:9090`) maps to:

```python
from urllib.parse import urlparse
parsed = urlparse(SERVER_BASE_URL)
system_domain = f"{parsed.hostname}:{parsed.port}"  # "W10-B13QL24:9090"
protocol = parsed.scheme                             # "http"
# outboundRequestTargetPath comes from the listener configuration, e.g., "/ws/rest/orders"
```

The `mashery-endpoint-create.py` tool handles this parsing automatically when you pass `--backend-url`.

---

## Backend Authentication (systemDomainAuthentication)

If your backend (e.g. a secured Boomi listener) requires credentials, set
`systemDomainAuthentication` — the **outbound** auth Mashery presents when it
calls the system domain. This is independent of `requestAuthenticationType`
(the **inbound** auth clients present to Mashery).

```json
"systemDomainAuthentication": {
  "type": "httpBasic",
  "username": "boomiuser",
  "password": "s3cret"
}
```

With the CLI tools (HTTP Basic shown; `--system-domain-auth basic` is an alias):

```bash
# On create
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-create.py \
  --service-id <id> --name "Default" \
  --backend-url "https://atom:9090/ws/rest/orders" --path-alias "/orders" \
  --backend-auth-type httpBasic --backend-user boomiuser
# password: pass --backend-password, or (preferred) set MASHERY_BACKEND_PASSWORD
# in the environment so it never appears in the process list / shell history.

# On an existing endpoint
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-update.py \
  --service-id <id> --endpoint-id <eid> \
  --backend-auth-type httpBasic --backend-user boomiuser   # MASHERY_BACKEND_PASSWORD

# Remove backend auth
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-update.py \
  --service-id <id> --endpoint-id <eid> --clear-backend-auth
```

Notes (verified live):
- The field accepts `httpBasic` (this skill models that — the common Boomi case);
  the API also supports `clientSslCertificate` / `custom`, not modeled here.
- The password is **stored and read back in clear text** by the API — the tools
  mask it to `***` in their own output, but treat the value as a secret.
- **Reading it back requires an explicit `fields` list** — see the gotcha under
  "Updating an Endpoint".

---

## Response

```json
{
  "id": "endpoint-uuid-here",
  "name": "Default",
  "requestPathAlias": "/orders",
  "systemDomains": [{"address": "atom-hostname:9090"}],
  "publicDomains": [{"address": "mycompany.api.mashery.com"}],
  "outboundRequestTargetPath": "/ws/rest/orders",
  "outboundTransportProtocol": "http",
  "requestAuthenticationType": "apiKey",
  "created": "2024-01-01T00:00:00.000+0000",
  "updated": "2024-01-01T00:00:00.000+0000"
}
```

**Save the `id` — this is the `endpointId` needed when creating Plans.**

---

## List Endpoints for a Service

```
GET https://api.mashery.com/v3/rest/services/{serviceId}/endpoints
Authorization: Bearer <token>
```

---

## Updating an Endpoint

```
PUT https://api.mashery.com/v3/rest/services/{serviceId}/endpoints/{endpointId}
Authorization: Bearer <token>
Content-Type: application/json

{ ...only the fields you want to change... }
```

**Partial PUT MERGES (verified live).** You only need to send the fields you are
changing — everything else is preserved. (E.g. `PUT {"name": "New"}` keeps
`requestPathAlias`, `systemDomains`, `systemDomainAuthentication`, etc.) To
remove backend auth, send `"systemDomainAuthentication": null`.

> **Gotcha — GET returns a minimal projection.** `GET .../endpoints/{id}` with
> **no `fields` param** returns only `id`, `name`, `created`, `updated`. To read
> back the full endpoint (path alias, system domains, `systemDomainAuthentication`,
> …) you **must** pass an explicit `fields` list, e.g.
> `?fields=id,name,requestPathAlias,systemDomains,systemDomainAuthentication,...`.
> The same applies to the `POST` create response — it is minimal, so the
> `mashery-endpoint-create.py` tool re-reads the endpoint with explicit fields.

The **`mashery-endpoint-update.py`** tool sends only the flags you pass and reads
the result back with explicit fields:

```bash
# Repoint the backend and restrict methods (other fields untouched)
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-update.py \
  --service-id <id> --endpoint-id <eid> \
  --backend-url "https://atom2:9090/ws/rest/orders" --methods get,post

# Toggle inbound HTTPS
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-update.py \
  --service-id <id> --endpoint-id <eid> --ssl     # or --no-ssl
```

## Call Transformation (processor)

An endpoint's **Call Transformation** is the `processor` object — it runs a custom
SDK adapter or a Boomi-provided named connector on the request/response. Partial
PUT works, so set it on `mashery-endpoint-create.py` or `mashery-endpoint-update.py`.

**Three modes (all verified live):**

1. **Single custom SDK processor → DIRECT.** Name the bean FQCN directly in
   `adapter`; inputs stay empty. (No chain.)
   ```bash
   ... mashery-endpoint-update.py --service-id <s> --endpoint-id <e> \
       --sdk-processors "com.banksaqu.cam.oauth.LoginProcessor"
   # processor = {adapter:"com.banksaqu.cam.oauth.LoginProcessor",
   #              preInputs:{}, postInputs:{}, preProcessEnabled:true, postProcessEnabled:true}
   ```
2. **Multiple custom SDK processors → CHAIN.** `adapter` becomes the built-in
   `Mashery_Proxy_Processor_Chain` and the FQCNs go in `preInputs`/`postInputs`
   as `{"processors":"A,B,…"}` (comma list = order). The tool switches to this
   automatically when `--sdk-processors` has 2+ classes; use
   `--sdk-pre-processors` / `--sdk-post-processors` when the stages differ.
   ```bash
   ... --sdk-processors "com.x.A,com.x.B"
   # processor.adapter = "Mashery_Proxy_Processor_Chain"
   # preInputs.processors = postInputs.processors = "com.x.A,com.x.B"
   ```
3. **Named Boomi connector → DIRECT with its own inputs** (e.g. CircuitBreaker,
   an API-policy connector). Use `--processor-adapter` + `--pre-inputs` /
   `--post-inputs` (JSON):
   ```bash
   ... --processor-adapter "com.mashery.proxy.customer.generic.CircuitBreakerService" \
       --pre-inputs '{"obs-window":"50","min-calls":"10"}' \
       --post-inputs '{"http-status-list":"500,502,504"}'
   ```

Toggle stages with `--pre-process true|false` / `--post-process true|false`
(default both true). **Remove** the transformation with `--clear-processor`
(sends an empty adapter + disabled stages — note `processor:null` returns `500`
and `processor:{}` only merges, so neither clears it on its own).

> Custom SDK adapters and connector beans must be **loaded into the area / Local
> Edition** to actually run. Config authored in the cloud syncs to a tethered
> Local Edition on the ~15-min loader delta — a fresh adapter can appear to
> "pass through" until that sync completes.

### Backend timeouts

- `--connect-timeout N` → `connectionTimeoutForSystemDomainRequest` (backend
  **connect**). The area accepts **only 2–7 seconds** — other values return a
  `400` that lists the allowed set; the tool validates this up front.
- `--response-timeout N` → `connectionTimeoutForSystemDomainResponse` (backend
  **read**). Wider: **≥ 2** (8/10/30/120 accepted). The two timeouts have
  different bounds — don't assume the 2–7 connect limit applies to the response.

---

## Cloning an Endpoint

To stand up a near-identical endpoint (same backend, auth, CircuitBreaker
`processor`, `cache`, timeouts, headers, methods…) on another service, copy the
**full** source config and change only what must differ. Doing this by hand is
error-prone — it's easy to miss `apiKeyValueLocations`, `processor`, or
`systemDomainAuthentication`. The **`mashery-endpoint-clone.py`** tool does it
faithfully: GET source → deep-copy → strip server keys (`id`/`created`/`updated`)
→ apply overrides → POST to target → copy methods.

```bash
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-clone.py \
  --source-service-id <srcSvc> --source-endpoint-id <srcEp> \
  --target-service-id <tgtSvc> \
  --name "orders-v2" --path-alias "/orders/v2"      # plus optional --public-domain / --inbound-ssl
```

What it copies (verified against a CircuitBreaker-protected camara endpoint —
the post-clone config diff showed **only** the overrides):
`apiKeyValueLocations`/`apiKeyValueLocationKey`, `supportedHttpMethods`,
`processor` (CircuitBreaker), `systemDomainAuthentication`, `connectionTimeout*`,
`headers*`, `cache`, `highSecurity`, plus the endpoint's **API methods**
(sub-resources, copied in a follow-up call; suppress with `--no-copy-methods`).

Secrets: the source backend password is copied **in-process** (source GET →
target POST) — never passed on the command line — and masked (`***`) in output.

Inspect or diff endpoints with **`mashery-endpoint-get.py`** (it requests the
full field set, working around the minimal-GET projection):

```bash
diff <(python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-get.py --service-id A --endpoint-id X --json) \
     <(python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-get.py --service-id B --endpoint-id Y --json)
```

Constraints (verified live):
- An endpoint's `(publicDomain, requestPathAlias)` must be unique — override
  `--path-alias` and/or `--public-domain` so the clone doesn't collide.
- Backend timeouts have **different bounds**: `connectionTimeoutForSystemDomainRequest`
  (connect) accepts **only 2–7s**, while `connectionTimeoutForSystemDomainResponse`
  (read) accepts **≥ 2** (8/10/30/120 ok). The clone copies the source's
  already-valid values. (See "Call Transformation (processor)" → Backend timeouts.)
- A whitelisted public domain can't be removed via the API (`DELETE /domains/{id}`
  → 403) — choose `--public-domain` deliberately (see `mashery-domain-list.py`).
- A newly provisioned key can take ~15 min to propagate to the gateway.

## Delete an Endpoint

```
DELETE https://api.mashery.com/v3/rest/services/{serviceId}/endpoints/{endpointId}
Authorization: Bearer <token>
```

---

## Common Errors

| Status | Meaning | Fix |
|--------|---------|-----|
| `400` "requestPathAlias already exists" | Another endpoint on this service has the same path | Change `requestPathAlias` |
| `400` "systemDomains required" | Missing backend host | Add `systemDomains` array |
| `404` on backend | Mashery can reach Atom but listener path is wrong | Verify `outboundRequestTargetPath` matches the deployed Boomi listener |
| `503` from gateway | Atom is unreachable from Mashery | Confirm Atom host:port is network-accessible from Mashery cloud |
