# Mashery Services

## What is a Service?

A **Service** is the top-level API object in Mashery. It represents one logical API (e.g., "Orders API", "Customer API"). A Service:

- Has a name, description, and version
- Contains one or more Endpoints
- Holds a security profile (OAuth settings, if applicable)
- Is the unit of association with Plans

One Boomi Integration web service listener typically maps to one Mashery Service with one Endpoint.

---

## Create a Service

### Using the CLI tool

```bash
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-service-create.py \
  --name "Orders API" \
  --description "REST API for order management, backed by Boomi Integration" \
  --version "v1"
```

### Using the Mashery V3 API directly

```
POST https://api.mashery.com/v3/rest/services
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Orders API",
  "description": "REST API for order management, backed by Boomi Integration",
  "version": "v1"
}
```

### Required fields

| Field | Type | Required | Notes |
|-------|------|----------|-------|
| `name` | string | Yes | Must be unique within the area |
| `description` | string | No | Shown in developer portal |
| `version` | string | No | Free-text version label (e.g. "1", "v1", "2024-01") |

### Response

```json
{
  "id": "abc12345-1234-1234-1234-abc123456789",
  "name": "Orders API",
  "description": "REST API for order management, backed by Boomi Integration",
  "version": "v1",
  "created": "2024-01-01T00:00:00.000+0000",
  "updated": "2024-01-01T00:00:00.000+0000"
}
```

**Save the `id` — this is the `serviceId` used for all subsequent endpoint and plan calls.**

---

## List Services

### Using the CLI tool

```bash
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-service-list.py
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-service-list.py --filter "Orders"
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-service-list.py --fields "id,name,version"
```

### Using the API directly

```
GET https://api.mashery.com/v3/rest/services?fields=id,name,version,description&limit=100
Authorization: Bearer <token>
```

### Response

V3 collection endpoints return a **bare JSON array** — there is **no** `{ "items": [...], "totalCount": N }` envelope:

```json
[
  {"id": "abc...", "name": "Orders API", "version": "v1"},
  {"id": "def...", "name": "Products API", "version": "v1"},
  {"id": "ghi...", "name": "Customer API", "version": "v2"}
]
```

> **Gotcha — bare array, not an envelope.** Every V3 collection endpoint (`/services`, `/members`, `/packages`, etc.) returns a plain array. The grand total for pagination is returned in the **`X-Total-Count` response header**, not the body. Calling `result.get("items")` / `result.get("totalCount")` on the response raises `AttributeError: 'list' object has no attribute 'get'`. Paginate with `limit`/`offset` and stop when a page returns fewer than `limit` items. The CLI tools handle this via `mashery_get_all()` / `normalize_collection()` in `mashery_paths.py` — reuse those instead of parsing the response yourself.

---

## Get a Specific Service

```
GET https://api.mashery.com/v3/rest/services/{serviceId}
Authorization: Bearer <token>
```

---

## Update a Service

```
PUT https://api.mashery.com/v3/rest/services/{serviceId}
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Orders API v2",
  "description": "Updated description"
}
```

**Note**: PUT replaces the full object. Always GET first, modify the fields you need to change, then PUT the full object.

---

## Delete a Service

```
DELETE https://api.mashery.com/v3/rest/services/{serviceId}
Authorization: Bearer <token>
```

**Warning**: Deleting a service also deletes its endpoints. Ensure no active keys or plans reference it first, or you will break developer access.

---

## Naming Conventions

- Use descriptive names: `"Orders API"`, `"Customer Profile API"`
- Keep `version` as a simple string: `"v1"` or `"1"`
- For Boomi-backed services, include "Boomi" in description for traceability: `"Order management, backed by Boomi Integration"`
- Avoid special characters in names — stick to alphanumeric, spaces, and hyphens

---

## Common Errors

| Status | Meaning | Fix |
|--------|---------|-----|
| `409 Conflict` | Service name already exists | Use a unique name or retrieve the existing service ID with `mashery-service-list.py` |
| `400 Bad Request` | Missing required field or invalid JSON | Check that `name` is present and the body is valid JSON |
| `401 Unauthorized` | Token expired or wrong area | Re-run `mashery-auth.py` |
| `403 Forbidden` | Insufficient permissions | Confirm your account has admin role in this Area |
