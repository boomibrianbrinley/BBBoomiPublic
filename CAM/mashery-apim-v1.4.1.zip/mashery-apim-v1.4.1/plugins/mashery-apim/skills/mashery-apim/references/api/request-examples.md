# Mashery V3 API Request Examples

Annotated curl examples for all common Mashery V3 REST API operations. Replace `<TOKEN>`, `<AREA_UUID>`, and resource IDs with your actual values.

---

## Authentication

### Get a bearer token

```bash
# Set variables
API_KEY="your-mashery-app-api-key"
API_SECRET="your-mashery-app-api-secret"
USERNAME="you@example.com"
PASSWORD="your-password"
AREA_UUID="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"

# Base64 encode key:secret
AUTH=$(echo -n "${API_KEY}:${API_SECRET}" | base64)

# Request token
curl -s -X POST "https://api.mashery.com/v3/token" \
  -H "Authorization: Basic ${AUTH}" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=password&username=${USERNAME}&password=${PASSWORD}&scope=${AREA_UUID}"
```

Expected response:
```json
{
  "access_token": "eyJ...",
  "token_type": "Bearer",
  "expires_in": 3600,
  "scope": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
}
```

---

## Services

### Create a Service

```bash
curl -s -X POST "https://api.mashery.com/v3/rest/services" \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Orders API",
    "description": "Order management REST API backed by Boomi Integration",
    "version": "v1"
  }'
```

### List all Services (with specific fields)

```bash
curl -s "https://api.mashery.com/v3/rest/services?fields=id,name,version,description&limit=100" \
  -H "Authorization: Bearer <TOKEN>"
```

### Get a specific Service

```bash
curl -s "https://api.mashery.com/v3/rest/services/<SERVICE_ID>" \
  -H "Authorization: Bearer <TOKEN>"
```

### Update a Service

```bash
curl -s -X PUT "https://api.mashery.com/v3/rest/services/<SERVICE_ID>" \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Orders API",
    "description": "Updated description",
    "version": "v2"
  }'
```

### Delete a Service

```bash
curl -s -X DELETE "https://api.mashery.com/v3/rest/services/<SERVICE_ID>" \
  -H "Authorization: Bearer <TOKEN>"
```

---

## Endpoints

### Create an Endpoint on a Service

```bash
curl -s -X POST "https://api.mashery.com/v3/rest/services/<SERVICE_ID>/endpoints" \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Default",
    "requestAuthenticationType": "apiKey",
    "apiKeyValueLocations": ["request-parameters"],
    "apiKeyValueLocationKey": "api_key",
    "supportedHttpMethods": ["get", "post", "put", "delete"],
    "requestPathAlias": "/orders",
    "publicDomains": [{"address": "yourcompany.api.mashery.com"}],
    "systemDomains": [{"address": "atom-host:9090"}],
    "outboundRequestTargetPath": "/ws/rest/orders",
    "outboundTransportProtocol": "http",
    "inboundSslRequired": false,
    "useSystemDomainAsTarget": false
  }'
```

### List Endpoints for a Service

```bash
curl -s "https://api.mashery.com/v3/rest/services/<SERVICE_ID>/endpoints" \
  -H "Authorization: Bearer <TOKEN>"
```

### Get a specific Endpoint

```bash
# NOTE: pass an explicit fields list — without it, GET returns only
# id/name/created/updated (a minimal projection).
curl -s "https://api.mashery.com/v3/rest/services/<SERVICE_ID>/endpoints/<ENDPOINT_ID>?fields=id,name,requestPathAlias,systemDomains,outboundRequestTargetPath,requestAuthenticationType,systemDomainAuthentication" \
  -H "Authorization: Bearer <TOKEN>"
```

### Create an Endpoint with backend auth (systemDomainAuthentication)

```bash
# Outbound HTTP Basic to a secured backend (independent of the inbound api key)
curl -s -X POST "https://api.mashery.com/v3/rest/services/<SERVICE_ID>/endpoints" \
  -H "Authorization: Bearer <TOKEN>" -H "Content-Type: application/json" \
  -d '{
    "name": "Default",
    "requestPathAlias": "/orders",
    "systemDomains": [{"address": "atom:9090"}],
    "outboundRequestTargetPath": "/ws/rest/orders",
    "outboundTransportProtocol": "https",
    "requestAuthenticationType": "apiKey",
    "apiKeyValueLocations": ["request-parameters"],
    "apiKeyValueLocationKey": "api_key",
    "systemDomainAuthentication": {"type": "httpBasic", "username": "boomiuser", "password": "s3cret"}
  }'
```

### Update an Endpoint (partial PUT — merges)

```bash
# Only the fields sent are changed; the rest are preserved.
curl -s -X PUT \
  "https://api.mashery.com/v3/rest/services/<SERVICE_ID>/endpoints/<ENDPOINT_ID>" \
  -H "Authorization: Bearer <TOKEN>" -H "Content-Type: application/json" \
  -d '{"systemDomainAuthentication": {"type": "httpBasic", "username": "boomiuser", "password": "s3cret"}}'

# Remove backend auth:
#   -d '{"systemDomainAuthentication": null}'
```

### Delete an Endpoint

```bash
curl -s -X DELETE \
  "https://api.mashery.com/v3/rest/services/<SERVICE_ID>/endpoints/<ENDPOINT_ID>" \
  -H "Authorization: Bearer <TOKEN>"
```

---

## Public Domains (the area whitelist)

The area keeps a registry of allowed hostnames — the "public domain whitelist".
A host must appear here before it can be used as a `publicDomains` /
`systemDomains` address on an endpoint. The resource is a **bare JSON array**
(like `/services`); each entry is `{id, domain, status, message, description,
created, updated}`.

### List whitelisted domains

```bash
curl -s "https://api.mashery.com/v3/rest/domains?fields=id,domain,status,description&limit=100" \
  -H "Authorization: Bearer <TOKEN>"
```

### Register (whitelist) a public domain  — supported via V3

```bash
curl -s -X POST "https://api.mashery.com/v3/rest/domains" \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "domain": "api.example.com",
    "status": "active"
  }'
```

Response (200) confirms the whitelisting:
```json
{
  "id": "c3ac3520-...",
  "domain": "api.example.com",
  "status": "active",
  "message": "The domain api.example.com has been whitelisted.",
  "description": null
}
```

### Update a domain's description (only field that is mutable)

```bash
curl -s -X PUT "https://api.mashery.com/v3/rest/domains/<DOMAIN_ID>" \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"description": "LE public domain"}'
```

> `domain` and `status` are immutable — including them in a PUT body returns
> `400 "Property '...' should not be part of request payload."`

### Delete a domain — NOT permitted via the API

```bash
curl -s -X DELETE "https://api.mashery.com/v3/rest/domains/<DOMAIN_ID>" \
  -H "Authorization: Bearer <TOKEN>"
# → HTTP 403 {"errorCode":403,"errorMessage":"Forbidden"}
```

Removing a whitelisted domain requires the **Control Center UI**.

---

## Packages

### Create a Package

```bash
curl -s -X POST "https://api.mashery.com/v3/rest/packages" \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Orders API Package",
    "description": "Access to the Orders API",
    "notifyDeveloperPeriod": "day",
    "notifyDeveloperNearQuota": false,
    "notifyDeveloperOverQuota": false,
    "generateSecrets": true,
    "sharedSecretLength": 10
  }'
```

> **Gotcha — `notifyDeveloperPeriod` is required and `"never"` is invalid.**
> The value must be a real period: `minute` | `hour` | `day` | `week` | `month`.
> Sending `"never"` (or omitting nothing but using a bad value) returns a
> *misleading* `400 "Property 'notifyDeveloperPeriod' is required."` — Mashery
> reports an unrecognized enum as if the field were missing. Omitting the field
> entirely also works and defaults to `"day"`. The near/over-quota notify flags
> can stay `false`; the period is inert unless they are enabled.

### List Packages

```bash
curl -s "https://api.mashery.com/v3/rest/packages?fields=id,name,description" \
  -H "Authorization: Bearer <TOKEN>"
```

---

## Plans

### Create a Plan (linked to Service + Endpoint)

```bash
curl -s -X POST "https://api.mashery.com/v3/rest/packages/<PACKAGE_ID>/plans" \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Basic",
    "description": "Basic access plan",
    "selfServiceKeyProvisioningEnabled": false,
    "adminKeyProvisioningEnabled": true,
    "numKeysBeforeReview": 1,
    "maxNumKeysAllowed": 2,
    "qpsLimitCeiling": 10,
    "rateLimitCeiling": 1000,
    "rateLimitPeriod": "day",
    "services": [
      {
        "id": "<SERVICE_ID>",
        "endpoints": [
          {"id": "<ENDPOINT_ID>"}
        ]
      }
    ]
  }'
```

### List Plans for a Package

```bash
curl -s "https://api.mashery.com/v3/rest/packages/<PACKAGE_ID>/plans" \
  -H "Authorization: Bearer <TOKEN>"
```

---

## Members and Keys

### Find your member ID by email

```bash
curl -s "https://api.mashery.com/v3/rest/members?filter=username:you@example.com&fields=id,username" \
  -H "Authorization: Bearer <TOKEN>"
```

### Admin-provision an API key — keys are Application-scoped

> **Important:** package keys belong to an **Application**, not directly to a
> member/plan. `POST .../packages/{id}/plans/{id}/members/{id}/keys` returns
> **404 Not Found**, and `POST /packageKeys` returns `"Method not found"`. The
> working flow is two steps: (1) ensure the member owns an Application, then
> (2) create the key under that Application.

**Step 1 — ensure the member has an Application** (create one if needed):

```bash
curl -s -X POST "https://api.mashery.com/v3/rest/members/<MEMBER_ID>/applications" \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"name": "My App", "username": "<MEMBER_USERNAME>"}'
```

**Step 2 — create the key under the Application**, referencing the package + plan:

```bash
curl -s -X POST \
  "https://api.mashery.com/v3/rest/applications/<APPLICATION_ID>/packageKeys" \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{
    "apikey": "",
    "secret": "",
    "status": "active",
    "limits": [],
    "package": {"id": "<PACKAGE_ID>"},
    "plan": {"id": "<PLAN_ID>"}
  }'
```

Note: Empty `apikey` and `secret` strings instruct Mashery to auto-generate them;
the response returns the generated `apikey` and `secret`. The
`mashery-package-plan-create.py --provision-key` tool performs both steps.

### List keys (all package keys, or filter by package / member)

```bash
curl -s "https://api.mashery.com/v3/rest/packageKeys?filter=package.id:<PACKAGE_ID>&fields=id,apikey,status,application.name,member.username,plan.id" \
  -H "Authorization: Bearer <TOKEN>"
```

---

## Testing Your API Through the Gateway

Once you have a provisioned API key:

```bash
# Basic test (API key in query parameter)
curl "https://yourcompany.api.mashery.com/orders?api_key=<YOUR_API_KEY>"

# With explicit headers
curl -H "Accept: application/json" \
     "https://yourcompany.api.mashery.com/orders?api_key=<YOUR_API_KEY>"

# POST example
curl -X POST \
     -H "Content-Type: application/json" \
     -H "Accept: application/json" \
     -d '{"orderId": "123"}' \
     "https://yourcompany.api.mashery.com/orders?api_key=<YOUR_API_KEY>"
```

Expected responses:
- `200` — success, Boomi listener responded normally
- `401` — API key missing, invalid, or not associated with a plan that covers this endpoint
- `403` — rate limit exceeded
- `404` — path alias not found (check `requestPathAlias` on the endpoint)
- `503` — backend (Atom) is unreachable from Mashery
