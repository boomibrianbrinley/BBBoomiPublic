# Field Notes — discoveries while using the boomi-cam skill

A running log of API behaviors, bugs, and gotchas found while using this skill against a live Boomi CAM / Mashery area. Each entry should say what was observed, the impact, and what changed (or still needs to). Add to this file as you find more.

---

## 2026-07-25 — Package-key lifecycle: Application-scoped, one-per-plan, new keys start "waiting", DELETE works

**By:** Brian Brinley <brian.brinley@boomi.com> · shipped in 2.0.0

**Area tested:** `00000000-0000-0000-0000-000000000000`. Verified live end-to-end with the new `tools/mashery-key.py` (create → list → suspend → activate → revoke) on a throwaway Application/key, cleaned up after.

**Observed:**
- Package keys are **Application-scoped**: `/applications/{appId}/packageKeys[/{keyId}]`. `suspend`/`activate` = `PUT {status: disabled|active}`; `revoke` = `DELETE`.
- **One key per Application per package/plan** — creating a second key for the same (app, package, plan) returns `400 "Duplicate Object"`. Use a different Application to hold another key.
- **New keys are created in status `waiting`** (review), even when `status: active` is requested; `activate` moves them to `active`. A developer key-generation email fires on create even with `notifyDeveloperOfKeyChanges: false`.
- **`DELETE` on a package key succeeds** here (revoke = delete) — unlike `DELETE` on *domains* (which returns 403). The tool still falls back to `suspend` if a key DELETE ever 403s.

**Added:** `tools/mashery-key.py` — `list/create/suspend/activate/revoke/rotate`. Masks apikey/secret by default (`--show-keys`), uses the shared HTTP timeout, and handles errors gracefully (no mid-run `sys.exit`) so the revoke→suspend fallback works.

---

## 2026-06-15 — V3 collection endpoints return a bare array, not an `{items,totalCount}` envelope

**By:** Yohanes W Sono <yohanes.sono@boomi.com> · shipped in 1.0.1

**Area tested:** `00000000-0000-0000-0000-000000000000` (region `api.mashery.com`, user `svcuser_example`). Connectivity confirmed via `mashery-auth.py` (token issued) and `GET /v3/rest/services` (3 services returned).

**Observed:** `GET /v3/rest/services` (and `GET /v3/rest/members`) return a **bare JSON array**. The grand total for pagination is in the **`X-Total-Count` response header**, not the body. There is no `{ "items": [...], "totalCount": N }` wrapper.

**Impact (bug):** Tools assumed the envelope shape and called `result.get("items")` / `result.get("totalCount")` on the response, which is a `list` → crash:
```
AttributeError: 'list' object has no attribute 'get'
```
- `tools/mashery-service-list.py` — crashed on every run.
- `tools/mashery-package-plan-create.py` `get_member_id()` — same pattern; would crash during `--provision-key`.
- `references/guides/services.md` "List Services → Response" documented the wrong (envelope) shape — the original source of the assumption.

**Fixed:**
- Added `normalize_collection()` + `mashery_get_all()` to `tools/mashery_paths.py` (handles bare array, defensive envelope, single-object, and limit/offset pagination by stopping on a short page).
- `mashery-service-list.py` and `mashery-package-plan-create.py` now use `mashery_get_all()`.
- `services.md` List response corrected to a bare array + a "Gotcha" callout.
- Re-tested live: `mashery-service-list.py` lists 3 services; `--filter` works.

---

## 2026-06-15 — V3 tokens are opaque strings, not JWTs

**By:** Yohanes W Sono <yohanes.sono@boomi.com> · shipped in 1.0.1

**Observed:** the `access_token` from `POST /v3/token` is a short opaque string (~24 chars, e.g. `EXAMPLE_ACCESS_TOKEN`), and `token_type` is returned lowercase (`bearer`).

**Impact:** `references/guides/authentication.md` "Token Response" showed a JWT-style `"access_token": "eyJ..."`, which is misleading (implies a decodable JWT).

**Fixed:** updated the example to an opaque token + lowercase `bearer`, with a note that V3 tokens are not JWTs.

---

## 2026-06-15 — Management API key is rate limited (2/sec, 5,000/day) → tools must self-throttle

**By:** Yohanes W Sono <yohanes.sono@boomi.com> · shipped in 1.0.2

**Observed:** the Mashery developer/application key used to call the V3 REST API is rate limited — default **2 calls/second** and **5,000 calls/day**. Raising QPS (e.g. to 10/sec) requires contacting Boomi Support; it is not self-serve.

**Impact:** the tools made unthrottled calls. After the 1.0.1 `mashery_get_all()` paginator was added, a multi-page list could fire >2 requests/sec and trip the limit → opaque `403` mid-batch.

**Fixed:** added QPS throttling + per-day counter + QPS-retry/backoff to `tools/mashery_paths.py` (`get_rate_limits`, `_throttle`, `quota_used`, `_rate_error_kind`); overridable via `MASHERY_API_QPS` / `MASHERY_API_DAILY`. Documented in `best-practices.md`. Verified the throttle holds 5 GETs to ~4.4s.

## 2026-06-15 — Endpoint reverse-lookup: resolve consumers from PackageKeys, not /applications

**By:** Yohanes W Sono <yohanes.sono@boomi.com> · shipped in 1.1.0

**Area tested:** `00000000-0000-0000-0000-000000000000`. Live data: 1 package (`Demo APIs`), plans Free/Gold/bronze/silver, 5 package keys, apps incl. `Scoot-Demo`, `IOH Demo-Gold`, `Demo App`, `Demo`.

**Goal:** "I have an endpoint name + path — which Applications/Packages use it?" The CAM model is one-directional (`Endpoint → Service → Plan → Package → PackageKey → Application`), so it requires chaining calls back down. Built `tools/mashery-endpoint-consumers.py` for this.

**Observed (two corrections to the conceptual framework):**
1. **`/applications?filter=packageKeys.package.id:<id>` is rejected** — `HTTP 404 {"errorCode":404,"errorMessage":"ERR_INVALID_FIELD","errors":{"field":"package","model":"package_keys"}}`. That filter path is not valid in this area. **Instead**, `GET /packageKeys?filter=package.id:<id>&fields=...,application.id,application.name,member.id,member.username,plan.id,plan.name` returns the consuming **Application**, its **owner (member)**, and the **Plan** nested on each key — so Step 3 (`/applications`) is unnecessary; resolve consumers straight from the PackageKeys (also one fewer call/package).
2. **`requestPathAlias` comes back `null`** in the nested package projection (`plans.services.endpoints.requestPathAlias`). Path matching via the package map is therefore unreliable in this area — endpoint **name** matching is the dependable path. Documented `--name` as the primary matcher; `PATH_FIELD` is overridable in the tool.

**Also:** a Package holds multiple Plans and only some grant the target endpoint, so the tool narrows consuming keys to the Plan ID(s) found in Step 1 (verified: `AntiFraud` is Gold-only → 2 of 5 package keys, apps `Scoot-Demo` + `IOH Demo-Gold`).

**Added:** `mashery_get_all(..., index_pagination=True)` for the page-index pagination `/packageKeys` and `/applications` use (vs. record-offset for `/packages`, `/services`); de-dupes by `id` and caps `max_pages` as a safety net against a wrong offset-mode assumption.

**Verified live:** `--name AntiFraud`, `--name Contact` (bronze+silver, 2 apps), `--name materialPrice --json` all return correct consumers.

## 2026-06-16 — Public-domain whitelist: GET/POST work, DELETE is 403, PUT is description-only

**By:** Yohanes W Sono <yohanes.sono@boomi.com> · shipped in 1.2.0

**Area tested:** `00000000-0000-0000-0000-000000000000` (traffic domain `example.api.mashery.com`).

**Goal:** there was no tool to list or register the area's public domains — you had to read `/v3/rest/domains` with raw curl, and it was unconfirmed whether the V3 API can *create* a public domain or whether it's Control-Center-UI-only. Built `tools/mashery-domain-list.py` + `tools/mashery-domain-create.py` and probed the full CRUD live to settle it.

**Observed:**
1. **Resource is `/v3/rest/domains`** (the other guesses — `/publicDomains`, `/systemDomains` — both `404`). Returns a **bare JSON array** (same shape gotcha as `/services`), each item `{id, created, updated, domain, status, message, description}`. These are the area's **whitelisted public domains** — a host must be here before it can be used as an endpoint `publicDomains`/`systemDomains` address.
2. **POST is supported** → `200`, body `message: "The domain <x> has been whitelisted."`. So **creating a public domain via V3 is NOT UI-only** — the open question is settled: it works.
3. **DELETE `/domains/{id}` → `403 Forbidden`** (consistent across retries) for the service account. Removal is **Control Center UI-only**.
4. **PUT `/domains/{id}` is description-only** — including `domain` or `status` returns `400 "Property '...' should not be part of request payload."` (`domain`/`status` are immutable).

**Side effect (disclosed):** the create probe whitelisted a throwaway domain `claude-probe-delete-me.example.com` (id `c3ac3520-098a-412d-a51b-ab94ff477fb2`). Because DELETE is 403, it could not be removed via the API; I PUT a `description` tagging it as a probe artifact safe to delete via the Control Center UI. **Action for an area admin:** remove that domain in Control Center.

**Added:** `mashery-domain-list.py` (`--filter`, `--json`), `mashery-domain-create.py` (`--domain`, `--description`); SKILL.md tool table/routing/workflow/scope; `endpoints.md` "Public Domain Whitelist" section; `request-examples.md` "Public Domains" section. Create-path tool verified via the live probe (200); list tool verified live (9 domains, `--filter mashery` → 1).

## 2026-06-16 — Package create rejects `notifyDeveloperPeriod: "never"`; key provisioning is Application-scoped

**By:** Yohanes W Sono <yohanes.sono@boomi.com> · shipped in 1.2.1

**Area tested:** `00000000-0000-0000-0000-000000000000` (service `Contact` / endpoint `Contact.corporate`). Probed create + delete live; all throwaway packages/apps/keys deleted afterward (no leftovers).

**Two bugs in `mashery-package-plan-create.py`, both now fixed:**

1. **`POST /packages` 400 — `notifyDeveloperPeriod: "never"` is invalid.** The tool sent `"never"` (since 1.0.0). This area returns a *misleading* `400 {"property":"notifyDeveloperPeriod","message":"Property 'notifyDeveloperPeriod' is required."}` — Mashery reports an **unrecognized enum value as if the field were missing**. Probed live: omitting the field → 200 (defaults to `"day"`); `day`/`week`/`month`/`hour`/`minute` all → 200; only `"never"` → 400. **Fix:** send a real period (default `"day"`, new `--notify-period` arg with choices `minute|hour|day|week|month`). Also corrected `request-examples.md` and `packages-and-plans.md`, which both documented `"never"` (and the latter listed the wrong enum `never/daily/weekly/monthly` — the real values are the singular forms).

2. **Key provisioning 404 — keys are Application-scoped, not member/plan-scoped.** The tool POSTed to `packages/{pid}/plans/{plid}/members/{mid}/keys` → **404 Not Found**. Probed the alternatives: `POST /packageKeys` and `POST /members/{mid}/keys` → `{"message":"Method not found","code":-32601}`; `packages/{pid}/keys`, `packages/{pid}/plans/{plid}/keys` → 404. Every existing package key carries a nested **`application`** — and the service-account member `svcuser_example` had **zero applications** (`applications: []`). **Working flow (verified live, key `EXAMPLE_KEY` issued + deleted):**
   - `POST /members/{memberId}/applications` `{name, username}` → creates an Application (200).
   - `POST /applications/{applicationId}/packageKeys` `{apikey:"", secret:"", status:"active", limits:[], package:{id}, plan:{id}}` → returns the auto-generated `apikey` + `secret` (200).
   **Fix:** `--provision-key` now finds-or-creates an Application (`get_or_create_application`, named `"<package> App"`, override `--app-name`) then creates the key under it (`provision_key`). The summary now also prints the key **secret**.

**Also confirmed:** `DELETE /packages/{id}`, `DELETE /applications/{id}`, `DELETE /packageKeys/{id}` all return 200 — unlike `/domains` DELETE (403). Verified end-to-end: the full tool now creates Package + Plan + Application + Key green.

## 2026-06-16 — No "none" auth type on endpoints; applications can't be activated via API

**By:** Yohanes W Sono <yohanes.sono@boomi.com> · shipped in 1.2.2

**Area tested:** `00000000-0000-0000-0000-000000000000`. Probed with throwaway services/endpoints/applications, all deleted afterward.

**1. `mashery-endpoint-create.py --auth none` was broken — V3 has no unauthenticated endpoint type.** `requestAuthenticationType` accepts only `apiKey`, `apiKeyAndSecret_SHA256`, `oauth` (iff enabled for the service), and `custom` (needs `customRequestAuthenticationAdapter`). The parser maps **any unrecognized value** to `custom`: probed `none`/`None`/`NONE`/`open`/`public`/`no`/`disabled` → all `400 "Property 'customRequestAuthenticationAdapter' is required if requestAuthenticationType is custom."` (exactly the reported error). `oauth` → `400` ("oauth is not enabled for the service"); `apiKey` and `apiKeyAndSecret_SHA256` → `200`. **Gotcha:** *omitting* `requestAuthenticationType` is NOT "open" — the create succeeds (200) but the area **defaults it to `apiKey`** (verified by reading the endpoint back). So a keyless/open endpoint cannot be made via the V3 API at all. **Fix:** the tool now (a) adds `apiKeyAndSecret_SHA256` as a real choice, (b) only sets the key-value-location fields for the key-based types, and (c) **rejects `--auth none` up front** with an explanation pointing at the Control Center UI, instead of sending a request that 400s.

**2. Provisioned applications land in `draft` and the API can't activate them.** `POST /members/{id}/applications` always returns `status: "draft"`, and `PUT /applications/{id}` with `{"status":"active"}` (or `"enabled"`) → `400 {"property":"status","message":"Please choose a different value."}`. Crucially, **every** application in this area reads as `draft` — including `IOH Demo-Free` etc. whose keys are active and in use — so draft is the normal terminal state and is **not** what gates a key; the key's own `status: active` governs gateway access. So the user's "key likely needs the app activated" hypothesis doesn't hold (and the API couldn't activate it anyway). **Fix:** `mashery-package-plan-create.py --provision-key` now prints the application status, the key status, and — when the app is `draft` — a NOTE explaining it's expected and that the Control Center UI is the only way to change app status if the gateway ever rejects the key.

**Also confirmed:** `DELETE` works for services, endpoints, applications, packages, package keys (all 200) — only `/domains` DELETE is 403 (see earlier note).

## 2026-06-16 — Endpoint backend auth + update tool: minimal-GET projection, partial-PUT merges

**By:** Yohanes W Sono <yohanes.sono@boomi.com> · shipped in 1.3.0

**Area tested:** `00000000-0000-0000-0000-000000000000`. Throwaway service/endpoints, deleted after.

**Goal:** no way to set an endpoint's **backend** auth (`systemDomainAuthentication`, e.g. HTTP Basic to a secured Boomi listener) and no endpoint-update tool — backend Basic auth had to be set via raw V3. Added backend-auth options to `mashery-endpoint-create.py` and a new `mashery-endpoint-update.py`.

**Observed (three V3 behaviors that shaped the tools):**
1. **`systemDomainAuthentication` works as `{"type":"httpBasic","username":...,"password":...}`** on create and update; it persists and reads back. It's the *outbound* auth (Mashery → backend), independent of `requestAuthenticationType` (inbound). The API stores/returns the **password in clear text** (tools mask it to `***`).
2. **GET on a single endpoint returns a *minimal projection*** — only `id`, `name`, `created`, `updated` — unless you pass an explicit `fields` list. This is why backend auth first looked like it wasn't saved (it was; I just wasn't projecting it). The **POST create response is minimal too**, so the create tool now re-reads with explicit fields (`ENDPOINT_FIELDS` in `mashery_paths.py`). The update tool does the same.
3. **Partial PUT MERGES** — `PUT {"name":"X"}` preserves `requestPathAlias`, `systemDomains`, `systemDomainAuthentication`, etc. (confirmed via explicit-fields GET after the PUT). So the update tool sends only the flags passed; `--clear-backend-auth` sends `systemDomainAuthentication: null`.

**Credential handling:** the backend password can be supplied via env `MASHERY_BACKEND_PASSWORD` instead of `--backend-password`, so it never lands in the process list / shell history (the harness auto-mode classifier blocks a literal password on the command line). Flag aliases match the requested naming: `--system-domain-auth basic` / `--system-user` / `--system-pass` (alongside `--backend-auth-type httpBasic` / `--backend-user` / `--backend-password`).

**Verified live (driving the actual CLIs):** create with backend Basic (alias flags + env password) → auth persisted, password not leaked in stdout; update rename+methods → merged (path alias + backend auth preserved); `--clear-backend-auth` → null; update `--auth none` → rejected (same guard as create). Throwaway service deleted.

## 2026-06-16 — Seamless endpoint clone: full-config copy, `fields=*` is empty, RESPONSE-timeout floor is 2

**By:** Yohanes W Sono <yohanes.sono@boomi.com> · shipped in 1.4.0

**Area tested:** `00000000-0000-0000-0000-000000000000`, cloning the CircuitBreaker-protected `IOH_Demo / camara-number-verification-v2` endpoint. Throwaway target service, deleted after.

**Goal:** a manual endpoint clone kept missing fields (key location, methods, `processor`). Built `mashery-endpoint-clone.py` (GET source → deep-copy → strip server keys → apply only overrides → POST to target → copy methods) and `mashery-endpoint-get.py` (full-config dump for diffing).

**Observed:**
1. **`GET .../endpoints/{id}?fields=*` returns an empty object** — the wildcard doesn't work; you must enumerate fields explicitly (captured as `ENDPOINT_FULL_FIELDS` in `mashery_paths.py`). Same minimal-projection rule as the single-endpoint GET noted earlier.
2. **A faithful clone is just: copy every field except `id`/`created`/`updated` (recursively), drop `methods`, apply overrides, POST.** Verified: after cloning with only `--name` + `--path-alias` overrides, a full-config diff of source vs clone showed **zero** non-override differences — `processor` (CircuitBreaker preInputs/postInputs), `cache`, `connectionTimeout*`, `apiKeyValueLocations`/`apiKeyValueLocationKey` (`x-api-key` / `request-header`), `supportedHttpMethods`, `systemDomainAuthentication`, `highSecurity` all carried over.
3. **`methods` are sub-resources** — not created by the endpoint POST. Copy them with a follow-up `POST /services/{svc}/endpoints/{ep}/methods` (ids stripped) per method → 200. The clone tool does this (suppress with `--no-copy-methods`).
4. **`connectionTimeoutForSystemDomainResponse` (read timeout) floor is 2.** `1` → `400 "must be greater than or equal to 2"`; `2`, `7`, `8`, `10` all → `200`. (CORRECTION, see 2026-06-17 entry: this is the RESPONSE timeout only. The REQUEST/connect timeout `connectionTimeoutForSystemDomainRequest` is the strict 2–7 field — I over-generalized here.)
5. **Backend secret handling:** `systemDomainAuthentication` (incl. the clear-text password) is copied **in-process** (source GET → target POST) — never on the CLI — and the tools mask it to `***` in output. The camara source's real backend password was confirmed *not* present in clone/get stdout.

**Added:** `mashery-endpoint-clone.py`, `mashery-endpoint-get.py`; `mashery_paths.py` `ENDPOINT_FULL_FIELDS` + `strip_server_keys()`. Possible follow-ons (not built): a `mashery-service-clone.py`, and method-level field fidelity beyond name/sample responses.

## 2026-06-17 — Endpoint Call Transformation (`processor`) + the connect-timeout 2–7 rule

**By:** Yohanes W Sono <yohanes.sono@boomi.com> · shipped in 1.4.1

**Area tested:** `00000000-0000-0000-0000-000000000000`. Throwaway service/endpoint, deleted after.

**Goal:** no tool set an endpoint's Call Transformation (`processor`) — a custom SDK adapter had to be applied via raw V3 PUT. Added `--sdk-processors` / `--processor-adapter` / `--clear-processor` (+ timeouts) to `mashery-endpoint-create.py` and `mashery-endpoint-update.py` (shared `build_processor` / `add_processor_args` / `apply_processor_args` in `mashery_paths.py`).

**Observed (all verified live via the actual CLI):**
1. **SINGLE custom SDK processor → DIRECT.** `processor.adapter` = the bean FQCN (e.g. `com.banksaqu.cam.oauth.LoginProcessor`), `preInputs`/`postInputs` `{}`. Persists. (Confirms the user-story CORRECTION: direct mode works; no chain needed for one bean. The earlier "silent passthrough" was the ~15-min LE loader sync delay, not an API failure.)
2. **MULTIPLE → CHAIN.** `adapter` = `Mashery_Proxy_Processor_Chain`; FQCNs go in `preInputs.processors` / `postInputs.processors` as a comma list. The tool auto-switches on class count; `--sdk-pre-processors`/`--sdk-post-processors` cover differing stages.
3. **Named connector** (CircuitBreaker, api-policy, …): `adapter` = the connector name directly, its params in `pre`/`postInputs` (`--processor-adapter` + `--pre-inputs`/`--post-inputs` JSON).
4. **Clearing is fiddly:** `processor: null` → **HTTP 500**; `processor: {}` → 200 but only *merges* (adapter survives). Working clear = send `{adapter:"", preProcessEnabled:false, postProcessEnabled:false, preInputs:{}, postInputs:{}}` (`--clear-processor`).
5. **connect-timeout is strictly 2–7.** `connectionTimeoutForSystemDomainRequest`: `1`/`8`/`10`/`30` → `400 "...should be any value out of ['2 Seconds ... 7 Seconds']"`; `2`–`7` → `200`. This is a DIFFERENT field from the RESPONSE timeout (`connectionTimeoutForSystemDomainResponse`, floor 2, 120 accepted) — the 2026-06-16 clone note that said "connectionTimeout* floor is 2" was the RESPONSE field; corrected there. `--connect-timeout` validates 2–7 up front; `--response-timeout` validates ≥2.

**Verified:** single-direct, chain, named-connector, split pre/post, clear, and connect-timeout accept/reject (5 ok, 8 rejected) all pass via `mashery-endpoint-update.py`. `mashery-endpoint-clone.py` already carries `processor` faithfully (it deep-copies the full config).

<!-- Add new findings above this line. Template:
## YYYY-MM-DD — short title
**Observed:** ...
**Impact:** ...
**Fixed / TODO:** ...
-->
