# Boomi Cloud API Management (CAM) Skill for Claude Code

A Claude Code skill that lets you register, configure, and manage APIs in **Boomi Cloud API Management** — directly from your AI-assisted development workflow.

This skill gives Claude deep knowledge of the Mashery V3 REST API, Python CLI tools for all gateway operations, and battle-tested reference documentation covering authentication, service creation, endpoint routing, package and plan management, and developer key provisioning.

---

## What This Skill Does

| Capability | Description |
|---|---|
| **Service management** | Create and list API Services (the logical API definition objects in Mashery) |
| **Endpoint configuration** | Create, update, inspect, and clone routing rules — path aliases, backend URLs, auth types, methods, backend auth, timeouts |
| **Call Transformation** | Attach SDK/connector processors (pre/post) and backend connect/response timeouts to endpoints |
| **Package + Plan creation** | Create distributable API packages and access-tier plans with rate limiting |
| **Key lifecycle** | Provision, list, suspend, reactivate, revoke, and rotate developer API keys |
| **Consumer lookup** | Reverse-lookup which Packages, Plans & Applications consume a given endpoint |
| **Public domains** | List and register (whitelist) the area's public traffic domains |
| **Authentication** | Acquire and manage OAuth 2.0 bearer tokens for the Mashery V3 management API |
| **Boomi Integration gateway** | Full workflow: expose a Boomi WSS listener through the Mashery gateway in minutes |

---

## Using it in Claude Code

You mostly won't touch the CLI. Once installed, just **ask Claude in plain language** — it reads `SKILL.md` and drives Cloud API Management for you:

- "List all the services in my Mashery area"
- "Publish the Orders API and put a 10 QPS rate limit on it"
- "Create a developer key for the Products plan, then rotate it"
- "Which apps and packages consume the /orders endpoint?"
- "Whitelist a new public domain for my area"

### Better together with Boomi Companion

boomi-cam pairs with **[Boomi Companion](https://github.com/OfficialBoomi/boomi-companion)** — the official Boomi agent for Integration, APIs, and the broader platform. A natural end-to-end flow, in one conversation:

1. **Boomi Companion** builds and deploys the Boomi Integration process (e.g. a Web Services Server listener).
2. **boomi-cam** publishes that listener as a managed API in Cloud API Management (Mashery) — service, endpoint, plan, rate limit, and developer keys.

So you go from *"build me an orders integration"* to *"now expose it as a rate-limited public API with a developer key"* without leaving the chat.

---

## Prerequisites

- **Claude Code** CLI installed and authenticated
- **Boomi Cloud API Management** area with admin access (see [Authentication Guide](plugins/boomi-cam/skills/boomi-cam/references/guides/authentication.md))
- **Python 3.7+** — used by the CLI tools (standard on macOS/Linux)
- Boomi Integration Runtime running a Web Services Server listener (for the Boomi gateway pattern)

---

## Installation

### Step 1 — Install Boomi Companion (recommended)

This skill is designed to work alongside **Boomi Companion** — the official Boomi AI agent for Claude Code that covers Integration, APIs, Event Streams, and the broader Boomi platform:

```
/plugin marketplace add OfficialBoomi/boomi-companion
```

### Step 2 — Install this marketplace

```
/plugin marketplace add boomi-internal/boomi-cam
```

Then install the plugin (the `@boomi-cam` suffix is the marketplace name):

```
/plugin install boomi-cam@boomi-cam
```

---

## Configuration

Create a `.env` file in your project root (never commit this file):

```bash
# Boomi Cloud API Management (Mashery)
# (Legacy MASHERY_* names are still accepted but deprecated.)
BOOMI_CAM_API_KEY=your-app-api-key
BOOMI_CAM_API_SECRET=your-app-api-secret
BOOMI_CAM_USERNAME=you@example.com
BOOMI_CAM_PASSWORD=your-control-center-password
BOOMI_CAM_AREA_UUID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
BOOMI_CAM_API_URL=https://api.mashery.com
BOOMI_CAM_TRAFFIC_DOMAIN=yourcompany.api.mashery.com

# Boomi Integration (required for the Boomi Integration + Mashery gateway pattern)
BOOMI_USERNAME=user@example.com
BOOMI_ACCOUNT_ID=boomi_accountname-XXXXXX
BOOMI_API_TOKEN=your-api-token
SERVER_BASE_URL=http://your-runtime-host:9090
```

See the [Authentication Guide](plugins/boomi-cam/skills/boomi-cam/references/guides/authentication.md) for how to obtain each value, including where to find your Area UUID and how to issue developer app keys.

---

## Under the hood: CLI tools (optional)

You rarely need these — Claude calls them for you. They're here for power users and scripting. All are plain Python (stdlib only), auto-load your `.env`, and support `--help`.

### Verify credentials
```bash
python3 tools/mashery-auth.py
```

### Create a Service (API definition)
```bash
python3 tools/mashery-service-create.py \
  --name "Orders API" \
  --description "Backed by Boomi Integration" \
  --version "v1"
```

### List existing Services
```bash
python3 tools/mashery-service-list.py
python3 tools/mashery-service-list.py --filter "Orders"   # search by name
```

### Add an Endpoint (routing rule to Boomi listener)
```bash
python3 tools/mashery-endpoint-create.py \
  --service-id <serviceId> \
  --name "Default" \
  --backend-url "http://runtime-host:9090/ws/rest/orders" \
  --path-alias "/orders"
```

### Create Package + Plan (developer access tier)
```bash
python3 tools/mashery-package-plan-create.py \
  --service-id <serviceId> \
  --endpoint-id <endpointId> \
  --package-name "Orders API Package" \
  --plan-name "Basic" \
  --provision-key
```

### Manage developer keys (lifecycle)
```bash
python3 tools/mashery-key.py list --application-id <appId>
python3 tools/mashery-key.py suspend --application-id <appId> --key-id <keyId>
python3 tools/mashery-key.py rotate  --application-id <appId> --key-id <keyId>
```

### More tools
`mashery-endpoint-update.py`, `-get.py`, `-clone.py`, `-consumers.py`, `mashery-domain-list.py`, `-create.py` — see the full table in [SKILL.md](plugins/boomi-cam/skills/boomi-cam/SKILL.md).

All tools support `--help` for full usage details.

---

## Full Workflow: Expose a Boomi Listener via Mashery

The core end-to-end pattern — which you can drive entirely by asking Claude (the CLI below is just what it runs under the hood):

```
Boomi Integration (WSS listener)  →  Mashery Gateway  →  Developer API Key
```

**Step 1 — Build the Boomi listener** (use the `boomi-integration` skill):
- Create a process with a Web Services Server start shape
- Deploy to a Boomi Integration Runtime with port 9090 accessible from the internet

**Step 2 — Register in Mashery**:
```bash
# Verify credentials
python3 tools/mashery-auth.py

# Create the Service
python3 tools/mashery-service-create.py --name "My API"
# → save serviceId

# Create the Endpoint
python3 tools/mashery-endpoint-create.py \
  --service-id <serviceId> \
  --name "Default" \
  --backend-url "http://runtime-host:9090/ws/rest/myapi" \
  --path-alias "/myapi"
# → save endpointId

# Create Package + Plan + test key
python3 tools/mashery-package-plan-create.py \
  --service-id <serviceId> \
  --endpoint-id <endpointId> \
  --package-name "My API Package" \
  --plan-name "Basic" \
  --provision-key
```

**Step 3 — Test**:
```bash
curl "https://yourcompany.api.mashery.com/myapi?api_key=<provisioned_key>"
```

---

## Reference Documentation

| Document | Description |
|---|---|
| [CAM_THINKING.md](plugins/boomi-cam/skills/boomi-cam/references/CAM_THINKING.md) | Core mental models — read before any CAM work |
| [authentication.md](plugins/boomi-cam/skills/boomi-cam/references/guides/authentication.md) | OAuth flow, credential setup, Area UUID, token caching |
| [concepts.md](plugins/boomi-cam/skills/boomi-cam/references/guides/concepts.md) | Resource hierarchy, terminology, Mashery vs. Boomi Integration |
| [services.md](plugins/boomi-cam/skills/boomi-cam/references/guides/services.md) | Creating, listing, updating, and deleting Services |
| [endpoints.md](plugins/boomi-cam/skills/boomi-cam/references/guides/endpoints.md) | Endpoint routing, auth types, backend URL construction |
| [packages-and-plans.md](plugins/boomi-cam/skills/boomi-cam/references/guides/packages-and-plans.md) | Packages, Plans, and API key provisioning |
| [best-practices.md](plugins/boomi-cam/skills/boomi-cam/references/guides/best-practices.md) | Naming conventions, rate limits, security, production patterns |
| [request-examples.md](plugins/boomi-cam/skills/boomi-cam/references/api/request-examples.md) | Annotated curl examples for all common Mashery V3 API operations |

---

## Getting Started

New to this skill? Start with the [Getting Started guide](docs/getting-started.md).

---

## Repository Structure

```
boomi-cam/
├── .claude-plugin/
│   └── marketplace.json              Claude Code marketplace metadata
├── docs/
│   └── getting-started.md            Step-by-step 15-minute setup guide
├── plugins/
│   └── boomi-cam/
│       ├── .claude-plugin/
│       │   └── plugin.json           Plugin registration config
│       └── skills/
│           └── boomi-cam/
│               ├── SKILL.md          Navigation hub for Claude
│               ├── references/
│               │   ├── CAM_THINKING.md   Core mental models
│               │   ├── guides/           Topic-specific how-to guides
│               │   └── api/              Request examples
│               └── tools/            Python CLI tools (no external deps)
├── .gitignore
├── CONTRIBUTING.md
└── README.md
```

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

---

## Author

**Shawn Aker** — Boomi Platform  
[shawn.aker@boomi.com](mailto:shawn.aker@boomi.com)
