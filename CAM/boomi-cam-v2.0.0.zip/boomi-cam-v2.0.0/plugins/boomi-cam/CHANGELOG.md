# Changelog — boomi-cam

All notable changes to this plugin are documented here. Newest first.

## [2.0.0] — 2026-07-25
**Rebrand + security hardening + key-lifecycle tool.**

### Changed (breaking)
- **Renamed `mashery-apim` → `boomi-cam`** (plugin, marketplace, and directories)
  to match the Boomi Cloud API Management brand. Reinstall required — see Migration.
- **Env vars renamed `MASHERY_*` → `BOOMI_CAM_*`.** Legacy `MASHERY_*` names are
  still honored (one-time deprecation warning); rename them in your `.env`.

### Added
- **`tools/mashery-key.py`** — package-key lifecycle: list / create / suspend /
  activate / revoke / rotate (Application-scoped). Keys masked by default
  (`--show-keys`). (Tool filenames keep the `mashery-` stem — they name the
  underlying Mashery V3 API, not the plugin.)
- Configurable HTTP timeout `BOOMI_CAM_HTTP_TIMEOUT` (default 60s, `0`=off).
- `.env.example`, gitleaks pre-commit config, and a secret-scan CI workflow.

### Security
- Scrubbed real test-area identifiers/tokens from committed docs → placeholders.
- Secrets masked by default in `mashery-auth`, `mashery-package-plan-create`,
  and `mashery-endpoint-consumers` (`--show-*` to reveal).
- `get_member_id()` returns `None` on no username match (no arbitrary-member
  key provisioning).

### Migration (from 1.x)
1. Reinstall: `/plugin marketplace remove mashery-apim` (if present), then
   `/plugin marketplace add boomi-internal/boomi-cam` and
   `/plugin install boomi-cam@boomi-cam`.
2. In your `.env`, rename `MASHERY_*` → `BOOMI_CAM_*` (or keep the legacy names
   for now — they still work, with a deprecation warning).

## [1.4.1] — 2026-06-17
**Author:** Yohanes W Sono <yohanes.sono@boomi.com>

### Added
- **Endpoint Call Transformation (`processor`) support** on
  `mashery-endpoint-create.py` and `mashery-endpoint-update.py`:
  - `--sdk-processors "A[,B]"` — custom SDK adapter(s). ONE class → set as
    `adapter` **directly**; MULTIPLE → `Mashery_Proxy_Processor_Chain` with a
    comma `processors` list. `--sdk-pre-processors`/`--sdk-post-processors` for
    differing stages; `--pre-process`/`--post-process true|false` to toggle.
  - `--processor-adapter NAME --pre-inputs JSON --post-inputs JSON` — named
    Boomi connector / explicit adapter with full control.
  - `--clear-processor` — remove it (sends empty adapter + disabled stages;
    `processor:null` → 500 and `processor:{}` only merges, so neither clears).
- **Backend timeout flags**: `--connect-timeout N`
  (`connectionTimeoutForSystemDomainRequest`, validated **2–7s**) and
  `--response-timeout N` (`connectionTimeoutForSystemDomainResponse`, **≥ 2**).
- `tools/mashery_paths.py` — shared `build_processor()`, `add_processor_args()`,
  `apply_processor_args()`, and the `PROCESSOR_CHAIN_ADAPTER` /
  `CONNECT_TIMEOUT_ALLOWED` constants.

### Discovered (live, documented in `FIELD_NOTES.md`)
- A **single** custom SDK processor is named directly in `processor.adapter`
  (no chain); the chain is only for **multiple** processors.
- `connectionTimeoutForSystemDomainRequest` (connect) is **2–7s only** — a
  distinct, stricter bound than the RESPONSE timeout (≥ 2). Corrected the earlier
  note that lumped them together.
- Clearing a processor needs an explicit empty-adapter + disabled body.

### Docs
- `references/guides/endpoints.md` — new "Call Transformation (processor)" and
  "Backend timeouts" sections; corrected the clone-section timeout bullet.
  `SKILL.md` — tool table + routing.

### Verified
- Live against area `00000000-0000-0000-0000-000000000000`: single-direct, chain,
  named-connector, split pre/post, clear, and connect-timeout accept/reject all
  pass via `mashery-endpoint-update.py`. Throwaway resources deleted.

## [1.4.0] — 2026-06-16
**Author:** Yohanes W Sono <yohanes.sono@boomi.com>

### Added
- **`tools/mashery-endpoint-clone.py`** — "seamless" endpoint clone: GET the
  source endpoint's full config → deep-copy → strip server keys → apply only the
  overrides you pass (`--name`, `--path-alias`, `--public-domain`, `--inbound-ssl`)
  → POST to `--target-service-id`, then copy the source's API **methods**
  (`--no-copy-methods` to skip). Every non-overridden field is preserved
  (apiKeyValueLocations, supportedHttpMethods, CircuitBreaker `processor`,
  `systemDomainAuthentication`, connection timeouts, headers, `cache`,
  `highSecurity`). The backend secret is copied **in-process** (never on the CLI)
  and masked in output.
- **`tools/mashery-endpoint-get.py`** — dump an endpoint's full config (requests
  the complete field set, working around the minimal-GET projection). `--json`
  for `diff <(get A) <(get B)`; `--raw-secret` to unmask the backend password.
- `tools/mashery_paths.py` — `ENDPOINT_FULL_FIELDS` and `strip_server_keys()`.

### Discovered (live, documented in `FIELD_NOTES.md`)
- `GET .../endpoints/{id}?fields=*` returns an **empty** object — fields must be
  enumerated explicitly.
- A copy-all-but-`id`/`created`/`updated` clone is faithful: cloning a
  CircuitBreaker-protected camara endpoint (overriding only name + path) yielded a
  **zero-difference** config diff vs the source.
- `methods` are **sub-resources** (not created by the endpoint POST) — copied via
  a follow-up `POST .../endpoints/{id}/methods`.
- `connectionTimeout*` floor is **2** (not the assumed "2–7"): `1` → 400; `2`, `7`,
  `8`, `10` all accepted.

### Docs
- `references/guides/endpoints.md` — new "Cloning an Endpoint" section (clone +
  get-for-diff workflow and the verified constraints). `SKILL.md` — layout, tool
  table, routing row.

### Verified
- Live against area `00000000-0000-0000-0000-000000000000`: cloned
  `camara-number-verification-v2` to a throwaway service; full-config diff showed
  only the overrides; the "verify" method was copied; the backend secret did not
  appear in output. Throwaway service deleted.

## [1.3.0] — 2026-06-16
**Author:** Yohanes W Sono <yohanes.sono@boomi.com>

### Added
- **`tools/mashery-endpoint-update.py`** — update an existing endpoint with a
  **partial PUT** (V3 PUT merges, so only the passed fields change). Supports
  `--name`, `--backend-url`, `--path-alias`, `--methods`, `--auth`, `--ssl/--no-ssl`,
  backend auth (`--backend-auth-type httpBasic` + creds), and `--clear-backend-auth`.
  Reads the result back with an explicit `fields` list and masks the backend secret.
- **Backend authentication on `tools/mashery-endpoint-create.py`** — new
  `--backend-auth-type httpBasic --backend-user … --backend-password …` (the
  endpoint `systemDomainAuthentication`, i.e. the outbound auth Mashery presents
  to a secured backend such as a Boomi listener). Aliases match the requested
  naming: `--system-domain-auth basic` / `--system-user` / `--system-pass`. The
  password may instead come from env **`MASHERY_BACKEND_PASSWORD`** so it never
  appears on the command line; output masks it to `***`. The create tool now also
  re-reads the endpoint with explicit fields (the POST response is minimal).
- `tools/mashery_paths.py` — shared `ENDPOINT_FIELDS`, `build_system_domain_auth()`,
  and `mask_system_domain_auth()` helpers.

### Discovered (live, documented in `FIELD_NOTES.md`)
- **GET on a single endpoint returns a minimal projection** (`id`/`name`/`created`/
  `updated`) unless an explicit `fields` list is passed — the POST create response
  is minimal too.
- **Partial PUT on an endpoint MERGES** — unsent fields are preserved; send
  `systemDomainAuthentication: null` to clear backend auth.
- `systemDomainAuthentication` `{type: httpBasic, username, password}` persists and
  reads back (password in clear text — tools mask it).

### Docs
- `references/guides/endpoints.md` — new "Backend Authentication" and rewritten
  "Updating an Endpoint" sections (merge behavior + the minimal-GET gotcha).
- `references/api/request-examples.md` — backend-auth create, partial-PUT update,
  and the explicit-`fields` GET note. `SKILL.md` — layout, tool table, routing.

### Verified
- Live against area `00000000-0000-0000-0000-000000000000`: create-with-backend-auth
  (alias flags + env password) persists and doesn't leak the secret; partial update
  merges (path alias + backend auth preserved); `--clear-backend-auth` nulls it;
  `--auth none` rejected. All throwaway resources deleted.

## [1.2.2] — 2026-06-16
**Author:** Yohanes W Sono <yohanes.sono@boomi.com>

### Fixed
- **`tools/mashery-endpoint-create.py` `--auth none` was broken.** Mashery V3 has
  no unauthenticated endpoint type; the parser maps any unrecognized
  `requestAuthenticationType` (including `"none"`) to `custom`, producing a
  misleading `400 "customRequestAuthenticationAdapter is required if
  requestAuthenticationType is custom."` The tool now **rejects `--auth none` up
  front** with an explanation (use `apiKey`, or the Control Center UI for a
  keyless endpoint), adds **`apiKeyAndSecret_SHA256`** as a real `--auth` choice,
  and only sets the key-value-location fields for the key-based types. (Verified
  live: `none`/`open`/`public`/… → 400; `apiKey`/`apiKeyAndSecret_SHA256` → 200;
  *omitting* the field defaults to `apiKey`, so it is set explicitly.)

### Changed
- **`tools/mashery-package-plan-create.py`** now surfaces the provisioned
  Application's `status` and the key's `status`, plus a NOTE when the Application
  is `draft`. The V3 API creates applications in `draft` and **cannot activate
  them** (`PUT status→active` → `400 "Please choose a different value"`); in this
  area every application reads as `draft` — including ones with working keys — so
  draft is expected and the key's own `status: active` governs access. (Activate
  an app only via the Control Center UI, if ever needed.)

### Docs
- `references/guides/endpoints.md` — removed the bogus `none` auth value from the
  field table and the auth-type table; added a "No unauthenticated endpoints"
  section (and the omit-defaults-to-apiKey trap). `SKILL.md` — new Error Patterns
  row for the `custom` adapter 400.

### Verified
- Live against area `00000000-0000-0000-0000-000000000000`: `--auth none` fails
  fast (no API call); full `--provision-key` run prints app/key status + draft
  note. All throwaway artifacts deleted (`DELETE` → 200).

## [1.2.1] — 2026-06-16
**Author:** Yohanes W Sono <yohanes.sono@boomi.com>

### Fixed (`tools/mashery-package-plan-create.py`)
- **`POST /packages` 400 "Property 'notifyDeveloperPeriod' is required."** — the
  package body sent `notifyDeveloperPeriod: "never"` (since 1.0.0), which the V3
  API rejects: `"never"` is an invalid enum value and Mashery reports it as if
  the field were *missing*. Now sends a real period (default `"day"`), with a new
  `--notify-period` arg (`minute|hour|day|week|month`). Verified live: `"never"`
  → 400; omitted/`day`/`week`/`month`/`hour`/`minute` → 200.
- **Key provisioning `404`** — `--provision-key` POSTed to
  `packages/{id}/plans/{id}/members/{id}/keys`, which returns 404 (and
  `POST /packageKeys` returns `"Method not found"`). V3 package keys are
  **Application-scoped**. `--provision-key` now finds-or-creates an Application
  for the member (`--app-name`, default `"<package> App"`) and creates the key
  under `POST /applications/{appId}/packageKeys` with package/plan refs. The
  summary now also prints the generated **secret**.

### Docs
- `references/api/request-examples.md` & `references/guides/packages-and-plans.md`
  — corrected the package `notifyDeveloperPeriod` example/enum (was `"never"`
  and a wrong `never/daily/weekly/monthly` value list) and rewrote
  "Admin-provision a key" to the Application-scoped two-step flow.
- `SKILL.md` — two new rows in the Error Patterns table (the notify-period 400
  and the key-provisioning 404).

### Verified
- Live against area `00000000-0000-0000-0000-000000000000` (service `Contact`):
  full `mashery-package-plan-create.py --provision-key` run creates Package +
  Plan + Application + active Key (apikey + secret returned). All throwaway
  artifacts deleted afterward (`DELETE` on packages/applications/keys → 200).

## [1.2.0] — 2026-06-16
**Author:** Yohanes W Sono <yohanes.sono@boomi.com>

### Added
- **`tools/mashery-domain-list.py`** — list the area's whitelisted public
  domains (`GET /v3/rest/domains`). Supports `--filter` (domain substring) and
  `--json`. Uses `mashery_get_all()` (the resource is a bare array, same shape
  as `/services`).
- **`tools/mashery-domain-create.py`** — register (whitelist) a public domain
  (`POST /v3/rest/domains`) with `--domain` and optional `--description`. Closes
  the gap where the only way to inspect/add area domains was raw curl.
- `SKILL.md` — tool-table rows, routing entry, a "Manage area public domains"
  workflow, and scope-boundary updates.
- `references/guides/endpoints.md` — new "Public Domain Whitelist" section
  (a host must be whitelisted before it can be an endpoint `publicDomains`/
  `systemDomains` address).
- `references/api/request-examples.md` — new "Public Domains" section
  (list / create / description-only update / delete-is-403).

### Discovered (live, documented in `FIELD_NOTES.md`)
- **Creating a public domain via the V3 API is supported** (`POST /domains` →
  200, "…has been whitelisted") — it is *not* Control-Center-UI-only. This was
  the open question the new tool was meant to settle.
- `DELETE /domains/{id}` → **403 Forbidden** (UI-only removal); `PUT` is
  **description-only** (`domain`/`status` immutable). The `/publicDomains` and
  `/systemDomains` resource names both 404 — the resource is `/domains`.

### Verified
- Live against area `00000000-0000-0000-0000-000000000000`: `mashery-domain-list.py`
  returns 9 domains and `--filter mashery` narrows to 1; create path confirmed
  via a live `POST` (200).

## [1.1.2] — 2026-06-15
**Author:** Yohanes W Sono <yohanes.sono@boomi.com>

### Docs (correction)
- `references/guides/authentication.md` — corrected where the API key comes from.
  1.1.1 wrongly implied the **service account** issues `MASHERY_API_KEY` /
  `MASHERY_API_SECRET`. They actually come from the **developer portal**:
  **developer.mashery.com → My Account → Keys → "Mashery API: V2 + V3"** (the
  **Key** / **Secret** fields). The Area **service account** only supplies
  `MASHERY_USERNAME` / `MASHERY_PASSWORD` (the password grant). Rewrote the
  "Getting Credentials" section into two clearly separate sources (A: portal key,
  B: area account), fixed the credentials table, `.env` block, "Issuing the API
  Key" section, and the `SKILL.md` first-time note accordingly.
- Noted the Key Activity page shows the key's rate limits (2/sec, 5,000/day),
  corroborating the client-side throttle defaults.

## [1.1.1] — 2026-06-15
**Author:** Yohanes W Sono <yohanes.sono@boomi.com>

### Docs
- `references/guides/authentication.md` — new **"Getting Mashery V3 API
  Credentials"** section answering "where do I get these?":
  - A Boomi/SSO login does **not** grant a V3 API key — you need a dedicated
    **service account** (Area Administrator role + **Service User** flag), issued
    a V3 API key, per the Boomi Community article (linked).
  - Documented the expected *"There is a problem with your permissions…"* message
    when a Service User tries to log into the Control Center (API-only account).
  - Clear `.env`-var → credential mapping, a copy-paste `.env` block, and
    `https://support.mashery.com/member/register` / community-article links.
  - "Issuing API Keys" reframed around the service account; 403 troubleshooting
    now points at the Area Administrator role + Service User flag.
- `SKILL.md` — first-time setup checklist now flags the service-account
  requirement up front.

## [1.1.0] — 2026-06-15
**Author:** Yohanes W Sono <yohanes.sono@boomi.com>

### Added
- **`tools/mashery-endpoint-consumers.py`** — reverse-lookup that answers "which
  Applications and Packages consume this endpoint?" Given an endpoint `--name`
  and/or `--path`, it chains `Endpoint → Service → Plan → Package → PackageKey →
  Application`:
  - **Step 1** — `GET /packages` with nested `plans.services.endpoints` and
    matches the endpoint (case-insensitive substring, or `--exact`), collecting
    the granting Package + **Plan** IDs.
  - **Step 2** — `GET /packageKeys?filter=package.id:<id>` with nested
    `application` / `member` / `plan` — resolves the consuming Applications and
    their owners in one call (no `/applications` lookup).
  - **Step 3** — narrows to keys whose Plan actually grants the matched endpoint
    (a Package holds several Plans; only some grant the target).
  - `--json` for machine-readable output; prints a flat "consuming applications"
    owner summary.
- `tools/mashery_paths.py` — `mashery_get_all()` gains `index_pagination`
  (page-index offset for `/packageKeys` & `/applications`, vs. the default
  record-offset) plus de-dup-by-`id` and a `max_pages` safety cap.
- `references/guides/packages-and-plans.md` — new "Reverse Lookup" section;
  `SKILL.md` — tool entry, routing row, and a reverse-lookup workflow.

### Discovered (live, documented in `FIELD_NOTES.md`)
- `/applications?filter=packageKeys.package.id:<id>` is rejected as
  `ERR_INVALID_FIELD` — consumers are resolved from PackageKeys instead.
- `requestPathAlias` is `null` in the nested package projection, so endpoint
  **name** matching is the reliable path.

### Verified
- Live against area `00000000-0000-0000-0000-000000000000`: `--name AntiFraud`
  (Gold-only → 2 of 5 keys), `--name Contact` (bronze+silver, 2 apps),
  `--name materialPrice --json` all return correct consumers.

## [1.0.2] — 2026-06-15
**Author:** Yohanes W Sono <yohanes.sono@boomi.com>

### Added
- **Client-side rate limiting** for the Mashery management API key (default **2 calls/sec, 5,000/day**), in `tools/mashery_paths.py`:
  - QPS throttle on every call (spaces requests to stay ≤ QPS — prevents `mashery_get_all()` pagination from bursting past the limit).
  - Best-effort per-day call counter (OS temp dir, keyed by area + UTC date): fails fast at the daily cap with a clear message, warns at 90%.
  - QPS rejections (HTTP 429 / `X-Mashery-Error-Code: *OVER_QPS*`) retried with exponential backoff; daily/quota rejections abort with guidance to raise the quota via Boomi Support.
  - Overridable via `.env`: `MASHERY_API_QPS`, `MASHERY_API_DAILY` (for keys with a raised quota).
- `references/guides/best-practices.md` — new "Mashery Management API Rate Limit" section (distinct from the consumer/plan rate-limit section).

### Verified
- Live: throttle holds 5 sequential GETs to ~4.4s (≥ the 2 QPS floor) while `mashery-service-list.py` still returns correct results.

## [1.0.1] — 2026-06-15
**Author:** Yohanes W Sono <yohanes.sono@boomi.com>

### Fixed
- **V3 collection endpoints return a bare JSON array, not an `{items, totalCount}` envelope.** Tools called `result.get("items")` on the response (a `list`), crashing with `AttributeError: 'list' object has no attribute 'get'`.
  - `tools/mashery-service-list.py` — crashed on every run.
  - `tools/mashery-package-plan-create.py` (`get_member_id`) — same crash on `--provision-key`.
- `references/guides/services.md` — "List Services → Response" documented the wrong envelope shape (the source of the bug); corrected to a bare array with a gotcha callout.
- `references/guides/authentication.md` — token example showed a JWT (`eyJ...`); V3 tokens are short opaque strings (~24 chars) and `token_type` is lowercase `bearer`. Corrected.

### Added
- `tools/mashery_paths.py` — `normalize_collection()` and `mashery_get_all()` (bare-array/envelope/single-object normalization + `limit`/`offset` pagination). Reuse these in any new tool that reads a collection.
- `FIELD_NOTES.md` (repo root) — running log of live-API discoveries.

### Verified
- Tested live against area `00000000-0000-0000-0000-000000000000`: `mashery-service-list.py` returns 3 services and `--filter` works; all tools compile clean.

## [1.0.0]
**Author:** Shawn Aker <shawn.aker@boomi.com>
- Initial release: auth, service/endpoint/package-plan tools, reference guides.
