# Mashery Core Concepts

## What is Boomi Cloud API Management?

Boomi Cloud API Management is the Mashery platform, acquired by Boomi from TIBCO. It is a **full lifecycle API management platform** that:

- Proxies inbound API traffic (acts as a reverse proxy)
- Enforces authentication (API keys, OAuth)
- Applies rate limiting and throttling
- Routes requests to backend systems (e.g., Boomi Integration listeners)
- Provides a developer portal and key management

Mashery is a **separate product** from Boomi Integration. The two integrate by pointing a Mashery Endpoint at the URL of a Boomi web service listener.

---

## Resource Hierarchy

```
Area  (your organization/tenant in Mashery)
│
├── Service  (represents one API — the logical grouping)
│   ├── name, description, version, security profile
│   └── Endpoint  (one URL path + backend routing rule)
│       ├── requestPathAlias   ← what clients call (e.g. /orders)
│       ├── systemDomains      ← your backend host (e.g. atom.boomi.com:9090)
│       ├── outboundRequestTargetPath  ← backend path (e.g. /ws/rest/orders)
│       ├── requestAuthenticationType  ← apiKey | oauth | none
│       └── Method  (optional per-HTTP-method overrides)
│
├── Package  (a bundle for distribution — appears in developer portal)
│   └── Plan  (access tier within the package — defines rate limits + key rules)
│       ├── rateLimitCeiling / qpsLimitCeiling
│       └── Service+Endpoint associations  ← which APIs this plan grants access to
│
└── Application  (a developer's registered app — created by developers)
    └── Key  (API key tied to an Application + Plan)
```

---

## Terminology Quick Reference

| Term | Meaning |
|------|---------|
| **Area** | Your Mashery tenant/org. Has a UUID (the "area UUID" in the token scope). |
| **Service** | The API definition object. One service = one logical API. Holds metadata, security profile, and endpoints. |
| **Endpoint** | A URL path on the Mashery gateway that proxies to a specific backend URL. A Service can have multiple endpoints. |
| **Traffic Manager Domain** | The Mashery-hosted hostname clients use to call your API (e.g. `mycompany.api.mashery.com`). Set at the area level. |
| **System Domain** | Your backend hostname — where Mashery forwards requests to. For Boomi this is your Atom's hostname/IP + port. |
| **Request Path Alias** | The inbound path clients append to the Traffic Manager Domain (e.g. `/orders`). |
| **Package** | A distributable bundle of plans. Appears in the developer portal. |
| **Plan** | A rate/access tier within a Package. Controls QPS, daily call limit, and which services/endpoints are accessible. |
| **Key** | A developer's API key, tied to a specific Plan. Passed by clients as a query parameter or header. |

---

## Boomi Integration + Mashery Integration Pattern

```
Developer App
    │  GET https://mycompany.api.mashery.com/orders?api_key=abc123
    ▼
Mashery Traffic Manager
    │  validates api_key, checks rate limits
    │  GET http://atom-host:9090/ws/rest/orders
    ▼
Boomi Atom (Web Services Server listener)
    │  executes integration process
    ▼
Response flows back up the chain
```

**What you configure in Boomi Integration:**
- A process with a **Web Services Server** (WSS) start shape
- The process is deployed to an Atom with a configured port (default 9090)
- The listener path is typically `/ws/rest/<service-name>`

**What you configure in Mashery:**
- A **Service** (logical API definition)
- An **Endpoint** where:
  - `systemDomains` = Atom hostname
  - `outboundRequestTargetPath` = `/ws/rest/<service-name>`
  - `requestPathAlias` = the public-facing path clients will call
- A **Package + Plan** to issue API keys

---

## V3 API Base URL

All Mashery V3 management API calls use:
```
https://api.mashery.com/v3/rest/
```

Authentication token endpoint:
```
https://api.mashery.com/v3/token
```

---

## Field ID vs. Name

Mashery API responses include both `id` (UUID string) and `name` fields. **Always use `id`** when referencing resources in subsequent calls — names are not unique across an area and are not accepted as path parameters.

Example service response:
```json
{
  "id": "abc123-...",
  "name": "Orders API",
  "created": "2024-01-01T00:00:00Z",
  "updated": "2024-01-01T00:00:00Z"
}
```

---

## Pagination

List endpoints return paginated results:
```
GET /v3/rest/services?limit=100&offset=0
```

Default `limit` is 100. If `totalCount` in the response exceeds `limit`, page through with `offset`. The `mashery-service-list.py` tool handles pagination automatically.

---

## Fields Parameter

To reduce response size, request only needed fields:
```
GET /v3/rest/services?fields=id,name,description
```

This is especially useful when listing resources with many fields.
