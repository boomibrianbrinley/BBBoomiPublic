# Packages, Plans, and API Keys

## Overview

To expose an API to developers, you need three things:

1. **Package** — a distributable bundle (shown in the developer portal)
2. **Plan** — an access tier within the package (defines rate limits + which APIs are accessible)
3. **Key** — an API key tied to an Application + Plan (how developers authenticate calls)

The Plan links back to the Service and Endpoint created earlier, completing the full access chain:

```
Package → Plan → [Service + Endpoint] → Key → API Access
```

---

## Create a Package + Plan (CLI tool — recommended)

The `mashery-package-plan-create.py` tool creates the Package and Plan in one command and optionally provisions a test key:

```bash
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-package-plan-create.py \
  --service-id <serviceId> \
  --endpoint-id <endpointId> \
  --package-name "Orders API Package" \
  --plan-name "Basic" \
  --qps 10 \
  --rate-limit 1000 \
  --rate-period day \
  --max-keys 2 \
  --provision-key
```

The `--provision-key` flag automatically provisions an API key for your account — ready to test immediately.

---

## Create a Package (API directly)

```
POST https://api.mashery.com/v3/rest/packages
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Orders API Package",
  "description": "Access to the Orders API",
  "notifyDeveloperPeriod": "day",
  "notifyDeveloperNearQuota": false,
  "notifyDeveloperOverQuota": false,
  "notifyDeveloperOfKeyChanges": false,
  "generateSecrets": true,
  "sharedSecretLength": 10
}
```

> **Gotcha — `notifyDeveloperPeriod` is required and `"never"` is rejected.**
> Valid values are the singular periods `minute` | `hour` | `day` | `week` |
> `month` (verified live). Sending `"never"` returns a *misleading*
> `400 "Property 'notifyDeveloperPeriod' is required."` — Mashery reports an
> unrecognized enum as if the field were absent. Omitting the field also works
> and the area defaults it to `"day"`. Since the near/over-quota notify flags
> are `false`, the period is inert unless those are later enabled.

### Package Fields

| Field | Type | Default | Notes |
|-------|------|---------|-------|
| `name` | string | required | Unique package name |
| `description` | string | `""` | Shown in developer portal |
| `notifyDeveloperPeriod` | string | `"day"` | Quota email frequency: `minute`\|`hour`\|`day`\|`week`\|`month`. **`"never"` is rejected** (400 — see gotcha above). |
| `generateSecrets` | boolean | `true` | Generate shared secrets with keys |
| `sharedSecretLength` | integer | `10` | Length of generated shared secrets |

### Package Response

```json
{
  "id": "pkg-uuid-here",
  "name": "Orders API Package",
  "created": "2024-01-01T00:00:00.000+0000"
}
```

**Save the `id` as `packageId`.**

---

## Create a Plan (API directly)

```
POST https://api.mashery.com/v3/rest/packages/{packageId}/plans
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Basic",
  "description": "Basic access plan with standard rate limits",
  "selfServiceKeyProvisioningEnabled": false,
  "adminKeyProvisioningEnabled": true,
  "numKeysBeforeReview": 1,
  "maxNumKeysAllowed": 2,
  "qpsLimitCeiling": 10,
  "rateLimitCeiling": 1000,
  "rateLimitPeriod": "day",
  "services": [
    {
      "id": "<serviceId>",
      "endpoints": [
        {"id": "<endpointId>"}
      ]
    }
  ]
}
```

### Plan Fields

| Field | Type | Default | Notes |
|-------|------|---------|-------|
| `name` | string | required | Plan display name |
| `qpsLimitCeiling` | integer | `0` | Max queries per second (0 = unlimited) |
| `rateLimitCeiling` | integer | `0` | Max calls per `rateLimitPeriod` (0 = unlimited) |
| `rateLimitPeriod` | string | `"day"` | `"minute"`, `"hour"`, `"day"`, `"month"` |
| `maxNumKeysAllowed` | integer | `0` | Max keys a developer can create (0 = unlimited) |
| `numKeysBeforeReview` | integer | `1` | Keys before requiring admin review |
| `adminKeyProvisioningEnabled` | boolean | `true` | Allow admins to provision keys directly |
| `selfServiceKeyProvisioningEnabled` | boolean | `false` | Allow developers to self-provision |
| `services` | array | `[]` | List of Service+Endpoint associations — **critical** |

### The `services` Array — Critical Field

This is what links the Plan to the API. Without it, the Plan grants access to nothing:

```json
"services": [
  {
    "id": "service-uuid",
    "endpoints": [
      {"id": "endpoint-uuid"}
    ]
  }
]
```

- Use the `serviceId` and `endpointId` from the previous steps
- A Plan can grant access to endpoints from multiple services

### Plan Response

```json
{
  "id": "plan-uuid-here",
  "name": "Basic",
  "qpsLimitCeiling": 10,
  "rateLimitCeiling": 1000,
  "rateLimitPeriod": "day",
  "services": [{"id": "...", "endpoints": [{"id": "..."}]}],
  "created": "2024-01-01T00:00:00.000+0000"
}
```

**Save the `id` as `planId`.**

---

## Create a Key (Admin-Provisioned)

Admin-provisioned keys allow you to immediately test the API without requiring a developer to self-register.

> **Keys are Application-scoped.** A package key belongs to an **Application**
> (owned by a member), not directly to a member/plan. The intuitive
> `POST .../packages/{id}/plans/{id}/members/{id}/keys` returns **404 Not Found**,
> and `POST /packageKeys` returns `"Method not found"`. Provisioning is therefore
> three steps: find the member → ensure the member owns an Application → create
> the key under that Application. `mashery-package-plan-create.py --provision-key`
> does all three automatically (it auto-creates an Application named
> `"<package-name> App"`, override with `--app-name`).

### Step 1 — Get your member ID

```
GET https://api.mashery.com/v3/rest/members?filter=username:<your_email>&fields=id,username
Authorization: Bearer <token>
```

### Step 2 — Ensure the member owns an Application

```
POST https://api.mashery.com/v3/rest/members/{memberId}/applications
Authorization: Bearer <token>
Content-Type: application/json

{ "name": "My App", "username": "<member_username>" }
```

Reuse an existing Application instead by listing
`GET /v3/rest/members/{memberId}/applications` and picking one.

### Step 3 — Create the key under the Application

```
POST https://api.mashery.com/v3/rest/applications/{applicationId}/packageKeys
Authorization: Bearer <token>
Content-Type: application/json

{
  "apikey": "",
  "secret": "",
  "status": "active",
  "limits": [],
  "package": {"id": "<packageId>"},
  "plan": {"id": "<planId>"}
}
```

Setting `apikey` and `secret` to empty strings lets Mashery auto-generate them.

### Key Response

```json
{
  "id": "key-uuid",
  "apikey": "EXAMPLE_API_KEY",
  "secret": "EXAMPLE_SECRET",
  "status": "active",
  "limits": [{"period": "second", "source": "plan", "ceiling": 10}],
  "created": "2024-01-01T00:00:00.000+0000"
}
```

**The `apikey` value is what you pass as `?api_key=<value>` when calling the gateway.**

---

## List Packages

```
GET https://api.mashery.com/v3/rest/packages?fields=id,name,description
Authorization: Bearer <token>
```

## List Plans for a Package

```
GET https://api.mashery.com/v3/rest/packages/{packageId}/plans
Authorization: Bearer <token>
```

---

## Reverse Lookup — which Applications / Packages consume an endpoint

The CAM object model is one-directional: `Endpoint → Service → Plan → Package →
PackageKey → Application`. There is no API that answers "given this endpoint, who
uses it?" directly — you chain calls back down the hierarchy. The
`mashery-endpoint-consumers.py` tool automates this:

```bash
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-consumers.py --name "<endpoint name>"
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-consumers.py --path "/<request-path>"
```

### Step 1 — Build the Package / Plan / Endpoint map

`plans` (and their nested services/endpoints) are **not** returned by default —
you must request them explicitly in `fields`:

```
GET https://api.mashery.com/v3/rest/packages?fields=id,name,plans.id,plans.name,plans.services.id,plans.services.endpoints.id,plans.services.endpoints.name,plans.services.endpoints.requestPathAlias&limit=100&offset=0
Authorization: Bearer <token>
```

Walk `plans[].services[].endpoints[]` and match the target endpoint by `name` or
`requestPathAlias`. Record the **Package ID** and the **Plan ID(s)** that contain
it — the Plan matters because a Package usually holds several plans and only some
grant the target endpoint. Paginate by incrementing `offset` by the page size.

> **Gotcha:** in this nested package projection, `requestPathAlias` frequently
> comes back `null`. Match by endpoint **name** when path matching returns
> nothing, and confirm the path field name for your area.

### Step 2 — Resolve PackageKeys (carry the Application + owner + Plan)

For each matched Package, the PackageKeys already carry the consuming Application,
its owner (member), and the Plan — so one call resolves the consumers:

```
GET https://api.mashery.com/v3/rest/packageKeys?filter=package.id:<PACKAGE_ID>&fields=id,apikey,status,member.id,member.username,application.id,application.name,package.id,plan.id,plan.name&limit=100&offset=0
Authorization: Bearer <token>
```

For `/packageKeys`, `offset` behaves as a **page index** (0, 1, 2, …), not a
record offset.

### Step 3 — Narrow to the granting Plan(s)

Keep only the PackageKeys whose `plan.id` is one of the Plan IDs collected in
Step 1 — those are the keys (and Applications) that genuinely consume the target
endpoint. Each key's nested `application` and `member` give you the app name,
app ID, and owner.

> **Note:** `/applications` does **not** accept a `packageKeys.package.id` filter
> (the area returns `ERR_INVALID_FIELD`). Resolve the consuming Applications from
> the PackageKeys (above) rather than from `/applications` — it's also one fewer
> call per package.

---

## Full Flow Summary

```
1. POST /v3/rest/services                                              → serviceId
2. POST /v3/rest/services/{serviceId}/endpoints                        → endpointId
3. POST /v3/rest/packages                                              → packageId
4. POST /v3/rest/packages/{packageId}/plans  (include serviceId+endpointId in services[])  → planId
5. GET  /v3/rest/members?filter=username:<email>                       → memberId
6. POST /v3/rest/packages/{packageId}/plans/{planId}/members/{memberId}/keys  → apikey
7. Test: GET https://<BOOMI_CAM_TRAFFIC_DOMAIN>/<requestPathAlias>?api_key=<apikey>
```

---

## Common Errors

| Status | Meaning | Fix |
|--------|---------|-----|
| `400` "services not found" | Invalid serviceId or endpointId in Plan `services` array | Verify IDs using `mashery-service-list.py` |
| `409` "plan name already exists" | Duplicate plan name within package | Use a unique plan name |
| `404` on member key creation | Wrong memberId | Re-fetch member ID from the members endpoint |
| `400` "maxNumKeysAllowed exceeded" | Developer already at key limit | Increase `maxNumKeysAllowed` in plan, or delete an existing key |
