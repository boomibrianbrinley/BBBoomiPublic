# Best Practices

## Naming Conventions

**Services:**
- Use a descriptive API name: `"Orders API"`, `"Customer Profile API"`, `"Inventory API"`
- Include version in the version field, not the name: name=`"Orders API"`, version=`"v1"` (not name=`"Orders API v1"`)
- For Boomi-backed services, note it in the description: `"...backed by Boomi Integration"`

**Endpoints:**
- Use `"Default"` for the primary endpoint name when a Service has only one
- For multi-endpoint services, use the HTTP method or resource path: `"GET /orders"`, `"POST /orders"`
- Keep `requestPathAlias` lowercase and hyphen-separated: `/customer-orders` not `/customerOrders`

**Packages:**
- Name after the API: `"Orders API Package"`, `"Customer API Package"`
- One Package per API unless you have specific multi-API bundle requirements

**Plans:**
- Name after the access tier: `"Basic"`, `"Standard"`, `"Enterprise"`, `"Internal"`
- Use consistent tier names across your API portfolio so developers understand what they're getting

**Keys:**
- Admin-provisioned test keys should be tracked in your project notes with the associated service/plan
- Rotate test keys periodically — they are real credentials with real access

---

## Rate Limiting Strategy

Set rate limits based on your Boomi Atom's capacity, not arbitrary numbers:

| Scenario | Recommended Settings |
|----------|---------------------|
| Development/testing | `--qps 10 --rate-limit 1000 --rate-period day` |
| Internal production | `--qps 50 --rate-limit 50000 --rate-period day` |
| External/public API | `--qps 10 --rate-limit 10000 --rate-period day` per key |
| High-volume integration | `--qps 100 --rate-limit 0` (unlimited daily) |

- Set `qpsLimitCeiling` to protect the Atom from traffic spikes
- Set `rateLimitCeiling` to provide a daily budget for developers
- Start conservative — it is easier to increase limits than to explain why an API was throttled

> **Don't confuse this with the management-API key limit below.** The settings above are the limits you impose on *consumers of your APIs*. The next section is about the limit on the *admin key these tools use to call the Mashery V3 API*.

---

## Mashery Management API Rate Limit (the key these tools use)

The Mashery developer/application key used by these tools to call the V3 REST API is itself rate limited. The **default** is:

| Limit | Default value |
|-------|---------------|
| Calls per second | **2** |
| Calls per day | **5,000** |

To raise the QPS quota (e.g. to 10/sec), **contact Boomi Support** — it cannot be self-served.

**The tools self-throttle to these limits automatically** (in `mashery_paths.py`):
- Outbound calls are spaced to stay at/under the QPS — important because `mashery_get_all()` pagination can otherwise burst past 2/sec.
- A best-effort **per-day counter** (in the OS temp dir, keyed by area + UTC date) makes a run fail fast with a clear message at the 5,000/day cap, and warns at 90%.
- A QPS rejection (HTTP 429 / `X-Mashery-Error-Code` containing `OVER_QPS`) is **retried with exponential backoff**; a daily/quota rejection aborts with guidance to contact Support.

**Override the defaults** if your key has a higher quota — add to `.env`:

```
BOOMI_CAM_API_QPS=10        # calls per second (default 2)
BOOMI_CAM_API_DAILY=50000   # calls per day   (default 5000)
```

> If you see `NOTE: hit Mashery QPS limit … retry`, the throttle is working — the run will continue. If you see the daily-limit error, you have exhausted the key's 5,000/day; wait for the UTC reset or raise the quota.

---

## Security Practices

**Credentials:**
- Never commit `.env` files — the `.gitignore` in this repo excludes them
- Use separate Mashery developer app keys for each environment (dev/test/prod)
- Rotate application API keys and secrets periodically
- Use a dedicated Mashery admin account for automation — not a personal account

**API Keys:**
- Prefer `apiKey` auth for internal/Boomi-to-Boomi APIs (simple, manageable)
- Use `oauth` auth for external developer-facing APIs
- For highly sensitive APIs, use `apiKeyAndSecret_SHA256` (HMAC-signed)
- Admin-provision test keys for developers rather than sharing your personal key

**Network:**
- Ensure Atom host:port is accessible from Mashery cloud IPs — not from the open internet unless required
- Use HTTPS (`outboundTransportProtocol: "https"`) for production backends when possible
- Set `inboundSslRequired: true` on production endpoints to enforce HTTPS on the inbound side

---

## Environment Strategy

Maintain separate Mashery configuration per environment:

```
Development:  Service "Orders API Dev"    + Endpoint → dev-atom:9090
Testing:      Service "Orders API Test"   + Endpoint → test-atom:9090
Production:   Service "Orders API"        + Endpoint → prod-atom:9090
```

Use separate `.env` configurations per environment (e.g., `.env.dev`, `.env.prod`) and pass the appropriate one to your tools. Each environment should have its own Package + Plan + keys.

---

## API Design Patterns

**One Boomi listener = one Mashery Service + Endpoint**

This keeps the mapping simple:
- Easy to trace from Mashery gateway to Boomi process
- Clean rate limiting per API
- Clear developer portal organization

**Path Alias Design:**
- Use noun-based paths: `/orders`, `/customers`, `/products`
- Version in the path if you anticipate breaking changes: `/v1/orders`, `/v2/orders`
- Keep paths consistent with your Boomi listener paths where possible

**HTTP Method Restriction:**
- Only enable the HTTP methods your Boomi listener actually supports
- If the listener is GET-only, set `supportedHttpMethods: ["get"]` — Mashery will reject other methods before they reach Boomi

---

## Operational Practices

**Before going to production:**
1. Test with `--provision-key` first and verify the full call chain works
2. Confirm the Atom host:port is accessible from outside your network (have someone test it from a different network)
3. Set appropriate rate limits and verify they apply (call the API repeatedly and watch for 429 responses)
4. Document the Service ID, Endpoint ID, Package ID, and Plan ID somewhere (your project notes, not this repo)

**Monitoring:**
- Mashery Control Center provides call volume and error rate dashboards
- Check the dashboard after any Boomi process redeployment to confirm traffic is flowing
- Watch for 503 errors — they indicate the Atom is unreachable from Mashery

**Troubleshooting workflow:**
1. Run `mashery-auth.py` to confirm credentials are valid
2. Run `mashery-service-list.py` to confirm the service and endpoint IDs are correct
3. Test the Boomi listener directly (bypass Mashery) to isolate whether the issue is in Mashery or Boomi
4. Check Mashery Control Center error logs for specific error details
