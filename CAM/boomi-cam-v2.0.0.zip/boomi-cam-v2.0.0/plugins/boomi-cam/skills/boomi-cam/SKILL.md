---
name: boomi-cam
description: Boomi Cloud API Management (CAM / Mashery) — publish, secure, and manage APIs on the Mashery gateway. Use when creating or configuring API services, endpoints, packages, plans, and rate limits; managing developer API keys (create/list/suspend/revoke/rotate); whitelisting public domains; finding which apps consume an endpoint; or exposing a Boomi Integration listener as a managed API. Triggers on Mashery, CAM, Cloud API Management, developer keys, rate limiting, and publishing or exposing APIs.
---

# Boomi Cloud API Management (CAM) Skill

This skill enables Claude Code to manage APIs in **Boomi Cloud API Management**, built on the Mashery platform (acquired by Boomi from TIBCO). It provides Python CLI tools, comprehensive reference documentation, and workflow guidance for registering and exposing APIs through the Mashery gateway.

---

## Repository Layout

```
plugins/boomi-cam/skills/boomi-cam/
├── SKILL.md                     ← you are here (entry point + routing)
├── references/
│   ├── CAM_THINKING.md          ← read first for any CAM work
│   ├── guides/
│   │   ├── authentication.md    ← OAuth flow, credentials, Area UUID
│   │   ├── concepts.md          ← resource hierarchy, terminology
│   │   ├── services.md          ← Service CRUD
│   │   ├── endpoints.md         ← Endpoint routing + Boomi backend
│   │   ├── packages-and-plans.md← Package, Plan, Key provisioning
│   │   └── best-practices.md    ← naming, rate limits, security
│   └── api/
│       └── request-examples.md  ← annotated curl examples
└── tools/
    ├── mashery_paths.py          ← shared credentials + HTTP helpers
    ├── mashery-auth.py           ← verify credentials, get bearer token
    ├── mashery-service-create.py ← create a Service
    ├── mashery-service-list.py   ← list Services in the area
    ├── mashery-endpoint-create.py← create an Endpoint on a Service (+ backend auth)
    ├── mashery-endpoint-update.py← update an existing Endpoint (partial PUT)
    ├── mashery-endpoint-get.py   ← show an Endpoint's full config (for diffing)
    ├── mashery-endpoint-clone.py ← clone an Endpoint's full config to a target service
    ├── mashery-package-plan-create.py ← create Package + Plan + key
    ├── mashery-key.py            ← package-key lifecycle: list/create/suspend/activate/revoke/rotate
    ├── mashery-endpoint-consumers.py  ← reverse-lookup: who consumes an endpoint
    ├── mashery-domain-list.py         ← list the area's whitelisted public domains
    └── mashery-domain-create.py       ← register (whitelist) a public domain
```

---

## First-Time Setup Checklist

Before any Mashery work, verify these `.env` variables are set:

```
BOOMI_CAM_API_KEY       ✓ From Mashery Control Center → My Account → Issue Developer Keys
BOOMI_CAM_API_SECRET    ✓ Same location as API key
BOOMI_CAM_USERNAME      ✓ Your Mashery login email
BOOMI_CAM_PASSWORD      ✓ Your Mashery login password
BOOMI_CAM_AREA_UUID     ✓ UUID from Control Center URL
BOOMI_CAM_API_URL       ✓ https://api.mashery.com (default)
BOOMI_CAM_TRAFFIC_DOMAIN✓ yourcompany.api.mashery.com
```

If any are missing, prompt the user to add them and point to `references/guides/authentication.md`.

> **First-timer / "where do I get these?"** The token needs **two separate
> credential pairs from two places** (a Boomi/SSO login gives you neither):
> 1. **`BOOMI_CAM_API_KEY` / `BOOMI_CAM_API_SECRET`** — from the developer portal:
>    **developer.mashery.com → My Account → Keys → "Mashery API: V2 + V3"** (the
>    Key + Secret fields).
> 2. **`BOOMI_CAM_USERNAME` / `BOOMI_CAM_PASSWORD`** — an **Area** account; for
>    automation use a dedicated **service account** (Area Administrator role +
>    **Service User** flag, created in Control Center → Manage → Users).
>
> See `references/guides/authentication.md` → "Getting Mashery V3 API Credentials"
> for step-by-step. Note: a Service User cannot log into the Control Center —
> that's expected.

Run `python3 ${CLAUDE_SKILL_DIR}/tools/mashery-auth.py` to verify before proceeding with any other task.

---

## Task → Reference Routing

| Task | Read these documents |
|------|---------------------|
| Any CAM / Mashery work | `references/CAM_THINKING.md` first — always |
| Auth errors, credential setup | `references/guides/authentication.md` |
| Understand resources and hierarchy | `references/guides/concepts.md` |
| Create or list Services | `references/guides/services.md` |
| Create or configure Endpoints | `references/guides/endpoints.md` |
| Update an endpoint / set backend (outbound) auth | `references/guides/endpoints.md` → "Backend Authentication" / "Updating an Endpoint" |
| Clone an endpoint faithfully (config-identical apart from overrides) | `references/guides/endpoints.md` → "Cloning an Endpoint" |
| Set an endpoint Call Transformation (SDK processor / connector) or backend timeout | `references/guides/endpoints.md` → "Call Transformation (processor)" |
| Create Packages, Plans, or Keys | `references/guides/packages-and-plans.md` |
| List or register area public domains (whitelist) | `references/guides/endpoints.md` → "Public Domain Whitelist" |
| Find who consumes an endpoint (reverse lookup) | `references/guides/packages-and-plans.md` → "Reverse Lookup" |
| Expose a Boomi listener via Mashery | All five guides in order (see Standard Workflows below) |
| Production best practices | `references/guides/best-practices.md` |
| Raw API examples / curl calls | `references/api/request-examples.md` |

---

## Architecture

**Mashery gateway model**: Mashery acts as a reverse proxy — inbound traffic hits the Mashery Traffic Manager domain, which enforces authentication and rate limits, then forwards requests to your backend (e.g., a Boomi Integration web service listener).

```
Client → Mashery Traffic Domain → [auth + throttle] → Boomi Listener URL
```

**Key resource hierarchy**:
```
Area (org)
└── Service (API definition)
    └── Endpoint (URL + backend routing)
Package
└── Plan (rate tier + service/endpoint associations)
    └── Key (developer API key)
```

---

## CLI Tools

All tools live in `tools/`. Run with:

```bash
python3 ${CLAUDE_SKILL_DIR}/tools/<tool>.py [args]
```

`CLAUDE_SKILL_DIR` is automatically set to this skill directory at load time.

| Tool | Purpose | Key Args |
|------|---------|----------|
| `mashery-auth.py` | Verify credentials + print bearer token | (none — reads .env) |
| `mashery-service-create.py` | Create a new Mashery Service | `--name` `--description` `--version` |
| `mashery-service-list.py` | List all Services in the area | `--filter` (name substring) |
| `mashery-endpoint-create.py` | Add an Endpoint to a Service (backend auth, Call Transformation, timeouts) | `--service-id` `--name` `--backend-url` `--path-alias` `--auth` `--backend-auth-type` `--sdk-processors` `--connect-timeout` |
| `mashery-endpoint-update.py` | Update an Endpoint (partial — incl. Call Transformation `processor` + timeouts) | `--service-id` `--endpoint-id` `--name` `--backend-url` `--sdk-processors` `--processor-adapter` `--clear-processor` `--connect-timeout` `--clear-backend-auth` |
| `mashery-endpoint-get.py` | Show an Endpoint's full config (for inspection / diffing) | `--service-id` `--endpoint-id` `--json` `--raw-secret` |
| `mashery-endpoint-clone.py` | Clone an Endpoint's full config to a target service, applying only overrides | `--source-service-id` `--source-endpoint-id` `--target-service-id` `--name` `--path-alias` `--public-domain` `--inbound-ssl` |
| `mashery-package-plan-create.py` | Create Package + Plan linked to a Service | `--service-id` `--endpoint-id` `--package-name` `--plan-name` `--provision-key` |
| `mashery-key.py` | Package-key lifecycle (Application-scoped): list/create/suspend/activate/revoke/rotate; keys masked by default | `{list,create,suspend,activate,revoke,rotate}` `--application-id` `--key-id` `--package-id` `--plan-id` `--show-keys` |
| `mashery-endpoint-consumers.py` | Reverse-lookup: which Packages, Plans & Applications consume an endpoint | `--name` `--path` `--exact` `--json` |
| `mashery-domain-list.py` | List the area's whitelisted public domains | `--filter` (domain substring) `--json` |
| `mashery-domain-create.py` | Register (whitelist) a public domain in the area | `--domain` `--description` |

---

## Standard Workflows

### Full flow: Expose a Boomi Integration listener via Mashery

Read in this order:
1. `references/CAM_THINKING.md` — resource model mental model
2. `references/guides/authentication.md` — verify credentials
3. `references/guides/services.md` — create the Service
4. `references/guides/endpoints.md` — configure the Endpoint pointing to Boomi
5. `references/guides/packages-and-plans.md` — create Package + Plan for access

Then execute:

**Step 1 — Verify credentials**
```bash
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-auth.py
```
Expected: prints a valid bearer token. If error → fix `.env` before continuing.

**Step 2 — Create the Service**
```bash
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-service-create.py \
  --name "My API" \
  --description "Exposed via Boomi Integration"
```
Save the returned `serviceId`.

**Step 3 — Create the Endpoint**
```bash
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-create.py \
  --service-id <serviceId> \
  --name "Default" \
  --backend-url "http://your-atom-host:9090/ws/rest/myapi" \
  --path-alias "/myapi"
```
Save the returned `endpointId`.

**Step 4 — Create Package + Plan + test key**
```bash
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-package-plan-create.py \
  --service-id <serviceId> \
  --endpoint-id <endpointId> \
  --package-name "My API Package" \
  --plan-name "Basic" \
  --provision-key
```

**Step 5 — Test**
```bash
curl "https://<BOOMI_CAM_TRAFFIC_DOMAIN>/myapi?api_key=<provisioned_key>"
```

### Reverse lookup: which Applications / Packages consume an endpoint

Use when someone has an **endpoint name (and/or its request path)** and asks
*"which Applications and Packages are using it?"* CAM has no direct reverse
index, so the tool chains down the hierarchy:

```
Endpoint → Service → Plan → Package → PackageKey → Application
```

Run it with the endpoint name and/or path (at least one required):

```bash
# By endpoint name (case-insensitive substring)
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-consumers.py --name "Orders"

# By request path alias
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-consumers.py --path "/orders"

# Require an exact match, or emit JSON for further processing
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-endpoint-consumers.py --name "Orders" --exact --json
```

What it does:
1. **Step 1** — `GET /packages` with nested `plans.services.endpoints` and matches
   the endpoint by `name` / `requestPathAlias`, collecting the Package + **Plan**
   IDs that grant it.
2. **Step 2** — for each matched Package, `GET /packageKeys?filter=package.id:<id>`
   with nested `application`, `member` (owner), and `plan`. One call resolves the
   keys **and** the consuming Applications + owners.
3. **Step 3** — narrows to keys whose **Plan** actually grants the matched
   endpoint (a Package can hold several Plans; only some grant the target), then
   prints the consuming Applications and their owners.

Caveats (the model has no reverse index, so this is best-effort):
- The nested package projection often returns `requestPathAlias` as `null`, so
  **`--name` is the most reliable matcher**. If `--path` finds nothing, match by
  name instead, or confirm your area's path field (see `PATH_FIELD` in the tool).
- `/applications` does **not** accept a `packageKeys.package.id` filter
  (`ERR_INVALID_FIELD`) — consumers are resolved from PackageKeys instead.
- An endpoint only appears if a **Plan** grants access to it; endpoints with no
  plan association won't be found by this reverse path.

### Manage area public domains (the domain whitelist)

The area maintains a **public-domain whitelist**: the set of hostnames allowed
to be used as the `publicDomains` / `systemDomains` address on an endpoint —
your Traffic Manager domain (`yourco.api.mashery.com`) plus any backend hosts.
An endpoint can only reference a host that already appears in this list, so
registering a new domain (e.g. a freshly-issued Let's Encrypt public domain)
is a prerequisite step before pointing an endpoint at it.

```bash
# List the whitelist (optionally filter)
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-domain-list.py
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-domain-list.py --filter mashery

# Register (whitelist) a new public domain — confirmed supported via the V3 API
python3 ${CLAUDE_SKILL_DIR}/tools/mashery-domain-create.py \
  --domain api.example.com --description "LE public domain"
```

**Important — registration is effectively one-way via the API:** creating a
domain works (`POST /domains` → 200, "…has been whitelisted"), but the V3 API
does **not** allow deleting one (`DELETE /domains/{id}` → **403 Forbidden** for
the standard service account), and `domain`/`status` are immutable on update
(only `description` can be `PUT`). Removing a whitelisted domain therefore
requires the **Control Center UI**. Double-check the hostname before creating.

### Troubleshooting 401 / auth errors
1. Read `references/guides/authentication.md` — re-read the token acquisition section
2. Run `python3 ${CLAUDE_SKILL_DIR}/tools/mashery-auth.py` to verify credentials work
3. Confirm `BOOMI_CAM_AREA_UUID` is correct (check it against the Control Center URL)

### Troubleshooting 404 or 503 on API calls through the gateway
1. Run `python3 ${CLAUDE_SKILL_DIR}/tools/mashery-service-list.py` to verify service IDs exist
2. Check `references/guides/endpoints.md` — confirm `requestPathAlias` matches the call path
3. Verify Atom host:port is reachable from Mashery cloud (try curl from another machine)

---

## Error Patterns Quick Reference

| Error | Likely Cause | Fix |
|-------|-------------|-----|
| `401` on token endpoint | Wrong API key/secret or area UUID | Check `.env` BOOMI_CAM_API_KEY, BOOMI_CAM_API_SECRET, BOOMI_CAM_AREA_UUID |
| `403` on REST calls | Token expired or insufficient role | Re-run `mashery-auth.py`; confirm admin role |
| `404` on service/endpoint | Wrong resource ID | Run `mashery-service-list.py` to confirm IDs |
| `409 Conflict` | Resource name already exists | Use a unique `--name` value |
| `400 "Property 'notifyDeveloperPeriod' is required."` on package create | The value `"never"` is invalid — Mashery reports a bad enum as "required" | Use a real period (`day`/`week`/`month`/`hour`/`minute`); the tool defaults to `day` (`--notify-period`) |
| `404 Not Found` provisioning a key | Tried to create a key under `.../members/{id}/keys`; keys are Application-scoped | Create the key under `POST /applications/{appId}/packageKeys` — `--provision-key` now does this automatically |
| `400 "customRequestAuthenticationAdapter is required if requestAuthenticationType is custom"` on endpoint create | An invalid `requestAuthenticationType` (e.g. `"none"`) was sent — Mashery maps any unknown value to `custom` | V3 has no open/`none` auth type; use `apiKey` (or `apiKeyAndSecret_SHA256`). For keyless, use the Control Center UI. `--auth none` now fails fast with this guidance |
| `503` through gateway | Atom unreachable from Mashery | Verify Atom host:port is internet-accessible |
| Connection timeout | Wrong `BOOMI_CAM_API_URL` | Confirm it is `https://api.mashery.com` |

---

## Integration with boomi-integration Skill

When the user asks to expose a Boomi listener, the workflow spans two skills:

1. **`boomi-integration` skill** — build the Web Services Server listener process and deploy it to an Atom
2. **`boomi-cam` skill** (this skill) — register the listener as a Mashery Service, configure the Endpoint, and create a Package + Plan

Always build the Boomi listener first — you need the listener URL before you can configure the Mashery Endpoint.

---

## Scope Boundaries

**This skill handles:**
- Mashery Service CRUD
- Mashery Endpoint CRUD and configuration
- Package + Plan creation and Service/Endpoint association
- Admin API key provisioning
- Bearer token acquisition
- Listing the area public-domain whitelist and **registering** new domains
  (create is supported via the V3 API)

**Out of scope (requires Mashery Control Center UI):**
- **Deleting** a whitelisted public domain (`DELETE /domains/{id}` → 403; UI-only)
- OAuth provider configuration
- Custom adapter setup
- Developer portal customization
- Reporting and analytics dashboards
- SSL certificate management for custom domains
- Interactive API testing console
