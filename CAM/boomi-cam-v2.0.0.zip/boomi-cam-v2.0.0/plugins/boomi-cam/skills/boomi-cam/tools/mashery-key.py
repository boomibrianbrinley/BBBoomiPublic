#!/usr/bin/env python3
"""
mashery-key.py — Package-key lifecycle for Boomi Cloud API Management (Mashery).

Keys are Application-scoped: /applications/{appId}/packageKeys[/{keyId}].

Subcommands:
  list     [--application-id ID]                 list keys (all apps if omitted)
  create    --application-id ID --package-id ID --plan-id ID [--apikey VALUE]
  suspend   --application-id ID --key-id ID      set status=disabled
  activate  --application-id ID --key-id ID      set status=active
  revoke    --application-id ID --key-id ID      DELETE (falls back to suspend if 403)
  rotate    --application-id ID --key-id ID       create a fresh key on same package/plan, disable the old

Globals: --show-keys (reveal apikey/secret; masked by default).

Notes:
  - Keys are one-per-application-per-package/plan: a duplicate returns 400
    "Duplicate Object". Use a different Application to hold another key.
  - New keys are created in status "waiting" (review) even when active is
    requested; `activate` moves them to "active".
  - This tool does its own HTTP so it can handle errors gracefully (e.g. the
    revoke->suspend fallback) rather than exiting mid-run. It reuses the shared
    helper for env/credentials/token/masking/timeout and paces to ~2 QPS.
"""
import sys
import json
import time
import argparse
from pathlib import Path
from urllib import request, parse
from urllib.error import HTTPError, URLError

sys.path.insert(0, str(Path(__file__).parent))
from mashery_paths import (load_env, get_mashery_credentials, get_token,  # noqa: E402
                           mask_secret, get_http_timeout)

_last = [0.0]


def _pace(min_interval=0.7):
    dt = time.time() - _last[0]
    if dt < min_interval:
        time.sleep(min_interval - dt)
    _last[0] = time.time()


def _req(method, path, token, creds, body=None, params=None):
    """Authenticated V3 request. Returns (status:int|None, parsed:dict|list|str)."""
    _pace()
    base = creds["api_url"].rstrip("/")
    url = f"{base}/v3/rest/{path.lstrip('/')}"
    if params:
        url += "?" + parse.urlencode(params)
    data = json.dumps(body).encode() if body is not None else None
    req = request.Request(url, data=data, method=method, headers={
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    })
    try:
        with request.urlopen(req, timeout=get_http_timeout()) as r:
            raw = r.read()
            return r.status, (json.loads(raw) if raw else {})
    except HTTPError as e:
        raw = e.read().decode()
        try:
            return e.code, json.loads(raw)
        except Exception:
            return e.code, raw
    except URLError as e:
        return None, f"URLError: {e.reason}"


def items_of(r):
    if isinstance(r, list):
        return r
    if isinstance(r, dict):
        return r.get("items", [r] if "id" in r else [])
    return []


def _get_apps(token, creds):
    st, r = _req("GET", "applications", token, creds, params={"fields": "id,name"})
    return items_of(r) if st == 200 else []


def _key_summary(app_id, k, show):
    lims = ", ".join(f"{l.get('period')}:{l.get('ceiling')}" for l in (k.get("limits") or []))
    pkg = (k.get("package") or {}).get("id", "?")
    pln = (k.get("plan") or {}).get("id", "?")
    return (f"  key={mask_secret(k.get('apikey'), show)}  status={k.get('status')}  "
            f"id={k.get('id')}  app={app_id}\n"
            f"      package={pkg}  plan={pln}  limits=[{lims}]")


def cmd_list(a, token, creds):
    apps = [{"id": a.application_id, "name": "(given)"}] if a.application_id else _get_apps(token, creds)
    total = 0
    for app in apps:
        st, r = _req("GET", f"applications/{app['id']}/packageKeys", token, creds,
                     params={"fields": "id,apikey,status,limits,package,plan"})
        keys = items_of(r) if st == 200 else []
        if not a.application_id:
            print(f"# application {app.get('name','?')} ({app['id']}) — {len(keys)} key(s)")
        for k in keys:
            print(_key_summary(app["id"], k, a.show_keys)); total += 1
    print(f"\nTotal: {total} key(s)")


def cmd_create(a, token, creds):
    body = {"apikey": a.apikey or "", "secret": "", "status": "active", "limits": [],
            "package": {"id": a.package_id}, "plan": {"id": a.plan_id}}
    st, r = _req("POST", f"applications/{a.application_id}/packageKeys", token, creds, body=body)
    if st in (200, 201):
        print("Created:"); print(_key_summary(a.application_id, r, a.show_keys))
        if r.get("secret"):
            print(f"      secret={mask_secret(r.get('secret'), a.show_keys)}")
    else:
        print(f"ERROR create -> {st}: {r}")


def _set_status(a, token, creds, status):
    st, r = _req("PUT", f"applications/{a.application_id}/packageKeys/{a.key_id}",
                 token, creds, body={"status": status})
    if st == 200:
        print(f"OK -> status now: {r.get('status', status)}")
        print(_key_summary(a.application_id, r, a.show_keys))
    else:
        print(f"ERROR set status={status} -> {st}: {r}")


def cmd_suspend(a, token, creds):
    _set_status(a, token, creds, "disabled")


def cmd_activate(a, token, creds):
    _set_status(a, token, creds, "active")


def cmd_revoke(a, token, creds):
    st, r = _req("DELETE", f"applications/{a.application_id}/packageKeys/{a.key_id}", token, creds)
    if st in (200, 204):
        print(f"Revoked (deleted) key {a.key_id}.")
    elif st == 403:
        print("DELETE not permitted in this area (403). Falling back to suspend (status=disabled)...")
        _set_status(a, token, creds, "disabled")
    else:
        print(f"ERROR revoke -> {st}: {r}")


def cmd_rotate(a, token, creds):
    st, r = _req("GET", f"applications/{a.application_id}/packageKeys/{a.key_id}", token, creds,
                 params={"fields": "id,apikey,status,package,plan"})
    if st != 200:
        print(f"ERROR rotate (read old) -> {st}: {r}"); return
    pkg = (r.get("package") or {}).get("id")
    pln = (r.get("plan") or {}).get("id")
    if not (pkg and pln):
        print(f"ERROR rotate: could not read package/plan on old key: {r}"); return
    st2, new = _req("POST", f"applications/{a.application_id}/packageKeys", token, creds,
                    body={"apikey": "", "secret": "", "status": "active", "limits": [],
                          "package": {"id": pkg}, "plan": {"id": pln}})
    if st2 not in (200, 201):
        print(f"ERROR rotate (create new) -> {st2}: {new}"); return
    print("New key:"); print(_key_summary(a.application_id, new, a.show_keys))
    st3, old = _req("PUT", f"applications/{a.application_id}/packageKeys/{a.key_id}",
                    token, creds, body={"status": "disabled"})
    print(f"Old key {a.key_id}: {'disabled' if st3 == 200 else f'disable failed {st3}: {old}'}")


def main():
    p = argparse.ArgumentParser(description="Mashery/CAM package-key lifecycle")
    p.add_argument("--show-keys", action="store_true", help="reveal apikey/secret (masked by default)")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("list"); s.add_argument("--application-id")
    s = sub.add_parser("create")
    for f in ("--application-id", "--package-id", "--plan-id"):
        s.add_argument(f, required=True)
    s.add_argument("--apikey", help="fixed apikey value (default: auto-generate)")
    for name in ("suspend", "activate", "revoke", "rotate"):
        s = sub.add_parser(name)
        s.add_argument("--application-id", required=True)
        s.add_argument("--key-id", required=True)

    a = p.parse_args()
    load_env()
    creds = get_mashery_credentials()
    token = get_token()
    {"list": cmd_list, "create": cmd_create, "suspend": cmd_suspend,
     "activate": cmd_activate, "revoke": cmd_revoke, "rotate": cmd_rotate}[a.cmd](a, token, creds)


if __name__ == "__main__":
    main()
