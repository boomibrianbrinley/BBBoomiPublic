"""
mashery_paths.py — Path resolution and shared utilities for Mashery tools.

Resolves:
  - The .env file (walks up from cwd to find it)
  - CLAUDE_SKILL_DIR (from env var or auto-detected from this file's location)
  - Mashery API credentials from .env

Also provides:
  - get_token()     — OAuth bearer token for Mashery V3 API
  - mashery_get()   — authenticated GET
  - mashery_post()  — authenticated POST
  - mashery_put()   — authenticated PUT
  - mashery_delete()— authenticated DELETE
"""

import os
import sys
import json
import time
import base64
import tempfile
from pathlib import Path
from urllib import request as urllib_request
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode


# ---------------------------------------------------------------------------
# Path resolution
# ---------------------------------------------------------------------------

def find_env_file():
    """Walk up from cwd to find .env file."""
    current = Path.cwd()
    for parent in [current] + list(current.parents):
        candidate = parent / ".env"
        if candidate.exists():
            return candidate
    return None


def load_env(env_path=None):
    """Load .env file into os.environ (does not override existing vars)."""
    if env_path is None:
        env_path = find_env_file()
    if env_path is None:
        return
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, _, value = line.partition("=")
                key = key.strip()
                value = value.strip().strip('"').strip("'")
                if key and key not in os.environ:
                    os.environ[key] = value


def get_skill_dir():
    """Return the directory containing this file (the skill tools directory)."""
    return Path(__file__).parent


def get_workspace_dir():
    """Return the active-development workspace directory."""
    env_file = find_env_file()
    if env_file:
        return env_file.parent / "active-development"
    return Path.cwd() / "active-development"


# ---------------------------------------------------------------------------
# Credential helpers
# ---------------------------------------------------------------------------

_LEGACY_WARNED = [False]


def get_env(suffix, default=None):
    """Read BOOMI_CAM_<suffix>, falling back to legacy MASHERY_<suffix>.

    Boomi Cloud API Management is the current brand; the MASHERY_* names are
    deprecated but still honored (one-time warning per process).
    """
    load_env()
    new_key = f"BOOMI_CAM_{suffix}"
    if os.environ.get(new_key) is not None:
        return os.environ[new_key]
    old_key = f"MASHERY_{suffix}"
    if os.environ.get(old_key) is not None:
        if not _LEGACY_WARNED[0]:
            print("WARNING: MASHERY_* env vars are deprecated — rename them to "
                  "BOOMI_CAM_* in your .env (legacy names still work for now).",
                  file=sys.stderr)
            _LEGACY_WARNED[0] = True
        return os.environ[old_key]
    return default


def get_mashery_credentials():
    """Return Boomi CAM (Mashery) credentials from env.

    Reads BOOMI_CAM_* variables, falling back to legacy MASHERY_* (see get_env).
    """
    required = ["API_KEY", "API_SECRET", "USERNAME", "PASSWORD", "AREA_UUID"]
    missing = [f"BOOMI_CAM_{s}" for s in required if get_env(s) is None]
    if missing:
        print(f"ERROR: Missing required .env variables: {', '.join(missing)}", file=sys.stderr)
        print("Add these to your .env file. See references/guides/authentication.md for details.",
              file=sys.stderr)
        sys.exit(1)
    return {
        "api_key": get_env("API_KEY"),
        "api_secret": get_env("API_SECRET"),
        "username": get_env("USERNAME"),
        "password": get_env("PASSWORD"),
        "area_uuid": get_env("AREA_UUID"),
        "api_url": get_env("API_URL", "https://api.mashery.com"),
        "traffic_domain": get_env("TRAFFIC_DOMAIN", ""),
    }


def get_http_timeout():
    """HTTP socket timeout (seconds) for Mashery API calls.

    Read from MASHERY_HTTP_TIMEOUT (default 60). Set to 0 to disable the
    timeout (returns None) — not recommended, since a stalled connection will
    then hang indefinitely. Raise it for larger accounts whose calls take
    longer to respond.
    """
    raw = (get_env("HTTP_TIMEOUT") or "").strip()
    if not raw:
        return 60
    try:
        val = float(raw)
    except ValueError:
        return 60
    return None if val <= 0 else val


def mask_secret(value, show=False):
    """Mask a secret/token for display. Full value only when show=True."""
    if not value or show:
        return value
    s = str(value)
    return (s[:4] + "…" + s[-2:]) if len(s) > 8 else "…"


# ---------------------------------------------------------------------------
# Rate limiting
# ---------------------------------------------------------------------------
# Mashery API keys are rate limited. The default developer key allows:
#     2 calls / second   and   5,000 calls / day
# (Contact Boomi Support to raise the QPS quota, e.g. to 10/sec.)
# These helpers throttle outbound calls to stay under QPS, retry on QPS
# rejections with backoff, and track a best-effort per-day counter so a run
# fails fast with a clear message instead of getting opaque 403s mid-batch.
# Override the limits via .env: MASHERY_API_QPS, MASHERY_API_DAILY.

_LAST_CALL = [0.0]  # monotonic timestamp of the most recent request (in-process)


def get_rate_limits():
    """Return (qps, daily_max) from env, defaulting to the Mashery key defaults."""
    try:
        qps = float(get_env("API_QPS", "2"))
    except ValueError:
        qps = 2.0
    try:
        daily = int(get_env("API_DAILY", "5000"))
    except ValueError:
        daily = 5000
    return max(qps, 0.1), max(daily, 1)


def _throttle(qps):
    """Block just long enough to keep the call rate at or under `qps`."""
    if qps <= 0:
        return
    min_interval = 1.0 / qps
    elapsed = time.monotonic() - _LAST_CALL[0]
    if elapsed < min_interval:
        time.sleep(min_interval - elapsed)
    _LAST_CALL[0] = time.monotonic()


def _quota_path(area_uuid):
    day = time.strftime("%Y%m%d", time.gmtime())
    return Path(tempfile.gettempdir()) / f"mashery_quota_{(area_uuid or 'na')[:8]}_{day}.json"


def quota_used(area_uuid):
    """Best-effort read of today's call count for this area (0 if unknown)."""
    try:
        return int(json.loads(_quota_path(area_uuid).read_text()).get("count", 0))
    except Exception:
        return 0


def _quota_increment(area_uuid):
    """Best-effort increment of today's call count. Never raises."""
    try:
        p = _quota_path(area_uuid)
        count = quota_used(area_uuid) + 1
        p.write_text(json.dumps({"count": count, "day": time.strftime("%Y%m%d", time.gmtime())}))
        return count
    except Exception:
        return -1


def _rate_error_kind(http_error, body):
    """Classify a 4xx as a rate-limit error: 'qps', 'daily', or None."""
    code = (http_error.headers.get("X-Mashery-Error-Code") or "").upper()
    text = (code + " " + (body or "")).upper()
    if http_error.code == 429 or "OVER_QPS" in text or "QUERIES PER SECOND" in text:
        return "qps"
    if "OVER_RATE" in text or "OVER RATE LIMIT" in text or "OVER_QUOTA" in text or "DAILY" in text:
        return "daily"
    return None


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------

def get_token():
    """Acquire an OAuth bearer token from Mashery. Returns token string."""
    creds = get_mashery_credentials()

    token_url = f"{creds['api_url']}/v3/token"

    # Basic auth header: base64(apikey:apisecret)
    auth_str = f"{creds['api_key']}:{creds['api_secret']}"
    auth_b64 = base64.b64encode(auth_str.encode()).decode()

    body = urlencode({
        "grant_type": "password",
        "username": creds["username"],
        "password": creds["password"],
        "scope": creds["area_uuid"],
    }).encode()

    req = urllib_request.Request(
        token_url,
        data=body,
        headers={
            "Authorization": f"Basic {auth_b64}",
            "Content-Type": "application/x-www-form-urlencoded",
        },
        method="POST",
    )

    qps, _ = get_rate_limits()
    _throttle(qps)

    try:
        with urllib_request.urlopen(req, timeout=get_http_timeout()) as resp:
            data = json.loads(resp.read())
            return data["access_token"]
    except HTTPError as e:
        body = e.read().decode()
        print(f"ERROR: Token request failed — HTTP {e.code}", file=sys.stderr)
        print(f"Response: {body}", file=sys.stderr)
        print("\nCheck MASHERY_API_KEY, MASHERY_API_SECRET, MASHERY_USERNAME, "
              "MASHERY_PASSWORD, MASHERY_AREA_UUID in .env", file=sys.stderr)
        sys.exit(1)
    except URLError as e:
        print(f"ERROR: Cannot reach Mashery API — {e.reason}", file=sys.stderr)
        print("Check MASHERY_API_URL and your network connection.", file=sys.stderr)
        sys.exit(1)


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

def _mashery_request(method, path, token, body=None, params=None, max_retries=4):
    """Make an authenticated, rate-limited Mashery V3 REST API call. Returns parsed JSON.

    Enforces the Mashery key limits (default 2/sec, 5,000/day): throttles to QPS,
    fails fast if today's daily count is already exhausted, and retries QPS
    rejections with exponential backoff.
    """
    creds = get_mashery_credentials()
    qps, daily = get_rate_limits()
    area = creds["area_uuid"]
    base = creds["api_url"].rstrip("/")

    url = f"{base}/v3/rest/{path.lstrip('/')}"
    if params:
        url += "?" + urlencode(params)

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    data = json.dumps(body).encode() if body is not None else None

    # Proactive daily-quota guard (best-effort, persisted per area+day in tmp).
    used = quota_used(area)
    if used >= daily:
        print(f"ERROR: Mashery daily call limit reached ({used}/{daily} today). "
              f"Wait for the daily reset or raise the quota via Boomi Support.", file=sys.stderr)
        sys.exit(1)
    if used and used >= int(daily * 0.9):
        print(f"WARNING: Mashery daily usage at {used}/{daily} — approaching the limit.",
              file=sys.stderr)

    attempt = 0
    backoff = 1.0
    while True:
        _throttle(qps)
        req = urllib_request.Request(url, data=data, headers=headers, method=method)
        try:
            with urllib_request.urlopen(req, timeout=get_http_timeout()) as resp:
                raw = resp.read()
            _quota_increment(area)
            return json.loads(raw) if raw else {}
        except HTTPError as e:
            err_body = e.read().decode(errors="replace")
            kind = _rate_error_kind(e, err_body)
            if kind == "qps" and attempt < max_retries:
                attempt += 1
                print(f"NOTE: hit Mashery QPS limit (2/sec default) — retry "
                      f"{attempt}/{max_retries} in {backoff:.0f}s", file=sys.stderr)
                time.sleep(backoff)
                backoff *= 2
                continue
            if kind == "daily":
                print(f"ERROR: Mashery daily/quota rate limit exceeded — {method} {url} → HTTP {e.code}",
                      file=sys.stderr)
                print(f"Response: {err_body}", file=sys.stderr)
                print("The Mashery API key default is 2 calls/sec and 5,000/day. "
                      "Contact Boomi Support to raise the quota.", file=sys.stderr)
                sys.exit(1)
            print(f"ERROR: {method} {url} → HTTP {e.code}", file=sys.stderr)
            print(f"Response: {err_body}", file=sys.stderr)
            sys.exit(1)
        except URLError as e:
            print(f"ERROR: {method} {url} → {e.reason}", file=sys.stderr)
            sys.exit(1)


def mashery_get(path, token, params=None):
    return _mashery_request("GET", path, token, params=params)


def mashery_post(path, token, body):
    return _mashery_request("POST", path, token, body=body)


def mashery_put(path, token, body):
    return _mashery_request("PUT", path, token, body=body)


def mashery_delete(path, token):
    return _mashery_request("DELETE", path, token)


# ---------------------------------------------------------------------------
# Collection helpers
# ---------------------------------------------------------------------------
# Mashery V3 collection endpoints (e.g. GET /services, /members) return a
# BARE JSON ARRAY — not a {"items": [...], "totalCount": N} envelope. The total
# count is returned in the "X-Total-Count" response header, not the body.
# Calling result.get(...) on that array raises AttributeError, so always
# normalize a collection response through normalize_collection().

def normalize_collection(result):
    """Normalize a Mashery V3 collection response to a list of items.

    Handles all observed shapes:
      - bare list            -> returned as-is (the actual V3 behavior)
      - {"items": [...]}      -> the items list (defensive, in case of envelope)
      - a single object dict  -> wrapped in a one-element list
      - None / anything else  -> empty list
    """
    if isinstance(result, list):
        return result
    if isinstance(result, dict):
        if isinstance(result.get("items"), list):
            return result["items"]
        if "id" in result:
            return [result]
    return []


def mashery_get_all(path, token, params=None, page_size=200,
                    index_pagination=False, max_pages=1000):
    """GET an entire Mashery V3 collection, handling limit/offset pagination.

    V3 returns a bare array with the grand total in the X-Total-Count header
    (not the body), so we page until a short page (< page_size) comes back.
    Returns a flat list of items.

    Pagination modes (the offset semantics differ by collection):
      - index_pagination=False (default): `offset` is a RECORD offset — advance
        by the number of items returned. This is the standard V3 behavior used
        by /services, /members, /packages, etc.
      - index_pagination=True: `offset` is a PAGE INDEX (0, 1, 2, ...) — advance
        by 1 each page. Observed for /packageKeys and /applications.

    `max_pages` is a safety cap so a wrong pagination assumption can't loop
    forever. Items are de-duplicated by `id` (when present) so an overlapping
    page (e.g. a mis-guessed offset mode) can't silently inflate the result.
    """
    params = dict(params or {})
    params["limit"] = page_size
    params["offset"] = 0
    all_items = []
    seen_ids = set()
    pages = 0
    while pages < max_pages:
        page = normalize_collection(mashery_get(path, token, params=dict(params)))
        pages += 1
        for item in page:
            item_id = item.get("id") if isinstance(item, dict) else None
            if item_id is not None:
                if item_id in seen_ids:
                    continue
                seen_ids.add(item_id)
            all_items.append(item)
        if len(page) < page_size:
            break
        params["offset"] += 1 if index_pagination else len(page)
    return all_items


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def print_json(obj):
    """Pretty-print a dict as JSON."""
    print(json.dumps(obj, indent=2))


# ---------------------------------------------------------------------------
# Endpoint helpers
# ---------------------------------------------------------------------------
# GET on a single endpoint returns only id/name/created/updated unless you pass
# an explicit `fields` list — so always request fields when reading one back.
ENDPOINT_FIELDS = (
    "id,name,requestPathAlias,systemDomains,outboundRequestTargetPath,"
    "outboundTransportProtocol,supportedHttpMethods,requestAuthenticationType,"
    "apiKeyValueLocations,apiKeyValueLocationKey,systemDomainAuthentication,"
    "publicDomains,trafficManagerDomain,inboundSslRequired,useSystemDomainAsTarget"
)

# The full set of endpoint fields to copy for a faithful clone / diff. GET ignores
# fields that don't apply, and `fields=*` does NOT work (returns nothing), so the
# list must be explicit. Keep identity/server fields out of any create/update body
# (use strip_server_keys()).
ENDPOINT_FULL_FIELDS = ",".join([
    "id", "name", "allowMissingApiKey", "apiKeyValueLocationKey", "apiKeyValueLocations",
    "apiMethodDetectionKey", "apiMethodDetectionLocations", "cache",
    "connectionTimeoutForSystemDomainRequest", "connectionTimeoutForSystemDomainResponse",
    "cors", "customRequestAuthenticationAdapter", "dropApiKeyFromIncomingCall",
    "forceGzipOfBackendCall", "gzipPassthroughSupportEnabled", "headersToExcludeFromIncomingCall",
    "highSecurity", "hostPassthroughIncludedInBackendCallHeader", "inboundSslRequired",
    "jsonpCallbackParameter", "jsonpCallbackParameterValue", "forwardedHeaders", "returnedHeaders",
    "methods", "numberOfHttpRedirectsToFollow", "outboundRequestTargetPath",
    "outboundRequestTargetQueryParameters", "outboundTransportProtocol", "processor",
    "publicDomains", "requestAuthenticationType", "requestPathAlias", "requestProtocol",
    "stringsToTrimFromApiKey", "supportedHttpMethods", "systemDomainAuthentication",
    "systemDomains", "trafficManagerDomain", "useSystemDomainCredentials",
    "systemDomainCredentialKey", "useSystemDomainAsTarget", "rateLimitHeadersEnabled",
    "cookiesDuringHttpRedirectsEnabled", "created", "updated",
])

# Server-managed keys to drop (recursively) before sending a clone/update body.
SERVER_MANAGED_KEYS = {"id", "created", "updated"}


# --- Call Transformation (endpoint `processor`) -----------------------------
# Verified live: a SINGLE custom SDK processor is named directly in
# processor.adapter (the bean FQCN). MULTIPLE processors chain via the built-in
# Mashery_Proxy_Processor_Chain with the FQCNs as a comma list in
# preInputs/postInputs.processors. Named Boomi connectors set adapter to the
# connector name directly with their own inputs. Clearing: processor=null → 500
# and processor={} only merges, so clear by sending an empty adapter + disabled
# stages.
PROCESSOR_CHAIN_ADAPTER = "Mashery_Proxy_Processor_Chain"
CLEAR_PROCESSOR = {"adapter": "", "preInputs": {}, "postInputs": {},
                   "preProcessEnabled": False, "postProcessEnabled": False}
# connectionTimeoutForSystemDomainRequest (backend CONNECT timeout) accepts only
# 2..7 seconds (the API 400 lists the allowed set). The RESPONSE/read timeout
# (connectionTimeoutForSystemDomainResponse) is wider (>= 2; 120 accepted).
CONNECT_TIMEOUT_ALLOWED = (2, 3, 4, 5, 6, 7)


def build_processor(*, sdk_pre=None, sdk_post=None, adapter=None,
                    pre_inputs=None, post_inputs=None,
                    pre_enabled=True, post_enabled=True):
    """Build an endpoint `processor` (Call Transformation) object.

    adapter mode  : named connector / explicit adapter with given inputs.
    sdk mode      : sdk_pre / sdk_post are lists of class FQCNs per stage. One
                    class shared by both stages -> set directly; otherwise the
                    Mashery_Proxy_Processor_Chain with comma `processors` lists.
    """
    if adapter is not None:
        return {"adapter": adapter, "preInputs": pre_inputs or {},
                "postInputs": post_inputs or {},
                "preProcessEnabled": pre_enabled, "postProcessEnabled": post_enabled}
    pre = list(sdk_pre or [])
    post = list(sdk_post or [])
    if pre and pre == post and len(pre) == 1:
        return {"adapter": pre[0], "preInputs": {}, "postInputs": {},
                "preProcessEnabled": pre_enabled, "postProcessEnabled": post_enabled}
    return {"adapter": PROCESSOR_CHAIN_ADAPTER,
            "preInputs": {"processors": ",".join(pre)} if pre else {},
            "postInputs": {"processors": ",".join(post)} if post else {},
            "preProcessEnabled": pre_enabled, "postProcessEnabled": post_enabled}


def add_processor_args(parser):
    """Add the shared Call Transformation / timeout flags to an argparse parser."""
    g = parser.add_argument_group("Call Transformation (endpoint processor) + timeouts")
    g.add_argument("--sdk-processors",
                   help="Custom SDK class FQCN(s), comma-separated. ONE class → set "
                        "directly; MULTIPLE → Mashery_Proxy_Processor_Chain.")
    g.add_argument("--sdk-pre-processors", help="Override pre-stage class list (else --sdk-processors)")
    g.add_argument("--sdk-post-processors", help="Override post-stage class list (else --sdk-processors)")
    g.add_argument("--processor-adapter", help="Named connector / explicit adapter name")
    g.add_argument("--pre-inputs", help="JSON object: adapter pre-stage inputs (with --processor-adapter)")
    g.add_argument("--post-inputs", help="JSON object: adapter post-stage inputs")
    g.add_argument("--pre-process", choices=["true", "false"], help="preProcessEnabled (default true)")
    g.add_argument("--post-process", choices=["true", "false"], help="postProcessEnabled (default true)")
    g.add_argument("--clear-processor", action="store_true", help="Remove the Call Transformation")
    g.add_argument("--connect-timeout", type=int,
                   help="Backend CONNECT timeout sec (connectionTimeoutForSystemDomainRequest); allowed 2-7")
    g.add_argument("--response-timeout", type=int,
                   help="Backend RESPONSE timeout sec (connectionTimeoutForSystemDomainResponse); >= 2")


def apply_processor_args(args, body):
    """Mutate `body` with processor/timeout fields from parsed args (shared by
    endpoint create + update). Raises ValueError on bad input. Returns a list of
    short change descriptions for display."""
    changes = []
    sdk_any = bool(args.sdk_processors or args.sdk_pre_processors or args.sdk_post_processors)
    if sum([sdk_any, bool(args.processor_adapter), bool(getattr(args, "clear_processor", False))]) > 1:
        raise ValueError("choose only one of --sdk-processors / --processor-adapter / --clear-processor")
    pre_enabled = (args.pre_process != "false") if args.pre_process else True
    post_enabled = (args.post_process != "false") if args.post_process else True

    if getattr(args, "clear_processor", False):
        body["processor"] = dict(CLEAR_PROCESSOR)
        changes.append("processor: cleared")
    elif args.processor_adapter:
        try:
            pre_in = json.loads(args.pre_inputs) if args.pre_inputs else {}
            post_in = json.loads(args.post_inputs) if args.post_inputs else {}
        except json.JSONDecodeError as e:
            raise ValueError(f"--pre-inputs/--post-inputs must be valid JSON: {e}")
        body["processor"] = build_processor(adapter=args.processor_adapter, pre_inputs=pre_in,
                                            post_inputs=post_in, pre_enabled=pre_enabled,
                                            post_enabled=post_enabled)
        changes.append(f"processor: adapter {args.processor_adapter}")
    elif sdk_any:
        base = [c.strip() for c in (args.sdk_processors or "").split(",") if c.strip()]
        pre = ([c.strip() for c in args.sdk_pre_processors.split(",") if c.strip()]
               if args.sdk_pre_processors else base)
        post = ([c.strip() for c in args.sdk_post_processors.split(",") if c.strip()]
                if args.sdk_post_processors else base)
        if not pre and not post:
            raise ValueError("--sdk-processors was empty")
        body["processor"] = build_processor(sdk_pre=pre, sdk_post=post,
                                            pre_enabled=pre_enabled, post_enabled=post_enabled)
        mode = "chain" if body["processor"]["adapter"] == PROCESSOR_CHAIN_ADAPTER else "direct"
        changes.append(f"processor: {mode} ({body['processor']['adapter']})")

    if args.connect_timeout is not None:
        if args.connect_timeout not in CONNECT_TIMEOUT_ALLOWED:
            raise ValueError(f"--connect-timeout must be one of {list(CONNECT_TIMEOUT_ALLOWED)} "
                             f"seconds (got {args.connect_timeout})")
        body["connectionTimeoutForSystemDomainRequest"] = args.connect_timeout
        changes.append(f"connect-timeout: {args.connect_timeout}s")
    if args.response_timeout is not None:
        if args.response_timeout < 2:
            raise ValueError(f"--response-timeout must be >= 2 seconds (got {args.response_timeout})")
        body["connectionTimeoutForSystemDomainResponse"] = args.response_timeout
        changes.append(f"response-timeout: {args.response_timeout}s")
    return changes


def strip_server_keys(obj):
    """Return a deep copy of obj with id/created/updated removed at every level.

    Mashery endpoint objects (and nested method/domain entries) carry server-managed
    id/created/updated that must not be POSTed back when cloning.
    """
    if isinstance(obj, dict):
        return {k: strip_server_keys(v) for k, v in obj.items()
                if k not in SERVER_MANAGED_KEYS}
    if isinstance(obj, list):
        return [strip_server_keys(v) for v in obj]
    return obj


def build_system_domain_auth(auth_type, username, password):
    """Build a systemDomainAuthentication object (outbound/backend auth).

    Returns the dict to send, or raises ValueError on bad input. Only httpBasic
    is supported here (the common Boomi backend case); the V3 field also accepts
    clientSslCertificate/custom which this skill does not model.
    Verified live: {"type":"httpBasic","username":...,"password":...} persists and
    reads back via an explicit `fields` GET.
    """
    if auth_type == "httpBasic":
        if not username:
            raise ValueError("--backend-user is required for httpBasic backend auth")
        if password is None:
            raise ValueError("backend password required: pass --backend-password or set "
                             "MASHERY_BACKEND_PASSWORD")
        return {"type": "httpBasic", "username": username, "password": password}
    raise ValueError(f"unsupported backend auth type: {auth_type!r}")


def mask_system_domain_auth(sda):
    """Return a display-safe copy of a systemDomainAuthentication dict (no secret)."""
    if not isinstance(sda, dict):
        return sda
    safe = dict(sda)
    if safe.get("password"):
        safe["password"] = "***"
    return safe


if __name__ == "__main__":
    load_env()
    print(f"Skill dir:     {get_skill_dir()}")
    print(f"Workspace dir: {get_workspace_dir()}")
    env_file = find_env_file()
    print(f".env file:     {env_file}")
