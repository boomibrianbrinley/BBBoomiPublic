#!/usr/bin/env python3
"""
mashery-endpoint-consumers.py — Reverse-lookup: given an Endpoint (by name and/or
request path), find which Packages, Plans, PackageKeys, and Applications consume it.

The CAM/Mashery object model has no direct reverse-lookup, so this chains calls
down the hierarchy:

    Endpoint → Service → Plan → Package → PackageKey → Application

Flow:
  Step 0  Authenticate (handled by mashery_paths.get_token()).
  Step 1  GET /packages with nested plans+services+endpoints, then match the
          target endpoint by name and/or requestPathAlias to collect the
          Package + Plan IDs that grant access to it.
  Step 2  For each matched Package, GET /packageKeys?filter=package.id:<id> with
          nested member/application/plan fields. Each PackageKey carries the
          consuming Application, its owner (member), and the Plan it belongs to —
          so a single call per package yields the Applications AND their owners,
          with no separate /applications lookup needed.
  Step 3  Narrow to the Applications whose key sits on a Plan that actually grants
          the matched endpoint (a Package can hold several Plans; only some grant
          the target endpoint).

Note on the model: the linkage Application←PackageKey→Package/Plan lives on the
PackageKey itself. /applications does NOT expose a `packageKeys.package.id`
filter (the area rejects it as ERR_INVALID_FIELD), so we resolve consumers from
PackageKeys instead — which is also one fewer call per package.

Usage:
    python3 mashery-endpoint-consumers.py --name "Orders"        # match by endpoint name
    python3 mashery-endpoint-consumers.py --path "/orders"       # match by request path alias
    python3 mashery-endpoint-consumers.py --name "Orders" --path "/orders"
    python3 mashery-endpoint-consumers.py --path "/orders" --exact   # exact (not substring) match
    python3 mashery-endpoint-consumers.py --name "Orders" --json      # machine-readable output

Options:
    --name NAME    Endpoint name to match (case-insensitive substring by default)
    --path PATH    Endpoint requestPathAlias to match (case-insensitive substring by default)
    --exact        Require an exact (case-insensitive) match instead of substring
    --json         Emit the full result as JSON instead of the formatted report

At least one of --name / --path is required. When both are given, an endpoint
must match BOTH to be selected.

NOTE: This is built from the CAM V3 API framework and assumes the endpoint
config field is `requestPathAlias`. If your area uses a different field for the
public path, pass --name instead, or adjust PATH_FIELD below.
"""

import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from mashery_paths import (load_env, get_token, mashery_get_all,
                           normalize_collection, print_json, mask_secret)

# Endpoint field holding the public-facing request path. Confirm this against
# your area's endpoint config if path matching returns nothing (see module docstring).
PATH_FIELD = "requestPathAlias"

# Nested field projection for Step 1. "plans" (and its nested services/endpoints)
# must be explicitly requested — they are not returned by default.
PACKAGE_FIELDS = ",".join([
    "id", "name",
    "plans.id", "plans.name",
    "plans.services.id", "plans.services.name",
    "plans.services.endpoints.id",
    "plans.services.endpoints.name",
    f"plans.services.endpoints.{PATH_FIELD}",
])


def _apps_from_keys(keys):
    """Collapse a list of PackageKeys into the distinct consuming Applications.

    Each key carries a nested `application` and owner `member`. Returns a list of
    {id, name, owner, plans[]} — one entry per Application, listing the plan(s)
    its keys sit on.
    """
    apps = {}
    for k in keys:
        app = k.get("application") or {}
        app_id = app.get("id")
        if app_id is None:
            continue
        owner = (k.get("member") or {}).get("username")
        plan = (k.get("plan") or {}).get("name")
        entry = apps.setdefault(app_id, {
            "id": app_id, "name": app.get("name"), "owner": owner, "plans": set(),
        })
        if plan:
            entry["plans"].add(plan)
    # Make plans JSON-serialisable and stable.
    return [{**a, "plans": sorted(a["plans"])} for a in apps.values()]


def _matches(value, needle, exact):
    """Case-insensitive match of `needle` against `value` (substring unless exact)."""
    if value is None or needle is None:
        return False
    v = str(value).lower()
    n = needle.lower()
    return v == n if exact else n in v


def find_matches(packages, name, path, exact):
    """Walk packages → plans → services → endpoints; return matched rows.

    Each row records the full chain so the report can group by package and by
    plan. An endpoint must match every provided criterion (name AND path).
    """
    rows = []
    for pkg in packages:
        pkg_id = pkg.get("id")
        pkg_name = pkg.get("name")
        for plan in (pkg.get("plans") or []):
            plan_id = plan.get("id")
            plan_name = plan.get("name")
            for svc in (plan.get("services") or []):
                svc_id = svc.get("id")
                svc_name = svc.get("name")
                for ep in (svc.get("endpoints") or []):
                    ep_name = ep.get("name")
                    ep_path = ep.get(PATH_FIELD)
                    ok_name = _matches(ep_name, name, exact) if name else True
                    ok_path = _matches(ep_path, path, exact) if path else True
                    if ok_name and ok_path:
                        rows.append({
                            "package_id": pkg_id,
                            "package_name": pkg_name,
                            "plan_id": plan_id,
                            "plan_name": plan_name,
                            "service_id": svc_id,
                            "service_name": svc_name,
                            "endpoint_id": ep.get("id"),
                            "endpoint_name": ep_name,
                            "endpoint_path": ep_path,
                        })
    return rows


def main():
    parser = argparse.ArgumentParser(
        description="Find which Packages/Plans/Applications consume a CAM endpoint")
    parser.add_argument("--name", help="Endpoint name to match")
    parser.add_argument("--path", help="Endpoint request path alias to match")
    parser.add_argument("--exact", action="store_true",
                        help="Exact (case-insensitive) match instead of substring")
    parser.add_argument("--json", action="store_true",
                        help="Emit JSON instead of the formatted report")
    parser.add_argument("--show-keys", action="store_true",
                        help="Reveal consumer API keys in output (masked by default)")
    args = parser.parse_args()

    if not args.name and not args.path:
        parser.error("provide at least one of --name / --path")

    load_env()
    token = get_token()

    # --- Step 1: build the package/plan/endpoint map and match the target ---
    if not args.json:
        print("Step 1: scanning packages for the target endpoint...", file=sys.stderr)
    packages = mashery_get_all("packages", token, params={"fields": PACKAGE_FIELDS})
    rows = find_matches(packages, args.name, args.path, args.exact)

    if not rows:
        crit = " and ".join(
            [c for c in (f"name~{args.name!r}" if args.name else None,
                         f"{PATH_FIELD}~{args.path!r}" if args.path else None) if c])
        msg = (f"No endpoint matched {crit} across {len(packages)} package(s).\n"
               f"  - Endpoints only appear here if a Plan grants access to them.\n"
               f"  - Try a looser --name/--path (substring), or drop --exact.\n"
               f"  - If matching by path, confirm your area uses '{PATH_FIELD}' "
               f"(see the note in this tool's header).")
        if args.json:
            print_json({"matched": [], "packages_scanned": len(packages), "message": msg})
        else:
            print(msg)
        sys.exit(0)

    matched_package_ids = sorted({r["package_id"] for r in rows})
    # Plans that actually grant the matched endpoint (only these consumers count).
    matched_plan_ids = {r["plan_id"] for r in rows if r["plan_id"]}

    # --- Steps 2 & 3: resolve consuming keys + applications per matched package ---
    consumers = []
    for pkg_id in matched_package_ids:
        pkg_name = next((r["package_name"] for r in rows if r["package_id"] == pkg_id), None)
        if not args.json:
            print(f"Step 2/3: fetching package keys + applications for package {pkg_id}...",
                  file=sys.stderr)

        # Step 2 — PackageKeys for this package, with the Application/owner/Plan
        # nested on each key. /packageKeys paginates by page index (per the CAM
        # framework). One call resolves both keys and consuming applications.
        keys = mashery_get_all(
            "packageKeys", token,
            params={"filter": f"package.id:{pkg_id}",
                    "fields": "id,apikey,status,member.id,member.username,"
                              "application.id,application.name,"
                              "package.id,plan.id,plan.name"},
            page_size=100, index_pagination=True)

        # Step 3 — keep only keys whose Plan grants the matched endpoint. These
        # are the keys (and apps) that genuinely consume the target endpoint.
        consuming_keys = [k for k in keys
                          if (k.get("plan") or {}).get("id") in matched_plan_ids]
        if not args.show_keys:
            for k in consuming_keys:
                if k.get("apikey"):
                    k["apikey"] = mask_secret(k["apikey"])

        consumers.append({
            "package_id": pkg_id,
            "package_name": pkg_name,
            "plans": sorted({(r["plan_id"], r["plan_name"]) for r in rows
                             if r["package_id"] == pkg_id}),
            "endpoints": [r for r in rows if r["package_id"] == pkg_id],
            "all_keys_count": len(keys),
            "package_keys": consuming_keys,
            "applications": _apps_from_keys(consuming_keys),
        })

    # --- Output ---
    if args.json:
        print_json({
            "query": {"name": args.name, "path": args.path, "exact": args.exact},
            "packages_scanned": len(packages),
            "matched_package_ids": matched_package_ids,
            "consumers": consumers,
        })
        return

    print()
    print("=" * 68)
    crit = ", ".join([c for c in (f"name~{args.name!r}" if args.name else None,
                                  f"path~{args.path!r}" if args.path else None) if c])
    print(f"Endpoint consumers for: {crit}")
    print("=" * 68)
    print(f"Matched {len(rows)} endpoint association(s) across "
          f"{len(matched_package_ids)} package(s).\n")

    for c in consumers:
        print(f"PACKAGE  {c['package_name']}  (id: {c['package_id']})")
        print("  Granting plan(s) for the matched endpoint:")
        for plan_id, plan_name in c["plans"]:
            print(f"    PLAN  {plan_name}  (id: {plan_id})")
        print("  Matched endpoint(s):")
        seen_ep = set()
        for ep in c["endpoints"]:
            if ep["endpoint_id"] in seen_ep:
                continue
            seen_ep.add(ep["endpoint_id"])
            print(f"    - {ep['endpoint_name']}  path={ep['endpoint_path']}  "
                  f"(endpoint {ep['endpoint_id']}, service {ep['service_id']})")

        keys = c["package_keys"]
        print(f"  Consuming PackageKeys ({len(keys)} of {c['all_keys_count']} total in package):")
        for k in keys:
            print(f"    - apikey={k.get('apikey')}  status={k.get('status')}  "
                  f"plan={(k.get('plan') or {}).get('name')}  "
                  f"app={(k.get('application') or {}).get('name')}  "
                  f"owner={(k.get('member') or {}).get('username')}")
        if not keys:
            print("    (no keys on a plan that grants this endpoint)")

        apps = c["applications"]
        print(f"  Consuming Applications ({len(apps)}):")
        for a in apps:
            print(f"    - {a.get('name')}  owner={a.get('owner')}  "
                  f"plans={','.join(a.get('plans') or [])}  (app {a.get('id')})")
        if not apps:
            print("    (none)")
        print()

    # Flat owner summary — usually the actual answer to "who uses this endpoint".
    owners = sorted({(a.get("name"), a.get("owner"))
                     for c in consumers for a in c["applications"]})
    print("-" * 68)
    print(f"Consuming applications ({len(owners)}):")
    for app_name, owner in owners:
        print(f"  - {app_name}  (owner: {owner})")
    if not owners:
        print("  (no applications hold a key on a plan that grants this endpoint yet)")


if __name__ == "__main__":
    main()
