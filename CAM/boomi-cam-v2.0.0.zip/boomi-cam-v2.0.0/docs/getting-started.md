# Getting Started with the CAM Skill

This guide walks you from zero to a live API on the Mashery gateway in approximately 15 minutes.

---

## What You Will Have at the End

A Boomi Integration web service listener exposed through Boomi Cloud API Management (Mashery) — with an API key you can use to call it from any HTTP client.

---

## Prerequisites

Before starting, confirm you have:

- [ ] Claude Code installed (`claude --version`)
- [ ] Python 3.7 or later (`python3 --version`)
- [ ] Boomi Cloud API Management access with an admin account
- [ ] A Boomi Integration Atom running and accessible on port 9090 (or your configured port)
- [ ] A Boomi web service listener process deployed on that Atom

If you do not have a Boomi listener yet, use the `boomi-integration` skill first to build and deploy one.

---

## Step 1 — Install the Skill

From within Claude Code:

```
/plugin marketplace add boomi-internal/boomi-cam
```

Or clone locally:

```bash
git clone https://github.com/boomi-internal/boomi-cam.git
claude plugin install ./boomi-cam
```

---

## Step 2 — Gather Your Credentials

You need five pieces of information from Mashery. Open **Mashery Control Center** (`developer.mashery.com`) while logged in with your admin account.

### Area UUID
Look at the URL when you are in the Control Center:
```
https://developer.mashery.com/controlcenter/areas/XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX/dashboard
                                                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                                                   Copy this — it is BOOMI_CAM_AREA_UUID
```

### API Key and Secret
Navigate to **My Account → Issue Developer Keys**. Create a new application key. Copy the **API Key** and **API Secret**.

### Traffic Domain
Navigate to **Manage → Areas**. Your area's **Traffic Manager Domain** is listed there (e.g., `yourcompany.api.mashery.com`). This is `BOOMI_CAM_TRAFFIC_DOMAIN`.

### Username and Password
Your Mashery login email and password.

---

## Step 3 — Create Your .env File

In your project root, create a `.env` file:

```bash
# Boomi Cloud API Management (Mashery)
BOOMI_CAM_API_KEY=your-app-api-key-from-step-2
BOOMI_CAM_API_SECRET=your-app-api-secret-from-step-2
BOOMI_CAM_USERNAME=you@example.com
BOOMI_CAM_PASSWORD=your-mashery-password
BOOMI_CAM_AREA_UUID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
BOOMI_CAM_API_URL=https://api.mashery.com
BOOMI_CAM_TRAFFIC_DOMAIN=yourcompany.api.mashery.com

# Boomi Integration (for the gateway pattern)
SERVER_BASE_URL=http://your-atom-hostname:9090
```

**Never commit `.env` to git.** It is already listed in `.gitignore`.

---

## Step 4 — Verify Credentials

Run the auth tool to confirm everything is wired correctly:

```bash
cd plugins/boomi-cam/skills/boomi-cam
python3 tools/mashery-auth.py
```

Expected output:
```
Authenticating to https://api.mashery.com...
Area UUID: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
Username:  you@example.com

Authentication successful!

Bearer token (valid ~1 hour):
eyJ...
```

If you see an error, check [Authentication Guide](guides/authentication.md) for the specific error type.

---

## Step 5 — Create the Service

A **Service** is the top-level API object — the logical definition of your API:

```bash
python3 tools/mashery-service-create.py \
  --name "My First API" \
  --description "Exposed via Boomi Integration" \
  --version "v1"
```

Output includes:
```
Service created successfully!
  Service ID:   abc12345-1234-1234-1234-abc123456789
  Name:         My First API
  Version:      v1
```

**Copy the Service ID** — you need it in the next step.

---

## Step 6 — Create the Endpoint

An **Endpoint** routes inbound traffic from Mashery to your Boomi listener:

```bash
python3 tools/mashery-endpoint-create.py \
  --service-id abc12345-1234-1234-1234-abc123456789 \
  --name "Default" \
  --backend-url "http://your-atom-host:9090/ws/rest/myapi" \
  --path-alias "/myapi"
```

Output includes:
```
Endpoint created successfully!
  Endpoint ID:  endpoint-uuid-here
  Path alias:   /myapi
  Backend:      http://your-atom-host:9090/ws/rest/myapi

Public URL will be:
  https://yourcompany.api.mashery.com/myapi?api_key=<api_key>
```

**Copy the Endpoint ID** — you need it in the next step.

---

## Step 7 — Create Package, Plan, and Test Key

A **Package** is the distributable bundle; a **Plan** is the access tier. The `--provision-key` flag auto-creates a test key for your account:

```bash
python3 tools/mashery-package-plan-create.py \
  --service-id abc12345-1234-1234-1234-abc123456789 \
  --endpoint-id endpoint-uuid-here \
  --package-name "My First API Package" \
  --plan-name "Basic" \
  --qps 10 \
  --rate-limit 1000 \
  --provision-key
```

Output includes:
```
============================================================
Setup Complete!
============================================================
  Package ID:   pkg-uuid
  Plan ID:      plan-uuid
  Service ID:   abc12345-...
  Endpoint ID:  endpoint-uuid-...

  Test API Key: EXAMPLE_API_KEY

  Test your API:
    curl "https://yourcompany.api.mashery.com/myapi?api_key=EXAMPLE_API_KEY"
```

---

## Step 8 — Test It

Copy the curl command from the output and run it:

```bash
curl "https://yourcompany.api.mashery.com/myapi?api_key=EXAMPLE_API_KEY"
```

If your Boomi listener is running and the Atom is accessible from the Mashery cloud, you will receive your API response.

---

## Troubleshooting

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| Auth tool returns 400 | Wrong API key/secret | Re-issue keys in Mashery Control Center |
| Auth tool returns 401 | Wrong username/password or locked account | Try logging in to Control Center manually |
| `invalid_grant` on token | Wrong Area UUID | Copy UUID from the Control Center URL |
| 404 on the gateway URL | Path alias mismatch | Verify `--path-alias` matches what you are calling |
| 503 from gateway | Atom unreachable | Confirm Atom host:port is network-accessible from Mashery |
| 401 on the gateway URL | Invalid or expired API key | Check key status in Mashery Control Center |

For detailed troubleshooting, see [authentication.md](guides/authentication.md) and [endpoints.md](guides/endpoints.md).

---

## Next Steps

- **Multiple environments**: Create separate Services and Endpoints for dev/test/prod
- **Rate limiting**: Adjust `--qps` and `--rate-limit` in your plan for production limits
- **OAuth**: Change `--auth oauth` on the endpoint for OAuth 2.0 instead of API keys
- **More APIs**: Repeat Steps 5–7 for each additional Boomi listener you want to expose
